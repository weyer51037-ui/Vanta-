# VibeEconomyPlus (add-on for VibeEconomy 1.5.0)

The original source wasn't available (jar only), so these features ship as a companion plugin
that hooks VibeEconomy. NOT compiled or tested yet - build and try on a test server first.

## Build
Needs JDK 21 + Maven: `mvn package` -> `target/VibeEconomyPlus-1.0.0.jar`.
Put it in `plugins/` next to VibeEconomy-1.5.0.jar. Copy `config-edits/shop.yml` and `crates.yml`
over `plugins/VibeEconomy/` and run `/shop reload` and `/crate reload`.

## Features
- **m / b / s amounts**: `/pay Bob 1.5m`, `/bounty Bob 2b`, also eco/duel/ah/orders. Letters are in config
  (`amounts.suffixes`). k, m, b, t, s are set; **s = sextillion (1e21)** - change if you meant something else.
- **Shop quantity menu**: right-click a stackable item. Starts at 1; -32/-8/-1/+1/+8/+32, full stack, confirm.
  Left click still buys one.
- **Selling**: `/sell`, `/sell hand`, `/sell all` now pay for custom (named/enchanted) items and keys.
  Prices in `sell.*`. Godset/Drill names are blocked.
- **Dimensional RTP**: `/rtp` opens an Overworld/Nether/End menu; `/rtp nether` goes direct.
- **Toggles**: `/vtoggle` GUI or `/vtoggle mobs.hostile off`. Hostile/passive/water/ambient, phantoms,
  spawners, raids, mob griefing, creeper/TNT block damage, fire spread, weather, hunger, fall damage.

- **/media**: shows the MEDIA rank rules (500 followers, 1k views, or 5 avg stream viewers). Edit under `media:` in config.

- **/open crates [crate]**: browse crates, or open one from anywhere using a key in your inventory.
  Mods run `/set opencrates on|off` (permission `vibeeconomy.mod`) to allow it for everyone. Default: off.

## Build on GitHub (no local setup)
Push this folder to a GitHub repo. Actions builds the jar on every push: repo -> Actions -> latest run -> Artifacts.
Tag a release (`git tag v1.0.0 && git push --tags`) and the jar is attached to the Releases page.

## Known limits
- Uses reflection on VibeEconomy internals (ShopGui$Holder.slots/category, package-private methods).
  If a field/method name differs at runtime, the console will show it.
- `record(...)` is called with negative amounts for purchases (assumed history convention).
- `/menu` -> Sell button still opens the original sell GUI (old prices); only the commands are replaced.
- Original `/rtpqueue` stays overworld-only.
