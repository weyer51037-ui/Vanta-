# VibeEconomy 1.5 (VantaSMP)

One plugin, no dependencies. Paper 1.21+, Java 21.

## Build (no install): GitHub
1. Create a free repository on github.com.
2. Upload the CONTENTS of this folder (pom.xml, src, README.md). Make sure pom.xml is at the top level.
3. Create .github/workflows/build.yml (build instructions file).
4. Actions tab > open the finished run > Artifacts > VibeEconomy-jar.

IMPORTANT when updating: delete config.yml, shop.yml and crates.yml in plugins/VibeEconomy/ on the server so the
new defaults are created. Balances, homes, shards etc. live in separate files and are kept.

## First-time setup
1. Stand where you want spawn and run the vanilla /setworldspawn. /spawn teleports there and the protected area is centered on it.
2. Place crates: look at a block and run /crate set <common|pvp|utility|treasure|legend>.
3. Give keys: /crate give <player> <vanta|void|legend> [amount]   |   /keyall [key] [amount]

## Commands
Money: /balance /pay /baltop /sell /sell hand|all /worth /transactions
Menus: /menu (hub), /shop, /ah, /orders, /settings
Spawners: /spawners (paged stash), admin: /spawners give <player> <mob> [amount]
Crates: /crate (preview), admin: set, remove, give, drill, reload
God set: /godset (admin: reset, give)
Travel: /spawn /sethome /home /delhome /homes /tpa /tpahere /tpaccept /tpdeny /rtp /rtpqueue
PvP: /duel <player> [wager] | accept | deny | forfeit
Social: /team /bounty /msg /reply /ignore /afk /stats /leaderboard /kit
Website: /roles (link). Admin: /role give <player> <role> | /role give <role> | remove | list | info (roles: media, admin, vanta, vanta+)

## Notes
- Money + role above heads: /settings > Money above head. Role comes from /role.
- Spawners: mine with Silk Touch. Placed spawners make 1 item/min (iron golem 5/min) into the owner's /spawners stash.
- Spawn protection radius: spawn.protection-radius in config.yml (100 = 100 blocks each way).
- Starter kit + $250,000 for new players (config.yml: starting-balance, starter-kit).

## Killstreaks, PvP and anti-cheat (1.5)
- /streak [player|top]: current/best streak. Rewards at 3/5/10/15/25 kills (config: killstreak), broadcasts,
  a growing server-funded bounty from streak 5, and a payout for ending someone's streak.
- PvP shop armor is crystal-optimized: Blast Protection IV + Unbreaking III + Mending.
  End crystals are sold in the PvP shop. Crystal/TNT damage is disabled at spawn.
- /ac (staff): alerts, status, logs, reset, exempt. Staff need vibeeconomy.ac.alerts to see alerts.
  The anti-cheat is conservative on purpose: it pauses on lag/high ping, ignores Bedrock players, creative, flying,
  gliding, vehicles, knockback and teleports, decays violations, and never bans unless you set ban-command.
- pvp section in config.yml: optional 1.8-style attack cooldown, crystal damage scaling, elytra block in combat.
