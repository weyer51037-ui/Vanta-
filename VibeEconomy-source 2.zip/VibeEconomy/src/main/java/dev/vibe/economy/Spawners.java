package dev.vibe.economy;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.CreatureSpawner;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.SpawnerSpawnEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Mineable spawners (Silk Touch). Placed spawners don't spawn mobs; instead they generate the mob's
 * drops into the owner's paged stash (/spawners): 1 per minute, 5 per minute for iron golems.
 */
@SuppressWarnings("deprecation")
public final class Spawners implements Listener, TabExecutor {

    private static final Map<String, String> ITEMS = new HashMap<>();
    static {
        String[][] d = {
                {"ZOMBIE", "ROTTEN_FLESH"}, {"HUSK", "ROTTEN_FLESH"}, {"DROWNED", "ROTTEN_FLESH"},
                {"SKELETON", "BONE"}, {"STRAY", "BONE"}, {"WITHER_SKELETON", "COAL"},
                {"SPIDER", "STRING"}, {"CAVE_SPIDER", "STRING"}, {"CREEPER", "GUNPOWDER"},
                {"ENDERMAN", "ENDER_PEARL"}, {"BLAZE", "BLAZE_ROD"}, {"PIG", "PORKCHOP"}, {"COW", "BEEF"},
                {"CHICKEN", "CHICKEN"}, {"SHEEP", "MUTTON"}, {"RABBIT", "RABBIT_HIDE"}, {"SLIME", "SLIME_BALL"},
                {"MAGMA_CUBE", "MAGMA_CREAM"}, {"WITCH", "REDSTONE"}, {"IRON_GOLEM", "IRON_INGOT"},
                {"ZOMBIFIED_PIGLIN", "GOLD_NUGGET"}, {"GUARDIAN", "PRISMARINE_SHARD"}, {"SQUID", "INK_SAC"},
                {"GHAST", "GHAST_TEAR"}, {"VILLAGER", "EMERALD"}
        };
        for (String[] e : d) ITEMS.put(e[0], e[1]);
    }

    private static final class Sp {
        final UUID owner; final EntityType type;
        Sp(UUID owner, EntityType type) { this.owner = owner; this.type = type; }
    }

    private static final class Stack {
        final Material m; final int n;
        Stack(Material m, int n) { this.m = m; this.n = n; }
    }

    private static final class Holder implements InventoryHolder {
        final int page;
        final Map<Integer, Stack> slots = new HashMap<>();
        Inventory inv;
        Holder(int page) { this.page = page; }
        @Override public Inventory getInventory() { return inv; }
    }

    private final VibeEconomy plugin;
    private final File file;
    private final Map<String, Sp> spawners = new HashMap<>();
    private final Map<UUID, Map<Material, Long>> stash = new HashMap<>();

    public Spawners(VibeEconomy plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "spawners.yml");
        load();
        Bukkit.getScheduler().runTaskTimer(plugin, this::produce, 1200L, 1200L);
    }

    // ---------------------------------------------------------------- storage

    private String lkey(Location l) {
        return l.getWorld().getName() + ":" + l.getBlockX() + ":" + l.getBlockY() + ":" + l.getBlockZ();
    }

    private Location fromKey(String key) {
        String[] sp = key.split(":");
        if (sp.length != 4) return null;
        World w = Bukkit.getWorld(sp[0]);
        if (w == null) return null;
        try { return new Location(w, Integer.parseInt(sp[1]), Integer.parseInt(sp[2]), Integer.parseInt(sp[3])); }
        catch (NumberFormatException e) { return null; }
    }

    private void load() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        for (String s : y.getStringList("spawners")) {
            String[] p = s.split("=");
            if (p.length != 3) continue;
            try { spawners.put(p[0], new Sp(UUID.fromString(p[1]), EntityType.valueOf(p[2]))); }
            catch (IllegalArgumentException ignored) { }
        }
        ConfigurationSection ss = y.getConfigurationSection("stash");
        if (ss != null) {
            for (String u : ss.getKeys(false)) {
                ConfigurationSection m = ss.getConfigurationSection(u);
                if (m == null) continue;
                Map<Material, Long> map = new EnumMap<>(Material.class);
                for (String mk : m.getKeys(false)) {
                    Material mat = Material.matchMaterial(mk);
                    if (mat != null && m.getLong(mk) > 0) map.put(mat, m.getLong(mk));
                }
                try { stash.put(UUID.fromString(u), map); } catch (IllegalArgumentException ignored) { }
            }
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        List<String> list = new ArrayList<>();
        for (Map.Entry<String, Sp> e : spawners.entrySet()) list.add(e.getKey() + "=" + e.getValue().owner + "=" + e.getValue().type.name());
        y.set("spawners", list);
        for (Map.Entry<UUID, Map<Material, Long>> e : stash.entrySet()) {
            for (Map.Entry<Material, Long> m : e.getValue().entrySet()) {
                if (m.getValue() > 0) y.set("stash." + e.getKey() + "." + m.getKey().name(), m.getValue());
            }
        }
        try { y.save(file); } catch (IOException e) { plugin.getLogger().severe("spawners.yml: " + e.getMessage()); }
    }

    // ---------------------------------------------------------------- rates

    private Material itemFor(EntityType t) {
        String name = plugin.getConfig().getString("spawners.items." + t.name(), ITEMS.get(t.name()));
        Material m = name == null ? null : Material.matchMaterial(name);
        return m == null ? Material.BONE : m;
    }

    private int rateFor(EntityType t) {
        int def = t == EntityType.IRON_GOLEM ? 5 : plugin.getConfig().getInt("spawners.default-per-minute", 1);
        return Math.max(0, plugin.getConfig().getInt("spawners.rates." + t.name(), def));
    }

    private static String pretty(String s) {
        StringBuilder sb = new StringBuilder();
        for (String w : s.toLowerCase(Locale.ROOT).split("_")) {
            if (w.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        return sb.toString();
    }

    // ---------------------------------------------------------------- items

    public ItemStack createItem(EntityType type, int amount) {
        ItemStack it = new ItemStack(Material.SPAWNER, Math.max(1, amount));
        BlockStateMeta meta = (BlockStateMeta) it.getItemMeta();
        CreatureSpawner cs = (CreatureSpawner) meta.getBlockState();
        cs.setSpawnedType(type);
        meta.setBlockState(cs);
        meta.setDisplayName(ItemSpec.c("&e" + pretty(type.name()) + " Spawner"));
        List<String> lore = new ArrayList<>();
        lore.add(ItemSpec.c("&7Generates &f" + rateFor(type) + "x " + pretty(itemFor(type).name()) + " &7per minute."));
        lore.add(ItemSpec.c("&7Place it, then collect with &f/spawners&7."));
        meta.setLore(lore);
        it.setItemMeta(meta);
        return it;
    }

    private EntityType typeOf(ItemStack it) {
        if (it == null || it.getType() != Material.SPAWNER || !(it.getItemMeta() instanceof BlockStateMeta bsm)) return EntityType.PIG;
        if (bsm.getBlockState() instanceof CreatureSpawner cs && cs.getSpawnedType() != null) return cs.getSpawnedType();
        return EntityType.PIG;
    }

    // ---------------------------------------------------------------- events

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Block b = e.getBlock();
        if (b.getType() != Material.SPAWNER) return;
        Player p = e.getPlayer();
        String key = lkey(b.getLocation());
        Sp reg = spawners.get(key);
        boolean admin = p.hasPermission("vibeeconomy.admin");
        if (reg != null && plugin.getConfig().getBoolean("spawners.owner-only-break", false)
                && !reg.owner.equals(p.getUniqueId()) && !admin) {
            e.setCancelled(true);
            plugin.msg(p, "&cOnly the owner can mine this spawner.");
            return;
        }
        ItemStack tool = p.getInventory().getItemInMainHand();
        if (!tool.containsEnchantment(Enchantment.SILK_TOUCH)) {
            e.setCancelled(true);
            plugin.msg(p, "&cYou need a &fSilk Touch &cpickaxe to mine spawners.");
            return;
        }
        EntityType type = reg != null ? reg.type
                : (b.getState() instanceof CreatureSpawner cs && cs.getSpawnedType() != null ? cs.getSpawnedType() : EntityType.PIG);
        e.setExpToDrop(0);
        e.setDropItems(false);
        b.getWorld().dropItemNaturally(b.getLocation().add(0.5, 0.5, 0.5), createItem(type, 1));
        if (reg != null) {
            spawners.remove(key);
            save();
            Player owner = Bukkit.getPlayer(reg.owner);
            if (owner != null && !owner.getUniqueId().equals(p.getUniqueId())) {
                plugin.msg(owner, "&c" + p.getName() + " mined one of your " + pretty(type.name()) + " spawners!");
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        Block b = e.getBlockPlaced();
        if (b.getType() != Material.SPAWNER) return;
        Player p = e.getPlayer();
        int max = plugin.getConfig().getInt("spawners.max-per-player", 200);
        int owned = 0;
        for (Sp sp : spawners.values()) if (sp.owner.equals(p.getUniqueId())) owned++;
        if (owned >= max && !p.hasPermission("vibeeconomy.admin")) {
            e.setCancelled(true);
            plugin.msg(p, "&cYou can only have " + max + " placed spawners.");
            return;
        }
        EntityType type = typeOf(e.getItemInHand());
        if (b.getState() instanceof CreatureSpawner cs) {
            cs.setSpawnedType(type);
            cs.update(true, false);
        }
        spawners.put(lkey(b.getLocation()), new Sp(p.getUniqueId(), type));
        save();
        plugin.msg(p, "&aPlaced a &e" + pretty(type.name()) + " Spawner&a. It generates &f" + rateFor(type) + "x "
                + pretty(itemFor(type).name()) + " &aper minute into &f/spawners&a.");
    }

    @EventHandler
    public void onSpawn(SpawnerSpawnEvent e) {
        if (e.getSpawner() != null && spawners.containsKey(lkey(e.getSpawner().getLocation()))) e.setCancelled(true);
    }

    @EventHandler
    public void onEntityExplode(EntityExplodeEvent e) {
        e.blockList().removeIf(b -> spawners.containsKey(lkey(b.getLocation())));
    }

    @EventHandler
    public void onBlockExplode(BlockExplodeEvent e) {
        e.blockList().removeIf(b -> spawners.containsKey(lkey(b.getLocation())));
    }

    @EventHandler
    public void onPistonExtend(BlockPistonExtendEvent e) {
        for (Block b : e.getBlocks()) if (spawners.containsKey(lkey(b.getLocation()))) { e.setCancelled(true); return; }
    }

    @EventHandler
    public void onPistonRetract(BlockPistonRetractEvent e) {
        for (Block b : e.getBlocks()) if (spawners.containsKey(lkey(b.getLocation()))) { e.setCancelled(true); return; }
    }

    // ---------------------------------------------------------------- production

    private long total(Map<Material, Long> st) {
        long t = 0;
        for (long v : st.values()) t += v;
        return t;
    }

    private void produce() {
        long cap = plugin.getConfig().getLong("spawners.max-storage", 500_000);
        for (Iterator<Map.Entry<String, Sp>> it = spawners.entrySet().iterator(); it.hasNext();) {
            Map.Entry<String, Sp> e = it.next();
            Location l = fromKey(e.getKey());
            // clean up spawners whose block no longer exists (only checks loaded chunks)
            if (l != null && l.getWorld().isChunkLoaded(l.getBlockX() >> 4, l.getBlockZ() >> 4)
                    && l.getBlock().getType() != Material.SPAWNER) {
                it.remove();
                continue;
            }
            Sp sp = e.getValue();
            Map<Material, Long> st = stash.computeIfAbsent(sp.owner, k -> new EnumMap<>(Material.class));
            long room = cap - total(st);
            if (room <= 0) continue;
            st.merge(itemFor(sp.type), Math.min(rateFor(sp.type), room), Long::sum);
        }
        save();
    }

    // ---------------------------------------------------------------- GUI

    private List<Stack> stacks(UUID id) {
        Map<Material, Long> st = stash.getOrDefault(id, new EnumMap<>(Material.class));
        List<Material> mats = new ArrayList<>(st.keySet());
        mats.sort(Comparator.comparing(Enum::name));
        List<Stack> out = new ArrayList<>();
        for (Material m : mats) {
            long c = st.get(m);
            int max = Math.max(1, m.getMaxStackSize());
            while (c > 0) {
                int n = (int) Math.min(max, c);
                out.add(new Stack(m, n));
                c -= n;
            }
        }
        return out;
    }

    private void take(UUID id, Material m, long n) {
        Map<Material, Long> st = stash.get(id);
        if (st == null) return;
        long left = st.getOrDefault(m, 0L) - n;
        if (left <= 0) st.remove(m); else st.put(m, left);
    }

    public void open(Player p, int page) {
        List<Stack> all = stacks(p.getUniqueId());
        int pages = Math.max(1, (int) Math.ceil(all.size() / 45.0));
        int pg = Math.max(0, Math.min(page, pages - 1));
        Holder h = new Holder(pg);
        Inventory inv = Bukkit.createInventory(h, 54, ItemSpec.c("&e&lSpawner Stash &8(" + (pg + 1) + "/" + pages + ")"));
        h.inv = inv;

        int from = pg * 45;
        for (int i = 0; i < 45 && from + i < all.size(); i++) {
            Stack s = all.get(from + i);
            ItemStack icon = new ItemStack(s.m, s.n);
            ItemMeta m = icon.getItemMeta();
            List<String> lore = new ArrayList<>();
            double price = plugin.sellPrice(s.m);
            if (price >= 0) lore.add(ItemSpec.c("&7Worth: &a" + plugin.money(price * s.n)));
            lore.add(ItemSpec.c("&eClick to take"));
            m.setLore(lore);
            icon.setItemMeta(m);
            inv.setItem(i, icon);
            h.slots.put(i, s);
        }
        for (int i = 45; i < 54; i++) inv.setItem(i, Util.filler());
        Util.navButtons(inv);

        int count = 0, perMin = 0;
        for (Sp sp : spawners.values()) {
            if (sp.owner.equals(p.getUniqueId())) { count++; perMin += rateFor(sp.type); }
        }
        long totalItems = total(stash.getOrDefault(p.getUniqueId(), new EnumMap<>(Material.class)));
        long cap = plugin.getConfig().getLong("spawners.max-storage", 500_000);
        if (pg > 0) inv.setItem(45, Util.button(Material.ARROW, "&7Previous page"));
        if (pg < pages - 1) inv.setItem(53, Util.button(Material.ARROW, "&7Next page"));
        inv.setItem(47, Util.button(Material.CHEST, "&aTake this page", "&7Moves every stack on this page", "&7into your inventory."));
        inv.setItem(49, Util.button(Material.SPAWNER, "&eYour spawners: &f" + count,
                "&7Producing about &f" + perMin + " &7items per minute.", "&7Stored: &f" + totalItems + " &7/ " + cap));
        inv.setItem(50, Util.button(Material.EMERALD, "&a&lSell everything", "&7Sells all sellable items in your stash", "&7at /sell prices."));
        p.openInventory(inv);
    }

    private void sellAll(Player p) {
        Map<Material, Long> st = stash.get(p.getUniqueId());
        if (st == null || st.isEmpty()) { plugin.msg(p, "&cYour stash is empty."); return; }
        double total = 0;
        long items = 0;
        for (Iterator<Map.Entry<Material, Long>> it = st.entrySet().iterator(); it.hasNext();) {
            Map.Entry<Material, Long> e = it.next();
            double price = plugin.sellPrice(e.getKey());
            if (price < 0) continue;
            total += price * e.getValue();
            items += e.getValue();
            it.remove();
        }
        if (items == 0) { plugin.msg(p, "&cNothing in your stash can be sold."); return; }
        total = Util.round2(total);
        plugin.deposit(p.getUniqueId(), total);
        plugin.record(p.getUniqueId(), "Sold " + items + " spawner items", total);
        plugin.msg(p, "&aSold &f" + items + " items&a for &f" + plugin.money(total) + "&a.");
        save();
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != top) return;
        int slot = e.getRawSlot();
        if (Util.navClick(plugin, p, slot)) return;

        if (slot == 45 && h.page > 0) { open(p, h.page - 1); return; }
        if (slot == 53) { open(p, h.page + 1); return; }
        if (slot == 50) { sellAll(p); open(p, h.page); return; }
        if (slot == 47) {
            int moved = 0;
            for (Stack s : h.slots.values()) {
                long have = stash.getOrDefault(p.getUniqueId(), new EnumMap<>(Material.class)).getOrDefault(s.m, 0L);
                if (have < s.n) continue;
                take(p.getUniqueId(), s.m, s.n);
                plugin.giveItem(p, new ItemStack(s.m, s.n));
                moved += s.n;
            }
            if (moved > 0) save();
            plugin.msg(p, moved > 0 ? "&aTook &f" + moved + " &aitems." : "&cNothing to take on this page.");
            open(p, h.page);
            return;
        }
        Stack s = h.slots.get(slot);
        if (s == null) return;
        long have = stash.getOrDefault(p.getUniqueId(), new EnumMap<>(Material.class)).getOrDefault(s.m, 0L);
        if (have >= s.n) {
            take(p.getUniqueId(), s.m, s.n);
            plugin.giveItem(p, new ItemStack(s.m, s.n));
            save();
        }
        open(p, h.page);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    // ---------------------------------------------------------------- commands

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (a.length >= 1 && a[0].equalsIgnoreCase("give")) {
            if (!s.hasPermission("vibeeconomy.admin")) { plugin.msg(s, "&cNo permission."); return true; }
            if (a.length < 3) { plugin.msg(s, "&cUsage: /spawners give <player> <mob> [amount]  (e.g. iron_golem)"); return true; }
            Player t = Bukkit.getPlayerExact(a[1]);
            if (t == null) { plugin.msg(s, "&cThat player must be online."); return true; }
            EntityType type;
            try { type = EntityType.valueOf(a[2].toUpperCase(Locale.ROOT)); }
            catch (IllegalArgumentException ex) { plugin.msg(s, "&cUnknown mob type."); return true; }
            int amount = 1;
            if (a.length >= 4) {
                try { amount = Math.max(1, Math.min(64, Integer.parseInt(a[3]))); } catch (NumberFormatException ex) { plugin.msg(s, "&cInvalid amount."); return true; }
            }
            plugin.giveItem(t, createItem(type, amount));
            plugin.msg(s, "&aGave " + t.getName() + " " + amount + "x " + pretty(type.name()) + " Spawner.");
            return true;
        }
        if (!(s instanceof Player p)) { plugin.msg(s, "&cPlayers only."); return true; }
        open(p, 0);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (!s.hasPermission("vibeeconomy.admin")) return out;
        String cur = a.length > 0 ? a[a.length - 1].toLowerCase() : "";
        if (a.length == 1 && "give".startsWith(cur)) out.add("give");
        else if (a.length == 2 && a[0].equalsIgnoreCase("give")) {
            for (Player p : Bukkit.getOnlinePlayers()) if (p.getName().toLowerCase().startsWith(cur)) out.add(p.getName());
        } else if (a.length == 3 && a[0].equalsIgnoreCase("give")) {
            for (String k : ITEMS.keySet()) if (k.toLowerCase().startsWith(cur)) out.add(k.toLowerCase());
        }
        return out;
    }
}
