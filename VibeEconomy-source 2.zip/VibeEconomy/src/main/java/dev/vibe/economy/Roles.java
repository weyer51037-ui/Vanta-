package dev.vibe.economy;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Roles shown next to a player's money above their head and in the sidebar.
 *   /role give <player> <role>     (or /role give <role> to give it to yourself)
 *   /role remove <player>   /role list   /role info <player>
 * The website (or any console tool) can run: role give <player> <role>
 * Roles are labels only; they don't grant permissions.
 */
@SuppressWarnings("deprecation")
public final class Roles implements TabExecutor {

    private static final Map<String, String> DEFAULTS = new LinkedHashMap<>();
    static {
        DEFAULTS.put("media", "&c&lMEDIA");
        DEFAULTS.put("admin", "&4&lADMIN");
        DEFAULTS.put("vanta", "&5&lVANTA");
        DEFAULTS.put("vanta+", "&d&lVANTA+");
    }

    private final VibeEconomy plugin;
    private final File file;
    private final Map<UUID, String> assigned = new HashMap<>();

    public Roles(VibeEconomy plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "roles.yml");
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        for (String k : y.getKeys(false)) {
            try { assigned.put(UUID.fromString(k), y.getString(k)); } catch (IllegalArgumentException ignored) { }
        }
    }

    private void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<UUID, String> e : assigned.entrySet()) y.set(e.getKey().toString(), e.getValue());
        try { y.save(file); } catch (IOException e) { plugin.getLogger().severe("roles.yml: " + e.getMessage()); }
    }

    /** Built-in roles plus anything in config.yml (roles.list). Config entries override the defaults. */
    private Map<String, String> roleList() {
        Map<String, String> out = new LinkedHashMap<>(DEFAULTS);
        ConfigurationSection cs = plugin.getConfig().getConfigurationSection("roles.list");
        if (cs != null) {
            for (String k : cs.getKeys(false)) out.put(k.toLowerCase(Locale.ROOT), cs.getString(k, k));
        }
        return out;
    }

    /** Colored role label for a player, or null if they have none. */
    public String display(UUID id) {
        String r = assigned.get(id);
        if (r == null) return null;
        String d = roleList().get(r);
        return d == null ? r : d;
    }

    private String normalize(String[] a, int from) {
        // lets "/role give vanta +" work the same as "/role give vanta+"
        return String.join("", Arrays.copyOfRange(a, from, a.length)).toLowerCase(Locale.ROOT);
    }

    private String roleNames() { return String.join(", ", roleList().keySet()); }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (!s.hasPermission("vibeeconomy.admin")) { plugin.msg(s, "&cNo permission."); return true; }
        if (a.length == 0) {
            plugin.msg(s, "&6/role give <player> <role> &7| &6/role give <role> &7(yourself)\n&6/role remove <player> &7| &6/role list &7| &6/role info <player>\n&7Roles: &f" + roleNames());
            return true;
        }
        String sub = a[0].toLowerCase();
        Map<String, String> roles = roleList();

        if (sub.equals("list")) {
            StringBuilder sb = new StringBuilder("&6Roles:");
            for (Map.Entry<String, String> e : roles.entrySet()) sb.append("\n&e").append(e.getKey()).append(" &7= ").append(e.getValue());
            plugin.msg(s, sb.toString());
            return true;
        }

        if (sub.equals("give") || sub.equals("set")) {
            if (a.length < 2) { plugin.msg(s, "&cUsage: /role give <player> <role>   Roles: " + roleNames()); return true; }
            OfflinePlayer target;
            String role;
            String selfRole = normalize(a, 1);
            if (roles.containsKey(selfRole)) {
                // /role give media  (or "vanta +")  -> give it to yourself
                if (!(s instanceof Player self)) { plugin.msg(s, "&cFrom the console use: role give <player> <role>"); return true; }
                target = self;
                role = selfRole;
            } else {
                if (a.length < 3) { plugin.msg(s, "&cUsage: /role give <player> <role>   Roles: " + roleNames()); return true; }
                target = Bukkit.getOfflinePlayer(a[1]);
                role = normalize(a, 2);
                if (!roles.containsKey(role)) { plugin.msg(s, "&cUnknown role. Roles: " + roleNames()); return true; }
            }
            if (!target.hasPlayedBefore() && !target.isOnline()) { plugin.msg(s, "&cThat player has never joined."); return true; }
            assigned.put(target.getUniqueId(), role);
            save();
            plugin.msg(s, "&a" + target.getName() + " now has the " + display(target.getUniqueId()) + "&a role.");
            Player on = target.getPlayer();
            if (on != null && !on.equals(s)) plugin.msg(on, "&aYou received the " + display(target.getUniqueId()) + "&a role! Thank you!");
            if (plugin.hud() != null) plugin.hud().refreshAll();
            return true;
        }

        if (sub.equals("remove") || sub.equals("info")) {
            if (a.length < 2) { plugin.msg(s, "&cSpecify a player."); return true; }
            OfflinePlayer t = Bukkit.getOfflinePlayer(a[1]);
            if (!t.hasPlayedBefore() && !t.isOnline()) { plugin.msg(s, "&cThat player has never joined."); return true; }
            if (sub.equals("remove")) {
                assigned.remove(t.getUniqueId());
                save();
                plugin.msg(s, "&aRemoved " + t.getName() + "'s role.");
                if (plugin.hud() != null) plugin.hud().refreshAll();
            } else {
                plugin.msg(s, "&e" + t.getName() + "&7: " + (display(t.getUniqueId()) == null ? "no role" : display(t.getUniqueId())));
            }
            return true;
        }
        plugin.msg(s, "&cUnknown subcommand. Use /role for help.");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (!s.hasPermission("vibeeconomy.admin")) return out;
        String cur = a.length > 0 ? a[a.length - 1].toLowerCase() : "";
        if (a.length == 1) {
            for (String o : new String[]{"give", "remove", "list", "info"}) if (o.startsWith(cur)) out.add(o);
        } else if (a.length == 2) {
            if (a[0].equalsIgnoreCase("give")) for (String r : roleList().keySet()) if (r.startsWith(cur)) out.add(r);
            for (Player p : Bukkit.getOnlinePlayers()) if (p.getName().toLowerCase().startsWith(cur)) out.add(p.getName());
        } else if (a.length == 3 && a[0].equalsIgnoreCase("give")) {
            for (String r : roleList().keySet()) if (r.startsWith(cur)) out.add(r);
        }
        return out;
    }
}
