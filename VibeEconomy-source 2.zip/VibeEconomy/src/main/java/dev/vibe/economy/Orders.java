package dev.vibe.economy;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Buy orders: players post what they want to buy, others fill them for money. */
public final class Orders implements Listener, TabExecutor {

    private static final class Order {
        final String id; final UUID owner; final String ownerName; final Material mat;
        int remaining; final int total; final double price; final long time;
        Order(String id, UUID owner, String ownerName, Material mat, int remaining, int total, double price, long time) {
            this.id = id; this.owner = owner; this.ownerName = ownerName; this.mat = mat;
            this.remaining = remaining; this.total = total; this.price = price; this.time = time;
        }
    }

    private static final class Holder implements InventoryHolder {
        final boolean mine; final int page;
        final Map<Integer, String> slots = new HashMap<>();
        Inventory inv;
        Holder(boolean mine, int page) { this.mine = mine; this.page = page; }
        @Override public Inventory getInventory() { return inv; }
    }

    private final VibeEconomy plugin;
    private final File file;
    private final List<Order> orders = new ArrayList<>();
    private final Map<UUID, Map<Material, Integer>> deliveries = new HashMap<>();

    public Orders(VibeEconomy plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "orders.yml");
        load();
    }

    // ---------------------------------------------------------------- storage

    private void load() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection os = y.getConfigurationSection("orders");
        if (os != null) {
            for (String id : os.getKeys(false)) {
                ConfigurationSection s = os.getConfigurationSection(id);
                if (s == null) continue;
                Material m = Material.matchMaterial(s.getString("material", ""));
                if (m == null) continue;
                try {
                    orders.add(new Order(id, UUID.fromString(s.getString("owner", "")), s.getString("name", "?"), m,
                            s.getInt("remaining"), s.getInt("total"), s.getDouble("price"), s.getLong("time")));
                } catch (IllegalArgumentException ignored) { }
            }
        }
        ConfigurationSection ds = y.getConfigurationSection("deliveries");
        if (ds != null) {
            for (String u : ds.getKeys(false)) {
                ConfigurationSection s = ds.getConfigurationSection(u);
                if (s == null) continue;
                Map<Material, Integer> map = new HashMap<>();
                for (String mk : s.getKeys(false)) {
                    Material m = Material.matchMaterial(mk);
                    if (m != null) map.put(m, s.getInt(mk));
                }
                try { deliveries.put(UUID.fromString(u), map); } catch (IllegalArgumentException ignored) { }
            }
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Order o : orders) {
            String k = "orders." + o.id;
            y.set(k + ".owner", o.owner.toString());
            y.set(k + ".name", o.ownerName);
            y.set(k + ".material", o.mat.name());
            y.set(k + ".remaining", o.remaining);
            y.set(k + ".total", o.total);
            y.set(k + ".price", o.price);
            y.set(k + ".time", o.time);
        }
        for (Map.Entry<UUID, Map<Material, Integer>> e : deliveries.entrySet()) {
            for (Map.Entry<Material, Integer> d : e.getValue().entrySet()) {
                if (d.getValue() > 0) y.set("deliveries." + e.getKey() + "." + d.getKey().name(), d.getValue());
            }
        }
        try { y.save(file); } catch (IOException e) { plugin.getLogger().severe("orders.yml: " + e.getMessage()); }
    }

    private Order find(String id) {
        for (Order o : orders) if (o.id.equals(id)) return o;
        return null;
    }

    private int deliveryCount(UUID id) {
        Map<Material, Integer> m = deliveries.get(id);
        if (m == null) return 0;
        int n = 0;
        for (int v : m.values()) n += v;
        return n;
    }

    // ---------------------------------------------------------------- commands

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (!(s instanceof Player p)) { plugin.msg(s, "&cPlayers only."); return true; }
        if (a.length == 0) { open(p, false, 0); return true; }
        switch (a[0].toLowerCase()) {
            case "create": create(p, a); break;
            case "mine": open(p, true, 0); break;
            case "claim": claim(p); break;
            default: plugin.msg(p, "&cUsage: /orders, /orders create <item> <amount> <price each>, /orders mine, /orders claim");
        }
        return true;
    }

    private void create(Player p, String[] a) {
        if (a.length < 4) { plugin.msg(p, "&cUsage: /orders create <item> <amount> <price each>"); return; }
        Material m = Material.matchMaterial(a[1]);
        if (m == null || !m.isItem() || !plugin.hasPrice(m)) { plugin.msg(p, "&cThat item can't be ordered."); return; }
        int amount;
        try { amount = Integer.parseInt(a[2]); } catch (NumberFormatException e) { plugin.msg(p, "&cInvalid amount."); return; }
        int maxAmt = plugin.getConfig().getInt("orders.max-amount", 2304);
        if (amount < 1 || amount > maxAmt) { plugin.msg(p, "&cAmount must be 1-" + maxAmt + "."); return; }
        Double price = VibeEconomy.parseMoney(a[3]);
        double maxPrice = plugin.getConfig().getDouble("orders.max-price-each", 10_000_000);
        if (price == null || price < 0.05 || price > maxPrice) { plugin.msg(p, "&cInvalid price each."); return; }
        int mine = 0;
        for (Order o : orders) if (o.owner.equals(p.getUniqueId())) mine++;
        int limit = plugin.getConfig().getInt("orders.max-orders", 5);
        if (mine >= limit) { plugin.msg(p, "&cYou can only have " + limit + " active orders."); return; }
        double total = Util.round2(amount * price);
        if (!plugin.withdraw(p.getUniqueId(), total)) { plugin.msg(p, "&cYou need " + plugin.money(total) + " to place that order."); return; }
        plugin.record(p.getUniqueId(), "Order placed: " + amount + "x " + Util.pretty(m), -total);
        orders.add(new Order(UUID.randomUUID().toString(), p.getUniqueId(), p.getName(), m, amount, amount, price, System.currentTimeMillis()));
        save();
        plugin.msg(p, "&aOrder placed: &f" + amount + "x " + Util.pretty(m) + " &aat &f" + plugin.money(price)
                + " &aeach. &7(" + plugin.money(total) + " held until filled or cancelled)");
    }

    private void claim(Player p) {
        Map<Material, Integer> map = deliveries.remove(p.getUniqueId());
        if (map == null || map.isEmpty()) { plugin.msg(p, "&cYou have nothing to claim."); return; }
        int total = 0;
        for (Map.Entry<Material, Integer> e : map.entrySet()) {
            if (e.getValue() <= 0) continue;
            plugin.giveItem(p, new ItemStack(e.getKey(), e.getValue()));
            total += e.getValue();
        }
        save();
        plugin.msg(p, "&aClaimed &f" + total + " &aitems from your orders.");
    }

    // ---------------------------------------------------------------- GUI

    public void open(Player p, boolean mine, int page) {
        List<Order> view = new ArrayList<>();
        for (Order o : orders) if (!mine || o.owner.equals(p.getUniqueId())) view.add(o);
        view.sort((x, y) -> {
            int c = Double.compare(y.price, x.price);
            return c != 0 ? c : Long.compare(x.time, y.time);
        });
        int pages = Math.max(1, (int) Math.ceil(view.size() / 45.0));
        int pg = Math.max(0, Math.min(page, pages - 1));

        Holder h = new Holder(mine, pg);
        String title = (mine ? "&b&lMy Orders" : "&b&lBuy Orders") + " &8(" + (pg + 1) + "/" + pages + ")";
        Inventory inv = Bukkit.createInventory(h, 54, ItemSpec.c(title));
        h.inv = inv;

        int from = pg * 45;
        for (int i = 0; i < 45 && from + i < view.size(); i++) {
            Order o = view.get(from + i);
            ItemStack icon = new ItemStack(o.mat);
            ItemMeta m = icon.getItemMeta();
            m.setDisplayName(ItemSpec.c("&f" + Util.pretty(o.mat)));
            List<String> lore = new ArrayList<>();
            lore.add(ItemSpec.c("&7Buyer: &f" + o.ownerName));
            lore.add(ItemSpec.c("&7Wants: &f" + o.remaining + " &7/ " + o.total));
            lore.add(ItemSpec.c("&aPays: &f" + plugin.money(o.price) + " &aeach"));
            lore.add("");
            if (mine) lore.add(ItemSpec.c("&eClick to cancel (refund &a" + plugin.money(Util.round2(o.remaining * o.price)) + "&e)"));
            else if (o.owner.equals(p.getUniqueId())) lore.add(ItemSpec.c("&7This is your order"));
            else lore.add(ItemSpec.c("&7You have: &f" + count(p, o.mat) + " &8| &eClick to fill"));
            m.setLore(lore);
            icon.setItemMeta(m);
            inv.setItem(i, icon);
            h.slots.put(i, o.id);
        }
        for (int i = 45; i < 54; i++) inv.setItem(i, Util.filler());
        Util.navButtons(inv);
        if (pg > 0) inv.setItem(45, Util.button(Material.ARROW, "&7Previous page"));
        if (pg < pages - 1) inv.setItem(53, Util.button(Material.ARROW, "&7Next page"));
        inv.setItem(48, mine ? Util.button(Material.CHEST, "&eAll Orders")
                : Util.button(Material.BOOK, "&eMy Orders", "&7View or cancel your orders."));
        inv.setItem(49, Util.button(Material.GOLD_INGOT, "&eBalance: &a" + plugin.money(plugin.getBalance(p.getUniqueId())),
                "&7New order: &f/orders create <item> <amount> <price>"));
        inv.setItem(50, Util.button(Material.ENDER_CHEST, "&dClaim delivered items", "&7Items waiting: &f" + deliveryCount(p.getUniqueId())));
        p.openInventory(inv);
    }

    private int count(Player p, Material m) {
        ItemStack base = new ItemStack(m);
        int n = 0;
        for (ItemStack it : p.getInventory().getStorageContents()) {
            if (it != null && it.isSimilar(base)) n += it.getAmount();
        }
        return n;
    }

    private void remove(Player p, Material m, int n) {
        ItemStack base = new ItemStack(m);
        ItemStack[] c = p.getInventory().getStorageContents();
        int left = n;
        for (int i = 0; i < c.length && left > 0; i++) {
            if (c[i] == null || !c[i].isSimilar(base)) continue;
            int t = Math.min(left, c[i].getAmount());
            if (t == c[i].getAmount()) c[i] = null;
            else c[i].setAmount(c[i].getAmount() - t);
            left -= t;
        }
        p.getInventory().setStorageContents(c);
    }

    private void fill(Player p, Order o) {
        if (o.owner.equals(p.getUniqueId())) { plugin.msg(p, "&cYou can't fill your own order."); return; }
        int give = Math.min(count(p, o.mat), o.remaining);
        if (give <= 0) { plugin.msg(p, "&cYou don't have any plain " + Util.pretty(o.mat) + " to deliver."); return; }
        remove(p, o.mat, give);
        double gross = Util.round2(give * o.price);
        double fee = Util.round2(gross * plugin.getConfig().getDouble("orders.fee-percent", 5) / 100.0);
        plugin.deposit(p.getUniqueId(), gross - fee);
        plugin.record(p.getUniqueId(), "Order: delivered " + give + "x " + Util.pretty(o.mat) + " to " + o.ownerName, gross - fee);
        o.remaining -= give;
        deliveries.computeIfAbsent(o.owner, k -> new HashMap<>()).merge(o.mat, give, Integer::sum);
        if (o.remaining <= 0) orders.remove(o);
        save();
        plugin.msg(p, "&aDelivered &f" + give + "x " + Util.pretty(o.mat) + "&a and earned &f" + plugin.money(gross - fee) + "&a.");
        Player ow = Bukkit.getPlayer(o.owner);
        if (ow != null) plugin.msg(ow, "&a" + p.getName() + " delivered &f" + give + "x " + Util.pretty(o.mat)
                + "&a to your order. Use &f/orders claim&a.");
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != top) return;
        int slot = e.getRawSlot();
        if (Util.navClick(plugin, p, slot)) return;

        if (slot == 45 && h.page > 0) { open(p, h.mine, h.page - 1); return; }
        if (slot == 53) { open(p, h.mine, h.page + 1); return; }
        if (slot == 48) { open(p, !h.mine, 0); return; }
        if (slot == 50) { claim(p); open(p, h.mine, h.page); return; }

        String id = h.slots.get(slot);
        if (id == null) return;
        Order o = find(id);
        if (o == null) { plugin.msg(p, "&cThat order is gone."); open(p, h.mine, h.page); return; }

        if (h.mine) {
            double refund = Util.round2(o.remaining * o.price);
            orders.remove(o);
            plugin.deposit(p.getUniqueId(), refund);
            plugin.record(p.getUniqueId(), "Order cancelled (refund)", refund);
            save();
            plugin.msg(p, "&aOrder cancelled. Refunded &f" + plugin.money(refund) + "&a.");
        } else {
            fill(p, o);
        }
        open(p, h.mine, h.page);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            for (String o : new String[]{"create", "mine", "claim"}) if (o.startsWith(a[0].toLowerCase())) out.add(o);
        } else if (a.length == 2 && a[0].equalsIgnoreCase("create")) {
            String cur = a[1].toLowerCase();
            for (Material m : plugin.pricedMaterials()) {
                String n = m.name().toLowerCase();
                if (n.startsWith(cur)) out.add(n);
                if (out.size() >= 50) break;
            }
        }
        return out;
    }
}
