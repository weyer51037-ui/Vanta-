package dev.vibe.economy;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Per-player settings (toggles) with a menu. Also remembers who claimed the starter kit. */
public final class Settings implements Listener, TabExecutor {

    private static final String[][] DEFS = {
            {"money-tag", "Money above head", "GOLD_INGOT", "Show your money and role above your head."},
            {"hud", "Sidebar HUD", "PAPER", "Show the VantaSMP scoreboard on your screen."},
            {"messages", "Private messages", "WRITABLE_BOOK", "Allow other players to /msg you."},
            {"tpa", "Teleport requests", "ENDER_PEARL", "Allow other players to /tpa you."}
    };
    private static final int[] SLOTS = {10, 12, 14, 16};

    private static final class Holder implements InventoryHolder {
        final Map<Integer, String> keys = new HashMap<>();
        Inventory inv;
        @Override public Inventory getInventory() { return inv; }
    }

    private final VibeEconomy plugin;
    private final File file;
    private final Map<UUID, Set<String>> disabled = new HashMap<>();
    private final Set<UUID> kitClaimed = new HashSet<>();

    public Settings(VibeEconomy plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "settings.yml");
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        if (y.getConfigurationSection("disabled") != null) {
            for (String k : y.getConfigurationSection("disabled").getKeys(false)) {
                try { disabled.put(UUID.fromString(k), new HashSet<>(y.getStringList("disabled." + k))); }
                catch (IllegalArgumentException ignored) { }
            }
        }
        for (String s : y.getStringList("kit-claimed")) {
            try { kitClaimed.add(UUID.fromString(s)); } catch (IllegalArgumentException ignored) { }
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<UUID, Set<String>> e : disabled.entrySet()) {
            if (!e.getValue().isEmpty()) y.set("disabled." + e.getKey(), new ArrayList<>(e.getValue()));
        }
        List<String> kc = new ArrayList<>();
        for (UUID u : kitClaimed) kc.add(u.toString());
        y.set("kit-claimed", kc);
        try { y.save(file); } catch (IOException e) { plugin.getLogger().severe("settings.yml: " + e.getMessage()); }
    }

    /** Settings default to ON. */
    public boolean get(UUID id, String key) {
        Set<String> d = disabled.get(id);
        return d == null || !d.contains(key);
    }

    public void set(UUID id, String key, boolean on) {
        Set<String> d = disabled.computeIfAbsent(id, k -> new HashSet<>());
        if (on) d.remove(key); else d.add(key);
        save();
    }

    public boolean claimedKit(UUID id) { return kitClaimed.contains(id); }

    public void setClaimedKit(UUID id) { kitClaimed.add(id); save(); }

    public void open(Player p) {
        Holder h = new Holder();
        Inventory inv = Bukkit.createInventory(h, 27, ItemSpec.c("&7&lSettings"));
        h.inv = inv;
        for (int i = 0; i < 27; i++) inv.setItem(i, Util.filler());
        for (int i = 0; i < DEFS.length; i++) {
            String[] d = DEFS[i];
            boolean on = get(p.getUniqueId(), d[0]);
            Material m = Material.matchMaterial(d[2]);
            ItemStack icon = Util.button(m == null ? Material.PAPER : m, (on ? "&a" : "&c") + d[1],
                    "&7" + d[3], "", on ? "&aEnabled" : "&cDisabled", "&eClick to toggle");
            inv.setItem(SLOTS[i], icon);
            h.keys.put(SLOTS[i], d[0]);
        }
        inv.setItem(22, Util.button(Material.ARROW, "&7Back to menu"));
        p.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != top) return;
        int slot = e.getRawSlot();
        if (slot == 22) { plugin.shopGui().openMain(p); return; }
        String key = h.keys.get(slot);
        if (key == null) return;
        set(p.getUniqueId(), key, !get(p.getUniqueId(), key));
        if (key.equals("hud") || key.equals("money-tag")) plugin.hud().refreshAll();
        open(p);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (!(s instanceof Player p)) { plugin.msg(s, "&cPlayers only."); return true; }
        open(p);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) { return new ArrayList<>(); }
}
