package dev.vibe.economy;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.entity.FallingBlock;
import org.bukkit.event.block.BlockFadeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.LeavesDecayEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Protects a square area (default 100 blocks in every direction) around spawn. */
public final class SpawnProtection implements Listener {

    private final VibeEconomy plugin;
    private final Map<UUID, Long> lastMsg = new HashMap<>();

    public SpawnProtection(VibeEconomy plugin) { this.plugin = plugin; }

    public boolean inZone(Location l) {
        if (l == null || l.getWorld() == null) return false;
        Location sp = plugin.travel().getSpawn();
        if (sp.getWorld() == null || !l.getWorld().equals(sp.getWorld())) return false;
        int r = plugin.getConfig().getInt("spawn.protection-radius", 100);
        return Math.abs(l.getBlockX() - sp.getBlockX()) <= r && Math.abs(l.getBlockZ() - sp.getBlockZ()) <= r;
    }

    private boolean bypass(Player p) { return p.hasPermission("vibeeconomy.spawn.bypass"); }

    private void deny(Player p) {
        long now = System.currentTimeMillis();
        Long last = lastMsg.get(p.getUniqueId());
        if (last != null && now - last < 2000) return;
        lastMsg.put(p.getUniqueId(), now);
        plugin.msg(p, "&cYou can't do that near spawn.");
    }

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        if (inZone(e.getBlock().getLocation()) && !bypass(e.getPlayer())) { e.setCancelled(true); deny(e.getPlayer()); }
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent e) {
        if (inZone(e.getBlock().getLocation()) && !bypass(e.getPlayer())) { e.setCancelled(true); deny(e.getPlayer()); }
    }

    @EventHandler
    public void onBucketEmpty(PlayerBucketEmptyEvent e) {
        if (inZone(e.getBlock().getLocation()) && !bypass(e.getPlayer())) { e.setCancelled(true); deny(e.getPlayer()); }
    }

    @EventHandler
    public void onBucketFill(PlayerBucketFillEvent e) {
        if (inZone(e.getBlock().getLocation()) && !bypass(e.getPlayer())) { e.setCancelled(true); deny(e.getPlayer()); }
    }

    @EventHandler
    public void onEntityExplode(EntityExplodeEvent e) {
        e.blockList().removeIf(b -> inZone(b.getLocation()));
    }

    @EventHandler
    public void onBlockExplode(BlockExplodeEvent e) {
        e.blockList().removeIf(b -> inZone(b.getLocation()));
    }

    @EventHandler
    public void onBurn(BlockBurnEvent e) {
        if (inZone(e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler
    public void onIgnite(BlockIgniteEvent e) {
        if (!inZone(e.getBlock().getLocation())) return;
        Player p = e.getPlayer();
        if (p == null || !bypass(p)) e.setCancelled(true);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() == Action.PHYSICAL && e.getClickedBlock() != null
                && e.getClickedBlock().getType() == Material.FARMLAND && inZone(e.getClickedBlock().getLocation())) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onHangingBreak(HangingBreakByEntityEvent e) {
        if (!inZone(e.getEntity().getLocation())) return;
        if (e.getRemover() instanceof Player p && bypass(p)) return;
        e.setCancelled(true);
    }

    @EventHandler
    public void onArmorStand(PlayerArmorStandManipulateEvent e) {
        if (inZone(e.getRightClicked().getLocation()) && !bypass(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onPvp(EntityDamageByEntityEvent e) {
        if (!plugin.getConfig().getBoolean("spawn.protect-pvp", true)) return;
        if (!(e.getEntity() instanceof Player victim)) return;
        if (!inZone(victim.getLocation())) return;
        Player damager = null;
        if (e.getDamager() instanceof Player d1) damager = d1;
        else if (e.getDamager() instanceof Projectile pr && pr.getShooter() instanceof Player d2) damager = d2;
        if (damager == null) return;
        if (plugin.duels() != null && plugin.duels().inDuel(victim) && plugin.duels().inDuel(damager)) return;
        e.setCancelled(true);
    }

    @EventHandler
    public void onMobSpawn(CreatureSpawnEvent e) {
        if (!plugin.getConfig().getBoolean("spawn.block-mob-spawns", true)) return;
        if (e.getEntity() instanceof Monster && e.getSpawnReason() == CreatureSpawnEvent.SpawnReason.NATURAL
                && inZone(e.getLocation())) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onEntityChange(EntityChangeBlockEvent e) {
        if (e.getEntity() instanceof FallingBlock) return;
        if (e.getEntity() instanceof Player p && bypass(p)) return;
        if (inZone(e.getBlock().getLocation())) e.setCancelled(true);   // endermen, withers, ravagers, etc.
    }

    @EventHandler
    public void onPistonExtend(BlockPistonExtendEvent e) {
        if (inZone(e.getBlock().getLocation()) || e.getBlocks().stream().anyMatch(b -> inZone(b.getLocation()))) e.setCancelled(true);
    }

    @EventHandler
    public void onPistonRetract(BlockPistonRetractEvent e) {
        if (inZone(e.getBlock().getLocation()) || e.getBlocks().stream().anyMatch(b -> inZone(b.getLocation()))) e.setCancelled(true);
    }

    @EventHandler
    public void onLeaves(LeavesDecayEvent e) {
        if (inZone(e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler
    public void onFade(BlockFadeEvent e) {
        if (inZone(e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler
    public void onExplosionDamage(EntityDamageEvent e) {
        if (!plugin.getConfig().getBoolean("spawn.protect-pvp", true)) return;
        if (!(e.getEntity() instanceof Player p) || !inZone(p.getLocation())) return;
        EntityDamageEvent.DamageCause c = e.getCause();
        if (c == EntityDamageEvent.DamageCause.BLOCK_EXPLOSION || c == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION) {
            e.setCancelled(true);   // end crystals, TNT, respawn anchors can't hurt anyone at spawn
        }
    }
}
