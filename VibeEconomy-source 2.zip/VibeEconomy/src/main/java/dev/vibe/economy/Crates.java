package dev.vibe.economy;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/** 3 key types, 5 crates, physical crate blocks placed by admins, previews and key-all. */
@SuppressWarnings("deprecation")
public final class Crates implements Listener, TabExecutor {

    public static final String[] COMMANDS = {"crate"};

    private static final class KeyType {
        final String id, name; final Material mat;
        KeyType(String id, String name, Material mat) { this.id = id; this.name = name; this.mat = mat; }
    }

    private static final class Crate {
        final String id, name, key; final Material block;
        final List<ItemSpec> loot = new ArrayList<>();
        int total;
        Crate(String id, String name, String key, Material block) { this.id = id; this.name = name; this.key = key; this.block = block; }
    }

    private static final class Holder implements InventoryHolder {
        final Map<Integer, String> slots = new HashMap<>();
        Inventory inv;
        @Override public Inventory getInventory() { return inv; }
    }

    private final VibeEconomy plugin;
    private final File cfgFile, placedFile;
    private final Map<String, KeyType> keys = new LinkedHashMap<>();
    private final Map<String, Crate> crates = new LinkedHashMap<>();
    private final Map<String, String> placed = new HashMap<>();   // "world:x:y:z" -> crate id
    private final Map<String, UUID> holograms = new HashMap<>();
    private final NamespacedKey keyTag, legacyTag;
    private final Random rnd = new Random();

    public Crates(VibeEconomy plugin) {
        this.plugin = plugin;
        this.cfgFile = new File(plugin.getDataFolder(), "crates.yml");
        this.placedFile = new File(plugin.getDataFolder(), "crate-locations.yml");
        this.keyTag = new NamespacedKey(plugin, "crate_key");
        this.legacyTag = new NamespacedKey(plugin, "vanta_key");
        reload();
        loadPlaced();
        Bukkit.getScheduler().runTaskLater(plugin, this::refreshHolograms, 40L);
    }

    // ---------------------------------------------------------------- config

    public void reload() {
        if (!cfgFile.exists()) plugin.saveResource("crates.yml", false);
        YamlConfiguration y = YamlConfiguration.loadConfiguration(cfgFile);
        keys.clear();
        crates.clear();
        ConfigurationSection ks = y.getConfigurationSection("keys");
        if (ks != null) {
            for (String id : ks.getKeys(false)) {
                ConfigurationSection s = ks.getConfigurationSection(id);
                if (s == null) continue;
                Material m = Material.matchMaterial(s.getString("material", "TRIPWIRE_HOOK"));
                keys.put(id.toLowerCase(Locale.ROOT), new KeyType(id.toLowerCase(Locale.ROOT), s.getString("name", id), m == null ? Material.TRIPWIRE_HOOK : m));
            }
        }
        ConfigurationSection cs = y.getConfigurationSection("crates");
        if (cs != null) {
            for (String id : cs.getKeys(false)) {
                ConfigurationSection s = cs.getConfigurationSection(id);
                if (s == null) continue;
                Material block = Material.matchMaterial(s.getString("block", "CHEST"));
                Crate c = new Crate(id.toLowerCase(Locale.ROOT), s.getString("name", id), s.getString("key", "vanta").toLowerCase(Locale.ROOT),
                        (block == null || !block.isBlock()) ? Material.CHEST : block);
                ConfigurationSection ls = s.getConfigurationSection("loot");
                if (ls != null) {
                    for (String lid : ls.getKeys(false)) {
                        ConfigurationSection l = ls.getConfigurationSection(lid);
                        if (l == null) continue;
                        ItemSpec spec = new ItemSpec(lid, l, "money");
                        c.loot.add(spec);
                        c.total += spec.weight;
                    }
                }
                crates.put(c.id, c);
            }
        }
        if (!holograms.isEmpty()) refreshHolograms();
    }

    private String lkey(Location l) {
        return l.getWorld().getName() + ":" + l.getBlockX() + ":" + l.getBlockY() + ":" + l.getBlockZ();
    }

    private Location fromKey(String key) {
        String[] sp = key.split(":");
        if (sp.length != 4) return null;
        World w = Bukkit.getWorld(sp[0]);
        if (w == null) return null;
        try { return new Location(w, Integer.parseInt(sp[1]), Integer.parseInt(sp[2]), Integer.parseInt(sp[3])); }
        catch (NumberFormatException e) { return null; }
    }

    private void loadPlaced() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(placedFile);
        for (String s : y.getStringList("placed")) {
            int i = s.lastIndexOf('=');
            if (i > 0) placed.put(s.substring(0, i), s.substring(i + 1));
        }
    }

    private void savePlaced() {
        YamlConfiguration y = new YamlConfiguration();
        List<String> out = new ArrayList<>();
        for (Map.Entry<String, String> e : placed.entrySet()) out.add(e.getKey() + "=" + e.getValue());
        y.set("placed", out);
        try { y.save(placedFile); } catch (IOException e) { plugin.getLogger().severe("crate-locations.yml: " + e.getMessage()); }
    }

    // ---------------------------------------------------------------- holograms

    private void removeHolo(String key) {
        UUID id = holograms.remove(key);
        if (id != null) {
            Entity e = Bukkit.getEntity(id);
            if (e != null) e.remove();
        }
    }

    private void spawnHolo(String key, Crate c) {
        Location base = fromKey(key);
        if (base == null) return;
        KeyType kt = keys.get(c.key);
        String keyName = kt == null ? c.key : kt.name;
        Location at = base.clone().add(0.5, 1.7, 0.5);
        TextDisplay td = base.getWorld().spawn(at, TextDisplay.class, t -> {
            t.setText(ItemSpec.c(c.name) + "\n" + ItemSpec.c("&7Key: " + keyName) + "\n" + ItemSpec.c("&eRight-click with key") + "\n" + ItemSpec.c("&7Left-click to preview"));
            t.setBillboard(Display.Billboard.CENTER);
            t.setPersistent(false);
        });
        holograms.put(key, td.getUniqueId());
    }

    public void refreshHolograms() {
        for (String k : new ArrayList<>(holograms.keySet())) removeHolo(k);
        for (Map.Entry<String, String> e : placed.entrySet()) {
            Crate c = crates.get(e.getValue());
            if (c != null) spawnHolo(e.getKey(), c);
        }
    }

    public void shutdown() {
        for (String k : new ArrayList<>(holograms.keySet())) removeHolo(k);
    }

    // ---------------------------------------------------------------- keys

    public ItemStack createKey(String type, int amount) {
        KeyType kt = keys.get(type);
        if (kt == null) return null;
        ItemStack it = new ItemStack(kt.mat, Math.max(1, amount));
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(ItemSpec.c(kt.name));
        List<String> names = new ArrayList<>();
        for (Crate c : crates.values()) if (c.key.equals(type)) names.add(c.name);
        List<String> lore = new ArrayList<>();
        lore.add(ItemSpec.c("&7Right-click a crate at spawn:"));
        for (String n : names) lore.add(ItemSpec.c(" &8- " + n));
        meta.setLore(lore);
        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(keyTag, PersistentDataType.STRING, type);
        it.setItemMeta(meta);
        return it;
    }

    /** Returns the key type of an item, or null if it isn't a key. */
    public String keyType(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        var pdc = it.getItemMeta().getPersistentDataContainer();
        String t = pdc.get(keyTag, PersistentDataType.STRING);
        if (t != null) return t;
        if (pdc.has(legacyTag, PersistentDataType.BYTE)) return "vanta";
        return null;
    }

    public boolean hasKeyType(String id) { return keys.containsKey(id == null ? "" : id.toLowerCase(Locale.ROOT)); }

    public String keyName(String id) {
        KeyType kt = keys.get(id);
        return kt == null ? id : kt.name;
    }

    public void giveKey(Player p, String type, int amount) {
        ItemStack it = createKey(type.toLowerCase(Locale.ROOT), amount);
        if (it != null) plugin.giveItem(p, it);
    }

    public void keyAll(String type, int amount, String by) {
        KeyType kt = keys.get(type.toLowerCase(Locale.ROOT));
        if (kt == null) return;
        for (Player t : Bukkit.getOnlinePlayers()) {
            giveKey(t, kt.id, amount);
            t.playSound(t.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
        }
        Bukkit.broadcastMessage(ItemSpec.c("&5&l[KEY ALL] &d" + by + " &fgave everyone online &d" + amount + "x &f" + kt.name + "&f!"));
    }

    // ---------------------------------------------------------------- opening + previews

    private ItemSpec roll(Crate c) {
        int r = rnd.nextInt(Math.max(1, c.total));
        for (ItemSpec s : c.loot) {
            r -= s.weight;
            if (r < 0) return s;
        }
        return c.loot.get(0);
    }

    private void open(Player p, Crate c, ItemStack keyItem) {
        if (c.loot.isEmpty()) { plugin.msg(p, "&cThis crate has no loot configured."); return; }
        keyItem.setAmount(keyItem.getAmount() - 1);
        ItemSpec won = roll(c);
        plugin.grant(p, won);
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.4f);
        plugin.msg(p, "&5&l[CRATE] &fYou opened the " + c.name + "&f and got &d" + won.label() + "&f!");
        if (won.broadcast) {
            Bukkit.broadcastMessage(ItemSpec.c("&5&l[CRATE] &d" + p.getName() + " &fwon &d" + won.label() + " &ffrom the " + c.name + "&f!"));
        }
    }

    public void openPreview(Player p, Crate c) {
        Holder h = new Holder();
        Inventory inv = Bukkit.createInventory(h, 54, ItemSpec.c(c.name + " &8- Preview"));
        h.inv = inv;
        int i = 0;
        for (ItemSpec s : c.loot) {
            if (i >= 45) break;
            ItemStack icon = s.build();
            ItemMeta m = icon.getItemMeta();
            List<String> lore = m.hasLore() ? new ArrayList<>(m.getLore()) : new ArrayList<>();
            lore.add("");
            lore.add(ItemSpec.c("&7Chance: &f" + String.format(Locale.US, "%.1f%%", s.weight * 100.0 / Math.max(1, c.total))));
            m.setLore(lore);
            icon.setItemMeta(m);
            inv.setItem(i++, icon);
        }
        for (int s = 45; s < 54; s++) inv.setItem(s, Util.filler());
        KeyType kt = keys.get(c.key);
        inv.setItem(49, Util.button(Material.TRIPWIRE_HOOK, "&eRequires: " + (kt == null ? c.key : kt.name), "&7Right-click the crate with the key."));
        inv.setItem(45, Util.button(Material.ARROW, "&7All crates"));
        h.slots.put(45, "__list");
        p.openInventory(inv);
    }

    public void openList(Player p) {
        Holder h = new Holder();
        Inventory inv = Bukkit.createInventory(h, 27, ItemSpec.c("&d&lCrates"));
        h.inv = inv;
        for (int i = 0; i < 27; i++) inv.setItem(i, Util.filler());
        int slot = 11;
        for (Crate c : crates.values()) {
            if (slot > 15) break;
            KeyType kt = keys.get(c.key);
            inv.setItem(slot, Util.button(c.block, c.name, "&7Key: " + (kt == null ? c.key : kt.name), "&7Rewards: &f" + c.loot.size(), "", "&eClick to preview"));
            h.slots.put(slot, c.id);
            slot++;
        }
        p.openInventory(inv);
    }

    @EventHandler
    public void onGuiClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != top) return;
        String id = h.slots.get(e.getRawSlot());
        if (id == null) return;
        if (id.equals("__list")) { openList(p); return; }
        Crate c = crates.get(id);
        if (c != null) openPreview(p, c);
    }

    @EventHandler
    public void onGuiDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    // ---------------------------------------------------------------- crate blocks

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Action a = e.getAction();
        Player p = e.getPlayer();
        if (a == Action.RIGHT_CLICK_BLOCK || a == Action.LEFT_CLICK_BLOCK) {
            Block b = e.getClickedBlock();
            String cid = b == null ? null : placed.get(lkey(b.getLocation()));
            if (cid != null) {
                e.setCancelled(true);
                Crate c = crates.get(cid);
                if (c == null) return;
                if (a == Action.LEFT_CLICK_BLOCK) { openPreview(p, c); return; }
                ItemStack hand = e.getItem();
                String kt = keyType(hand);
                if (kt != null && kt.equals(c.key)) {
                    open(p, c, hand);
                } else {
                    plugin.msg(p, "&cYou need a " + keyName(c.key) + "&c to open this crate.");
                    openPreview(p, c);
                }
                return;
            }
        }
        if ((a == Action.RIGHT_CLICK_AIR || a == Action.RIGHT_CLICK_BLOCK) && keyType(e.getItem()) != null) {
            e.setCancelled(true);
            plugin.msg(p, "&7Use this key on a crate at spawn.");
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onBreak(BlockBreakEvent e) {
        String cid = placed.get(lkey(e.getBlock().getLocation()));
        if (cid == null) return;
        e.setCancelled(true);
        Crate c = crates.get(cid);
        if (c != null) openPreview(e.getPlayer(), c);
    }

    @EventHandler
    public void onEntityExplode(EntityExplodeEvent e) {
        e.blockList().removeIf(b -> placed.containsKey(lkey(b.getLocation())));
    }

    @EventHandler
    public void onBlockExplode(BlockExplodeEvent e) {
        e.blockList().removeIf(b -> placed.containsKey(lkey(b.getLocation())));
    }

    @EventHandler
    public void onPistonExtend(BlockPistonExtendEvent e) {
        for (Block b : e.getBlocks()) if (placed.containsKey(lkey(b.getLocation()))) { e.setCancelled(true); return; }
    }

    @EventHandler
    public void onPistonRetract(BlockPistonRetractEvent e) {
        for (Block b : e.getBlocks()) if (placed.containsKey(lkey(b.getLocation()))) { e.setCancelled(true); return; }
    }

    // ---------------------------------------------------------------- commands

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (a.length == 0 || a[0].equalsIgnoreCase("list")) {
            if (!(s instanceof Player p)) { plugin.msg(s, "&cPlayers only."); return true; }
            openList(p);
            return true;
        }
        String sub = a[0].toLowerCase();
        if (sub.equals("preview")) {
            if (!(s instanceof Player p)) { plugin.msg(s, "&cPlayers only."); return true; }
            Crate c = a.length >= 2 ? crates.get(a[1].toLowerCase()) : null;
            if (c == null) { plugin.msg(p, "&cUsage: /crate preview <" + String.join("|", crates.keySet()) + ">"); return true; }
            openPreview(p, c);
            return true;
        }
        if (!s.hasPermission("vibeeconomy.admin")) { plugin.msg(s, "&cNo permission."); return true; }
        switch (sub) {
            case "set": return cmdSet(s, a);
            case "remove": return cmdRemove(s);
            case "give": return cmdGive(s, a);
            case "drill": return cmdDrill(s, a);
            case "reload":
                reload();
                plugin.msg(s, "&aCrates reloaded.");
                return true;
            default:
                plugin.msg(s, "&6/crate set <crate> &7- turn the block you're looking at into a crate\n"
                        + "&6/crate remove &7- remove the crate you're looking at\n"
                        + "&6/crate give <player> <key> [amount] &7- give keys (" + String.join("|", keys.keySet()) + ")\n"
                        + "&6/crate drill <player> [hours] &7- give a Vanta Drill\n"
                        + "&6/crate reload &7| &6/crate list &7| &6/crate preview <crate>");
                return true;
        }
    }

    private boolean cmdSet(CommandSender s, String[] a) {
        if (!(s instanceof Player p)) { plugin.msg(s, "&cPlayers only."); return true; }
        Crate c = a.length >= 2 ? crates.get(a[1].toLowerCase()) : null;
        if (c == null) { plugin.msg(p, "&cUsage: /crate set <" + String.join("|", crates.keySet()) + ">"); return true; }
        Block b = p.getTargetBlockExact(6);
        if (b == null) { plugin.msg(p, "&cLook at the block you want to turn into a crate (within 6 blocks)."); return true; }
        String key = lkey(b.getLocation());
        removeHolo(key);
        b.setType(c.block);
        placed.put(key, c.id);
        savePlaced();
        spawnHolo(key, c);
        plugin.msg(p, "&aThat block is now the " + c.name + "&a.");
        return true;
    }

    private boolean cmdRemove(CommandSender s) {
        if (!(s instanceof Player p)) { plugin.msg(s, "&cPlayers only."); return true; }
        Block b = p.getTargetBlockExact(6);
        String key = b == null ? null : lkey(b.getLocation());
        if (key == null || !placed.containsKey(key)) { plugin.msg(p, "&cLook at a crate to remove it."); return true; }
        placed.remove(key);
        removeHolo(key);
        savePlaced();
        b.setType(Material.AIR);
        plugin.msg(p, "&aCrate removed.");
        return true;
    }

    private boolean cmdGive(CommandSender s, String[] a) {
        if (a.length < 3) { plugin.msg(s, "&cUsage: /crate give <player> <" + String.join("|", keys.keySet()) + "> [amount]"); return true; }
        Player t = Bukkit.getPlayerExact(a[1]);
        if (t == null) { plugin.msg(s, "&cThat player must be online."); return true; }
        String type = a[2].toLowerCase();
        if (!keys.containsKey(type)) { plugin.msg(s, "&cUnknown key. Keys: " + String.join(", ", keys.keySet())); return true; }
        int amount = 1;
        if (a.length >= 4) {
            try { amount = Integer.parseInt(a[3]); } catch (NumberFormatException e) { plugin.msg(s, "&cInvalid amount."); return true; }
        }
        if (amount < 1 || amount > 64) { plugin.msg(s, "&cAmount must be 1-64."); return true; }
        giveKey(t, type, amount);
        plugin.msg(s, "&aGave " + t.getName() + " " + amount + "x " + keyName(type) + "&a.");
        plugin.msg(t, "&5You received &d" + amount + "x &f" + keyName(type) + "&5.");
        return true;
    }

    private boolean cmdDrill(CommandSender s, String[] a) {
        if (a.length < 2) { plugin.msg(s, "&cUsage: /crate drill <player> [hours]"); return true; }
        Player t = Bukkit.getPlayerExact(a[1]);
        if (t == null) { plugin.msg(s, "&cThat player must be online."); return true; }
        int hours = 24;
        if (a.length >= 3) {
            try { hours = Math.max(1, Math.min(720, Integer.parseInt(a[2]))); } catch (NumberFormatException e) { plugin.msg(s, "&cInvalid hours."); return true; }
        }
        plugin.giveItem(t, plugin.drills().create(hours));
        plugin.msg(s, "&aGave " + t.getName() + " a Vanta Drill (" + hours + "h).");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        List<String> out = new ArrayList<>();
        String cur = a.length > 0 ? a[a.length - 1].toLowerCase() : "";
        if (a.length == 1) {
            for (String o : new String[]{"list", "preview", "set", "remove", "give", "drill", "reload"}) if (o.startsWith(cur)) out.add(o);
        } else if (a.length == 2 && (a[0].equalsIgnoreCase("set") || a[0].equalsIgnoreCase("preview"))) {
            for (String id : crates.keySet()) if (id.startsWith(cur)) out.add(id);
        } else if (a.length == 2 && (a[0].equalsIgnoreCase("give") || a[0].equalsIgnoreCase("drill"))) {
            for (Player p : Bukkit.getOnlinePlayers()) if (p.getName().toLowerCase().startsWith(cur)) out.add(p.getName());
        } else if (a.length == 3 && a[0].equalsIgnoreCase("give")) {
            for (String id : keys.keySet()) if (id.startsWith(cur)) out.add(id);
        }
        return out;
    }
}
