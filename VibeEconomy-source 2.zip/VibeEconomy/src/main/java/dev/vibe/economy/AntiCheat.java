package dev.vibe.economy;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Shulker;
import org.bukkit.entity.Vehicle;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerAnimationType;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerRiptideEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerVelocityEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * A deliberately conservative built-in anti-cheat. It only reacts to clear evidence:
 *  - checks pause when the server lags (low TPS) or a player's ping is very high
 *  - every flag adds "violation level" that decays over time, so one odd moment never punishes anyone
 *  - nothing happens below the alert threshold; setbacks/kicks need a long streak of violations
 *  - staff, creative, flying, gliding, vehicles, knockback, teleports and special blocks are skipped
 *  - Bedrock (Floodgate) players are exempt
 * Checks: reach, aim (hitting behind you), multi-target hits, autoclicker, fly, speed.
 * For a stronger, dedicated solution you can run a plugin like Grim alongside this.
 */
@SuppressWarnings("deprecation")
public final class AntiCheat implements Listener, TabExecutor {

    private static final Set<Material> SPECIAL = new HashSet<>();
    private static final Set<Material> ICY = new HashSet<>();
    static {
        for (String n : new String[]{"LADDER", "VINE", "SCAFFOLDING", "COBWEB", "SWEET_BERRY_BUSH", "HONEY_BLOCK", "SLIME_BLOCK",
                "POWDER_SNOW", "BUBBLE_COLUMN", "WEEPING_VINES", "WEEPING_VINES_PLANT", "TWISTING_VINES", "TWISTING_VINES_PLANT",
                "CAVE_VINES", "CAVE_VINES_PLANT", "WATER", "LAVA", "KELP", "KELP_PLANT", "SEAGRASS", "TALL_SEAGRASS",
                "BIG_DRIPLEAF", "SMALL_DRIPLEAF", "MOVING_PISTON", "PISTON_HEAD"}) {
            Material m = Material.matchMaterial(n);
            if (m != null) SPECIAL.add(m);
        }
        for (String n : new String[]{"ICE", "PACKED_ICE", "BLUE_ICE", "FROSTED_ICE", "SLIME_BLOCK"}) {
            Material m = Material.matchMaterial(n);
            if (m != null) ICY.add(m);
        }
    }

    private static final class Data {
        final Map<String, Double> vl = new HashMap<>();
        final LinkedList<String> log = new LinkedList<>();
        long joined = System.currentTimeMillis(), lastTp, lastVel, lastDamage, lastAlert, lastFlag;
        Location last, lastSafe;
        int airSamples, hover, rise;
        long cpsStart; int cps, cpsHigh;
        UUID lastTarget; long lastHit;
    }

    private final VibeEconomy plugin;
    private final File logFile;
    private final Map<UUID, Data> data = new HashMap<>();
    private final Set<UUID> alertsOff = new HashSet<>();
    private final Set<UUID> exempt = new HashSet<>();

    public AntiCheat(VibeEconomy plugin) {
        this.plugin = plugin;
        this.logFile = new File(plugin.getDataFolder(), "anticheat.log");
        for (Player p : Bukkit.getOnlinePlayers()) data(p);
        Bukkit.getScheduler().runTaskTimer(plugin, this::sample, 100L, 5L);
        Bukkit.getScheduler().runTaskTimer(plugin, this::decay, 400L, 400L);
    }

    private boolean enabled() { return plugin.getConfig().getBoolean("anticheat.enabled", true); }

    private Data data(Player p) { return data.computeIfAbsent(p.getUniqueId(), k -> new Data()); }

    private static String fmt(double d) { return String.format(Locale.US, "%.2f", d); }

    // ---------------------------------------------------------------- gates (avoid false positives)

    private boolean unstable() {
        try { return Bukkit.getTPS()[0] < plugin.getConfig().getDouble("anticheat.min-tps", 18.0); }
        catch (Throwable t) { return false; }
    }

    private boolean skip(Player p) {
        if (!enabled()) return true;
        if (exempt.contains(p.getUniqueId()) || p.hasPermission("vibeeconomy.ac.bypass")) return true;
        String prefix = plugin.getConfig().getString("anticheat.bedrock-prefix", ".");
        if (!prefix.isEmpty() && p.getName().startsWith(prefix)) return true;
        GameMode gm = p.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return true;
        if (p.getAllowFlight() || p.isFlying()) return true;
        if (p.getPing() > plugin.getConfig().getInt("anticheat.max-ping", 350)) return true;
        return System.currentTimeMillis() - data(p).joined < 5000;
    }

    private boolean recent(Data d, long now) {
        return now - d.lastTp < 2500 || now - d.lastVel < 2500 || now - d.lastDamage < 1500;
    }

    private boolean special(Player p, Location l) {
        if (p.isInsideVehicle() || p.isGliding() || p.isRiptiding() || p.isSwimming() || p.isInWater()
                || p.isInLava() || p.isClimbing()) return true;
        for (PotionEffect ef : p.getActivePotionEffects()) {
            PotionEffectType t = ef.getType();
            if (t.equals(PotionEffectType.LEVITATION) || t.equals(PotionEffectType.SLOW_FALLING)
                    || t.equals(PotionEffectType.JUMP_BOOST)) return true;
        }
        World w = l.getWorld();
        int bx = l.getBlockX(), by = l.getBlockY(), bz = l.getBlockZ();
        for (int dx = -1; dx <= 1; dx++)
            for (int dy = -1; dy <= 1; dy++)
                for (int dz = -1; dz <= 1; dz++)
                    if (SPECIAL.contains(w.getBlockAt(bx + dx, by + dy, bz + dz).getType())) return true;
        return false;
    }

    private boolean nearGround(Location l) {
        World w = l.getWorld();
        double[] off = {-0.3, 0, 0.3};
        for (double dx : off) {
            for (double dz : off) {
                Block b = new Location(w, l.getX() + dx, l.getY() - 0.3, l.getZ() + dz).getBlock();
                if (!b.isPassable()) return true;
            }
        }
        return false;
    }

    private boolean standingOnEntity(Player p) {
        for (Entity en : p.getNearbyEntities(1.2, 2.0, 1.2)) {
            if (en instanceof Vehicle || en instanceof Shulker) return true;
        }
        return false;
    }

    private boolean icyBelow(Location l) {
        World w = l.getWorld();
        for (int dy = -2; dy <= 0; dy++) {
            if (ICY.contains(w.getBlockAt(l.getBlockX(), l.getBlockY() + dy, l.getBlockZ()).getType())) return true;
        }
        return false;
    }

    // ---------------------------------------------------------------- flagging + punishment

    private double flag(Player p, String check, double amount, String detail) {
        Data d = data(p);
        long now = System.currentTimeMillis();
        double v = d.vl.merge(check, amount, Double::sum);
        d.lastFlag = now;
        String tps;
        try { tps = fmt(Bukkit.getTPS()[0]); } catch (Throwable t) { tps = "?"; }
        String line = "[" + check + " vl " + fmt(v) + "] " + detail + " (ping " + p.getPing() + "ms, tps " + tps + ")";
        d.log.addFirst(new java.text.SimpleDateFormat("HH:mm:ss").format(new java.util.Date()) + " " + line);
        while (d.log.size() > 40) d.log.removeLast();

        double alertVl = plugin.getConfig().getDouble("anticheat.alert-vl", 6);
        if (v >= alertVl && now - d.lastAlert > 3000) {
            d.lastAlert = now;
            String msg = "&c&l[AC] &f" + p.getName() + " &7failed &c" + check + " &7(vl &f" + fmt(v) + "&7) &8" + detail + " &8| " + p.getPing() + "ms";
            for (Player staff : Bukkit.getOnlinePlayers()) {
                if (staff.hasPermission("vibeeconomy.ac.alerts") && !alertsOff.contains(staff.getUniqueId())) plugin.msg(staff, msg);
            }
            plugin.getLogger().info("[AC] " + p.getName() + " " + line);
            appendLog(p.getName() + " " + line);
        }

        // setbacks only for movement cheats, and only after a long run of violations
        if ((check.equals("fly") || check.equals("speed")) && v >= plugin.getConfig().getDouble("anticheat.setback-vl", 12)
                && d.lastSafe != null && d.lastSafe.getWorld() == p.getWorld()) {
            d.lastTp = now;
            p.teleport(d.lastSafe);
            d.airSamples = 0; d.hover = 0; d.rise = 0;
        }
        if (v >= plugin.getConfig().getDouble("anticheat.kick-vl", 30)) {
            d.vl.put(check, 0.0);
            p.kickPlayer(ItemSpec.c("&cDisconnected by anti-cheat: unfair advantage detected (" + check + ").\n&7If this is a mistake, contact staff."));
            return v;
        }
        String cmd = plugin.getConfig().getString("anticheat.ban-command", "");
        if (!cmd.isEmpty() && v >= plugin.getConfig().getDouble("anticheat.ban-vl", 60)) {
            d.vl.put(check, 0.0);
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("%player%", p.getName()).replace("%check%", check));
        }
        return v;
    }

    private void appendLog(String line) {
        try {
            String stamp = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date());
            Files.writeString(logFile.toPath(), stamp + " " + line + "\n", StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException ignored) { }
    }

    private void decay() {
        double amt = plugin.getConfig().getDouble("anticheat.decay-per-20s", 1.0);
        for (Data d : data.values()) {
            d.vl.replaceAll((k, v) -> Math.max(0, v - amt));
            d.vl.values().removeIf(v -> v <= 0);
        }
    }

    // ---------------------------------------------------------------- combat checks

    @EventHandler(priority = EventPriority.HIGH)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player a)) return;
        if (e.getCause() != EntityDamageEvent.DamageCause.ENTITY_ATTACK) return;
        Entity victim = e.getEntity();
        if (victim.equals(a) || skip(a) || unstable()) return;
        Data d = data(a);
        long now = System.currentTimeMillis();

        // reach
        Location eye = a.getEyeLocation();
        BoundingBox bb = victim.getBoundingBox();
        double dx = Math.max(Math.max(bb.getMinX() - eye.getX(), 0), eye.getX() - bb.getMaxX());
        double dy = Math.max(Math.max(bb.getMinY() - eye.getY(), 0), eye.getY() - bb.getMaxY());
        double dz = Math.max(Math.max(bb.getMinZ() - eye.getZ(), 0), eye.getZ() - bb.getMaxZ());
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        double base = 3.0;
        AttributeInstance ai = a.getAttribute(Attribute.ENTITY_INTERACTION_RANGE);
        if (ai != null) base = ai.getValue();
        double allowed = base + plugin.getConfig().getDouble("anticheat.reach-tolerance", 1.3)
                + Math.min(0.8, a.getPing() / 1000.0 * 5.0);
        if (dist > allowed) {
            double hardLimit = plugin.getConfig().getDouble("anticheat.reach-hard-limit", 5.5);
            boolean hard = dist > hardLimit;
            double v = flag(a, "reach", hard ? 2 : 1, "dist " + fmt(dist) + " allowed " + fmt(allowed));
            // only block the hit when it is clearly impossible, or the player is already flagged
            if (hard || (v >= plugin.getConfig().getDouble("anticheat.alert-vl", 6) && dist - allowed > 0.5)) e.setCancelled(true);
        }

        // aim: hitting something well behind where you are looking
        if (dist > 2.0) {
            Vector to = bb.getCenter().subtract(eye.toVector());
            if (to.lengthSquared() > 0.01) {
                double ang = Math.toDegrees(eye.getDirection().angle(to));
                if (ang > 105) flag(a, "aim", 1, "angle " + fmt(ang) + " dist " + fmt(dist));
            }
        }

        // multi-target: two different entities in the same tick (sweeping uses another damage cause)
        if (d.lastTarget != null && !d.lastTarget.equals(victim.getUniqueId()) && now - d.lastHit <= 55) {
            flag(a, "multi", 0.5, "two targets in one tick");
        }
        d.lastTarget = victim.getUniqueId();
        d.lastHit = now;
    }

    @EventHandler
    public void onSwing(PlayerAnimationEvent e) {
        if (e.getAnimationType() != PlayerAnimationType.ARM_SWING) return;
        Player p = e.getPlayer();
        if (skip(p)) return;
        Data d = data(p);
        long now = System.currentTimeMillis();
        if (d.cpsStart == 0) d.cpsStart = now;
        d.cps++;
        if (now - d.cpsStart >= 1000) {
            int max = plugin.getConfig().getInt("anticheat.max-cps", 25);
            if (d.cps > max && !unstable()) {
                d.cpsHigh++;
                if (d.cpsHigh >= 2) flag(p, "clicker", 1, d.cps + " clicks/s");
            } else {
                d.cpsHigh = 0;
            }
            d.cps = 0;
            d.cpsStart = now;
        }
    }

    // ---------------------------------------------------------------- movement checks (sampled every 5 ticks)

    private void resetMove(Data d) { d.airSamples = 0; d.hover = 0; d.rise = 0; }

    private double allowedSpeed(Player p, Location cur) {
        double mult = 1.0;
        PotionEffect speed = p.getPotionEffect(PotionEffectType.SPEED);
        if (speed != null) mult += 0.2 * (speed.getAmplifier() + 1);
        mult *= Math.max(1.0, p.getWalkSpeed() / 0.2);
        if (icyBelow(cur)) mult *= 2.0;
        return 1.8 * mult + 0.9;   // blocks per 5 ticks: a sprint jump is about 1.8
    }

    private void sample() {
        if (!enabled()) return;
        boolean unstable = unstable();
        long now = System.currentTimeMillis();
        for (Player p : Bukkit.getOnlinePlayers()) {
            Data d = data(p);
            Location cur = p.getLocation();
            Location last = d.last;
            d.last = cur;
            if (last == null || last.getWorld() != cur.getWorld()) { resetMove(d); continue; }
            if (unstable || skip(p) || recent(d, now) || special(p, cur)) { resetMove(d); continue; }

            if (nearGround(cur)) {
                resetMove(d);
                if (now - d.lastFlag > 10_000) d.lastSafe = cur;
            } else {
                d.airSamples++;
                double dy = cur.getY() - last.getY();
                if (d.airSamples >= 4 && Math.abs(dy) < 0.04 && !standingOnEntity(p)) d.hover++;
                else if (dy < -0.1) d.hover = Math.max(0, d.hover - 2);
                if (dy > 0.05 && d.airSamples >= 3) d.rise++; else d.rise = Math.max(0, d.rise - 1);
                if (d.hover >= 6) { flag(p, "fly", 1.5, "hovering in the air"); d.hover = 4; }
                if (d.rise >= 4) { flag(p, "fly", 2, "rising without a jump"); d.rise = 2; }
            }

            double dxz = Math.hypot(cur.getX() - last.getX(), cur.getZ() - last.getZ());
            double allowed = allowedSpeed(p, cur);
            if (dxz > allowed) flag(p, "speed", 1, fmt(dxz) + " blocks/5t (max " + fmt(allowed) + ")");
        }
    }

    // ---------------------------------------------------------------- bookkeeping events

    @EventHandler
    public void onJoin(PlayerJoinEvent e) { Data d = data(e.getPlayer()); d.joined = System.currentTimeMillis(); d.last = null; d.lastSafe = null; }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) { data.remove(e.getPlayer().getUniqueId()); }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent e) { Data d = data(e.getPlayer()); d.lastTp = System.currentTimeMillis(); resetMove(d); d.last = null; }

    @EventHandler
    public void onWorld(PlayerChangedWorldEvent e) { Data d = data(e.getPlayer()); d.lastTp = System.currentTimeMillis(); resetMove(d); d.last = null; d.lastSafe = null; }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) { Data d = data(e.getPlayer()); d.lastTp = System.currentTimeMillis() + 1500; resetMove(d); d.last = null; d.lastSafe = null; }

    @EventHandler
    public void onVelocity(PlayerVelocityEvent e) { data(e.getPlayer()).lastVel = System.currentTimeMillis(); }

    @EventHandler
    public void onRiptide(PlayerRiptideEvent e) { data(e.getPlayer()).lastVel = System.currentTimeMillis() + 3000; }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p) data(p).lastDamage = System.currentTimeMillis();
    }

    // ---------------------------------------------------------------- commands

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (a.length >= 1 && a[0].equalsIgnoreCase("alerts")) {
            if (!(s instanceof Player p)) { plugin.msg(s, "&cPlayers only."); return true; }
            if (!p.hasPermission("vibeeconomy.ac.alerts")) { plugin.msg(s, "&cNo permission."); return true; }
            if (alertsOff.remove(p.getUniqueId())) plugin.msg(p, "&aAnti-cheat alerts &fon&a.");
            else { alertsOff.add(p.getUniqueId()); plugin.msg(p, "&7Anti-cheat alerts &coff&7."); }
            return true;
        }
        if (!s.hasPermission("vibeeconomy.admin")) { plugin.msg(s, "&cNo permission."); return true; }
        if (a.length == 0) {
            plugin.msg(s, "&6/ac alerts &7- toggle alerts\n&6/ac status <player> &7- violation levels\n&6/ac logs <player> &7- recent flags\n"
                    + "&6/ac reset <player> &7- clear violations\n&6/ac exempt <player> &7- toggle exemption (until restart)");
            return true;
        }
        if (a.length < 2) { plugin.msg(s, "&cSpecify a player."); return true; }
        Player t = Bukkit.getPlayerExact(a[1]);
        if (t == null) { plugin.msg(s, "&cThat player isn't online."); return true; }
        Data d = data(t);
        switch (a[0].toLowerCase()) {
            case "status" -> {
                StringBuilder sb = new StringBuilder("&6" + t.getName() + " &7violations:");
                if (d.vl.isEmpty()) sb.append(" &anone");
                for (Map.Entry<String, Double> e : d.vl.entrySet()) sb.append("\n&e").append(e.getKey()).append(" &7= &f").append(fmt(e.getValue()));
                sb.append("\n&8ping ").append(t.getPing()).append("ms").append(exempt.contains(t.getUniqueId()) ? " | exempt" : "");
                plugin.msg(s, sb.toString());
            }
            case "logs" -> {
                if (d.log.isEmpty()) { plugin.msg(s, "&7No recent flags for " + t.getName() + "."); return true; }
                StringBuilder sb = new StringBuilder("&6Recent flags for " + t.getName() + ":");
                int i = 0;
                for (String l : d.log) { if (i++ >= 10) break; sb.append("\n&7").append(l); }
                plugin.msg(s, sb.toString());
            }
            case "reset" -> { d.vl.clear(); d.log.clear(); plugin.msg(s, "&aCleared " + t.getName() + "'s violations."); }
            case "exempt" -> {
                if (exempt.remove(t.getUniqueId())) plugin.msg(s, "&a" + t.getName() + " is no longer exempt.");
                else { exempt.add(t.getUniqueId()); plugin.msg(s, "&a" + t.getName() + " is exempt from checks."); }
            }
            default -> plugin.msg(s, "&cUnknown subcommand. Use /ac for help.");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (!s.hasPermission("vibeeconomy.ac.alerts") && !s.hasPermission("vibeeconomy.admin")) return out;
        String cur = a.length > 0 ? a[a.length - 1].toLowerCase() : "";
        if (a.length == 1) {
            for (String o : new String[]{"alerts", "status", "logs", "reset", "exempt"}) if (o.startsWith(cur)) out.add(o);
        } else if (a.length == 2) {
            for (Player p : Bukkit.getOnlinePlayers()) if (p.getName().toLowerCase().startsWith(cur)) out.add(p.getName());
        }
        return out;
    }
}
