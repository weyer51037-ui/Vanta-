package dev.vibe.economy;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.Material;
import org.bukkit.Statistic;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Bounties, private messages + ignore, AFK + playtime shards, stats and leaderboards. */
@SuppressWarnings("deprecation")
public final class Extras implements Listener, TabExecutor {

    public static final String[] COMMANDS = {"bounty", "msg", "reply", "ignore", "afk", "stats", "leaderboard", "roles", "kit"};

    private final VibeEconomy plugin;
    private final File bountyFile, ignoreFile;
    private final Map<UUID, Double> bounties = new HashMap<>();
    private final Map<UUID, Set<UUID>> ignores = new ConcurrentHashMap<>();
    private final Map<UUID, UUID> lastMessaged = new HashMap<>();
    private final Map<UUID, Long> lastActive = new HashMap<>();
    private final Set<UUID> afk = new HashSet<>();
    private final Map<UUID, Integer> playMinutes = new HashMap<>();

    public Extras(VibeEconomy plugin) {
        this.plugin = plugin;
        bountyFile = new File(plugin.getDataFolder(), "bounties.yml");
        ignoreFile = new File(plugin.getDataFolder(), "ignores.yml");
        load();
        // AFK detection every 30 seconds
        Bukkit.getScheduler().runTaskTimer(plugin, this::afkTick, 600L, 600L);
        // playtime shards every minute
        Bukkit.getScheduler().runTaskTimer(plugin, this::playtimeTick, 1200L, 1200L);
    }

    // ---------------------------------------------------------------- storage

    private void load() {
        YamlConfiguration b = YamlConfiguration.loadConfiguration(bountyFile);
        for (String k : b.getKeys(false)) {
            try { bounties.put(UUID.fromString(k), b.getDouble(k)); } catch (IllegalArgumentException ignored) { }
        }
        YamlConfiguration i = YamlConfiguration.loadConfiguration(ignoreFile);
        for (String k : i.getKeys(false)) {
            try {
                Set<UUID> set = ConcurrentHashMap.newKeySet();
                for (String s : i.getStringList(k)) set.add(UUID.fromString(s));
                ignores.put(UUID.fromString(k), set);
            } catch (IllegalArgumentException ignored) { }
        }
    }

    private void saveBounties() {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<UUID, Double> e : bounties.entrySet()) y.set(e.getKey().toString(), e.getValue());
        try { y.save(bountyFile); } catch (IOException e) { plugin.getLogger().severe("bounties.yml: " + e.getMessage()); }
    }

    private void saveIgnores() {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<UUID, Set<UUID>> e : ignores.entrySet()) {
            List<String> l = new ArrayList<>();
            for (UUID u : e.getValue()) l.add(u.toString());
            y.set(e.getKey().toString(), l);
        }
        try { y.save(ignoreFile); } catch (IOException e) { plugin.getLogger().severe("ignores.yml: " + e.getMessage()); }
    }

    private String nameOf(UUID id) {
        String n = Bukkit.getOfflinePlayer(id).getName();
        return n == null ? "Unknown" : n;
    }

    // ---------------------------------------------------------------- commands

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        switch (cmd.getName().toLowerCase()) {
            case "bounty":      return cmdBounty(s, a);
            case "msg":         return cmdMsg(s, a);
            case "reply":       return cmdReply(s, a);
            case "ignore":      return cmdIgnore(s, a);
            case "afk":         return cmdAfk(s);
            case "stats":       return cmdStats(s, a);
            case "leaderboard": return cmdLeaderboard(s, a);
            case "roles":       return cmdRoles(s);
            case "kit":         return cmdKit(s);
        }
        return false;
    }

    // ---- bounties

    private boolean cmdBounty(CommandSender s, String[] a) {
        if (a.length >= 1 && a[0].equalsIgnoreCase("list")) {
            List<Map.Entry<UUID, Double>> all = new ArrayList<>(bounties.entrySet());
            all.sort((x, y) -> Double.compare(y.getValue(), x.getValue()));
            if (all.isEmpty()) { plugin.msg(s, "&7There are no bounties right now."); return true; }
            StringBuilder sb = new StringBuilder("&c&lBounties");
            int i = 0;
            for (Map.Entry<UUID, Double> e : all) {
                if (i++ >= 10) break;
                sb.append("\n&e").append(i).append(". &f").append(nameOf(e.getKey())).append(" &7- &a").append(plugin.money(e.getValue()));
            }
            plugin.msg(s, sb.toString());
            return true;
        }
        if (!(s instanceof Player p)) { plugin.msg(s, "&cPlayers only."); return true; }
        if (a.length < 2) { plugin.msg(p, "&cUsage: /bounty <player> <amount>   or   /bounty list"); return true; }
        @SuppressWarnings("deprecation")
        OfflinePlayer t = Bukkit.getOfflinePlayer(a[0]);
        if (!t.hasPlayedBefore() && !t.isOnline()) { plugin.msg(p, "&cPlayer not found."); return true; }
        if (t.getUniqueId().equals(p.getUniqueId())) { plugin.msg(p, "&cYou can't put a bounty on yourself."); return true; }
        Double amt = VibeEconomy.parseMoney(a[1]);
        double min = plugin.getConfig().getDouble("bounty.min", 100);
        if (amt == null || amt < min) { plugin.msg(p, "&cThe minimum bounty is " + plugin.money(min) + "."); return true; }
        if (!plugin.withdraw(p.getUniqueId(), amt)) { plugin.msg(p, "&cYou can't afford that."); return true; }
        plugin.record(p.getUniqueId(), "Placed bounty on " + t.getName(), -amt);
        double total = bounties.merge(t.getUniqueId(), amt, Double::sum);
        saveBounties();
        Bukkit.broadcastMessage(ItemSpec.c("&c&l[BOUNTY] &e" + p.getName() + " &fplaced &a" + plugin.money(amt)
                + " &fon &e" + t.getName() + "&f! Total: &a" + plugin.money(total)));
        return true;
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        Player killer = victim.getKiller();
        if (killer == null || killer.getUniqueId().equals(victim.getUniqueId())) return;
        Double bounty = bounties.get(victim.getUniqueId());
        if (bounty == null || bounty <= 0) return;
        if (plugin.duels() != null && plugin.duels().inDuel(victim)) return;
        if (plugin.teams() != null && plugin.teams().sameTeam(killer, victim)) return;
        if (plugin.getConfig().getBoolean("shards.block-same-ip", true)
                && killer.getAddress() != null && victim.getAddress() != null
                && killer.getAddress().getAddress().equals(victim.getAddress().getAddress())) return;
        bounties.remove(victim.getUniqueId());
        saveBounties();
        double tax = bounty * plugin.getConfig().getDouble("bounty.tax-percent", 5) / 100.0;
        double payout = Util.round2(bounty - tax);
        plugin.deposit(killer.getUniqueId(), payout);
        plugin.record(killer.getUniqueId(), "Bounty collected on " + victim.getName(), payout);
        Bukkit.broadcastMessage(ItemSpec.c("&c&l[BOUNTY] &e" + killer.getName() + " &fcollected the bounty on &e"
                + victim.getName() + " &ffor &a" + plugin.money(payout) + "&f!"));
    }

    private static final List<String> DEFAULT_KIT = List.of("IRON_SWORD:1", "IRON_PICKAXE:1", "IRON_AXE:1", "IRON_SHOVEL:1",
            "IRON_HELMET:1", "IRON_CHESTPLATE:1", "IRON_LEGGINGS:1", "IRON_BOOTS:1", "SHIELD:1", "COOKED_BEEF:32",
            "TORCH:32", "WATER_BUCKET:1", "ENDER_PEARL:2");

    private void giveStarterKit(Player p) {
        List<String> list = plugin.getConfig().getStringList("starter-kit.items");
        if (list.isEmpty()) list = DEFAULT_KIT;
        for (String s : list) {
            String[] parts = s.split(":");
            Material m = Material.matchMaterial(parts[0].trim());
            if (m == null) continue;
            int n = 1;
            if (parts.length > 1) {
                try { n = Math.max(1, Integer.parseInt(parts[1].trim())); } catch (NumberFormatException ignored) { }
            }
            plugin.giveItem(p, new ItemStack(m, n));
        }
        plugin.settings().setClaimedKit(p.getUniqueId());
        plugin.msg(p, "&a&lWelcome to VantaSMP! &fYou got a starter kit and start with &a" + plugin.money(plugin.getBalance(p.getUniqueId())).replace(".00", "") + "&f. Try &e/menu&f.");
    }

    private boolean cmdKit(CommandSender s) {
        if (!(s instanceof Player p)) { plugin.msg(s, "&cPlayers only."); return true; }
        if (plugin.settings().claimedKit(p.getUniqueId())) { plugin.msg(p, "&cYou already claimed the starter kit."); return true; }
        giveStarterKit(p);
        return true;
    }

    /** Server-funded bounty (used by killstreaks). */
    public void addServerBounty(UUID id, double amount) {
        bounties.merge(id, amount, Double::sum);
        saveBounties();
    }

    public double bountyOf(UUID id) {
        Double b = bounties.get(id);
        return b == null ? 0 : b;
    }

    private boolean cmdRoles(CommandSender s) {
        String url = plugin.getConfig().getString("roles.url", "https://www.vantaclient.cfd");
        Component link = Component.text("Click here to buy a role: ", NamedTextColor.GRAY)
                .append(Component.text(url, NamedTextColor.LIGHT_PURPLE, TextDecoration.UNDERLINED)
                        .clickEvent(ClickEvent.openUrl(url)));
        s.sendMessage(link);
        return true;
    }

    // ---- messaging

    private boolean ignoring(UUID who, UUID target) {
        Set<UUID> set = ignores.get(who);
        return set != null && set.contains(target);
    }

    private boolean cmdMsg(CommandSender s, String[] a) {
        if (!(s instanceof Player p)) { plugin.msg(s, "&cPlayers only."); return true; }
        if (a.length < 2) { plugin.msg(p, "&cUsage: /msg <player> <message>"); return true; }
        Player t = Bukkit.getPlayerExact(a[0]);
        if (t == null) { plugin.msg(p, "&cThat player isn't online."); return true; }
        sendPrivate(p, t, String.join(" ", java.util.Arrays.copyOfRange(a, 1, a.length)));
        return true;
    }

    private boolean cmdReply(CommandSender s, String[] a) {
        if (!(s instanceof Player p)) { plugin.msg(s, "&cPlayers only."); return true; }
        if (a.length < 1) { plugin.msg(p, "&cUsage: /reply <message>"); return true; }
        UUID last = lastMessaged.get(p.getUniqueId());
        Player t = last == null ? null : Bukkit.getPlayer(last);
        if (t == null) { plugin.msg(p, "&cYou have nobody to reply to."); return true; }
        sendPrivate(p, t, String.join(" ", a));
        return true;
    }

    private void sendPrivate(Player from, Player to, String text) {
        if (!plugin.settings().get(to.getUniqueId(), "messages") && !from.hasPermission("vibeeconomy.admin")) {
            plugin.msg(from, "&cThat player has private messages turned off.");
            return;
        }
        if (ignoring(to.getUniqueId(), from.getUniqueId())) { plugin.msg(from, "&cThat player isn't accepting messages from you."); return; }
        if (ignoring(from.getUniqueId(), to.getUniqueId())) { plugin.msg(from, "&cYou are ignoring that player. Use /ignore to unignore."); return; }
        from.sendMessage(ItemSpec.c("&7[&dyou &7-> &d" + to.getName() + "&7] &f") + text);
        to.sendMessage(ItemSpec.c("&7[&d" + from.getName() + " &7-> &dyou&7] &f") + text);
        lastMessaged.put(from.getUniqueId(), to.getUniqueId());
        lastMessaged.put(to.getUniqueId(), from.getUniqueId());
    }

    private boolean cmdIgnore(CommandSender s, String[] a) {
        if (!(s instanceof Player p)) { plugin.msg(s, "&cPlayers only."); return true; }
        if (a.length < 1) { plugin.msg(p, "&cUsage: /ignore <player>  (run again to unignore)"); return true; }
        @SuppressWarnings("deprecation")
        OfflinePlayer t = Bukkit.getOfflinePlayer(a[0]);
        if (!t.hasPlayedBefore() && !t.isOnline()) { plugin.msg(p, "&cPlayer not found."); return true; }
        if (t.getUniqueId().equals(p.getUniqueId())) { plugin.msg(p, "&cYou can't ignore yourself."); return true; }
        Set<UUID> set = ignores.computeIfAbsent(p.getUniqueId(), k -> ConcurrentHashMap.newKeySet());
        if (set.remove(t.getUniqueId())) plugin.msg(p, "&aYou are no longer ignoring &f" + t.getName() + "&a.");
        else { set.add(t.getUniqueId()); plugin.msg(p, "&7You are now ignoring &f" + t.getName() + "&7. Their chat and messages are hidden."); }
        saveIgnores();
        return true;
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent e) {
        UUID sender = e.getPlayer().getUniqueId();
        e.getRecipients().removeIf(r -> !r.getUniqueId().equals(sender) && ignoring(r.getUniqueId(), sender));
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTask(plugin, () -> markActive(p));
    }

    // ---- AFK + playtime shards

    private void markActive(Player p) {
        UUID id = p.getUniqueId();
        lastActive.put(id, System.currentTimeMillis());
        if (afk.remove(id)) {
            p.setPlayerListName(null);
            plugin.msg(p, "&7You are no longer AFK.");
        }
    }

    private void setAfk(Player p) {
        if (afk.add(p.getUniqueId())) {
            p.setPlayerListName(ItemSpec.c("&7[AFK] " + p.getName()));
            plugin.msg(p, "&7You are now AFK. You won't earn playtime shards until you move.");
        }
    }

    private boolean cmdAfk(CommandSender s) {
        if (!(s instanceof Player p)) { plugin.msg(s, "&cPlayers only."); return true; }
        if (afk.contains(p.getUniqueId())) markActive(p);
        else setAfk(p);
        return true;
    }

    private void afkTick() {
        long limit = plugin.getConfig().getLong("afk.minutes", 5) * 60_000L;
        long now = System.currentTimeMillis();
        for (Player p : Bukkit.getOnlinePlayers()) {
            Long last = lastActive.get(p.getUniqueId());
            if (last == null) { lastActive.put(p.getUniqueId(), now); continue; }
            if (now - last >= limit) setAfk(p);
        }
    }

    private void playtimeTick() {
        int need = Math.max(1, plugin.getConfig().getInt("playtime.minutes-per-reward", 10));
        long shards = plugin.getConfig().getLong("playtime.shards", 1);
        if (shards <= 0) return;
        for (Player p : Bukkit.getOnlinePlayers()) {
            UUID id = p.getUniqueId();
            if (afk.contains(id)) continue;
            int m = playMinutes.merge(id, 1, Integer::sum);
            if (m >= need) {
                playMinutes.put(id, 0);
                plugin.addShards(id, shards);
                plugin.msg(p, "&5+" + shards + " Vanta Shard" + (shards == 1 ? "" : "s") + " &7for playing.");
            }
        }
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        if (e.hasChangedBlock()) markActive(e.getPlayer());
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) { markActive(e.getPlayer()); }

    @EventHandler
    public void onCommandPre(PlayerCommandPreprocessEvent e) {
        String m = e.getMessage().toLowerCase(Locale.ROOT);
        if (m.equals("/afk") || m.startsWith("/afk ")) return;
        markActive(e.getPlayer());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        lastActive.put(p.getUniqueId(), System.currentTimeMillis());
        if (!p.hasPlayedBefore() && plugin.getConfig().getBoolean("starter-kit.enabled", true)
                && !plugin.settings().claimedKit(p.getUniqueId())) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> { if (p.isOnline()) giveStarterKit(p); }, 30L);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        afk.remove(id);
        lastActive.remove(id);
        lastMessaged.remove(id);
    }

    // ---- stats + leaderboards

    @SuppressWarnings("deprecation")
    private boolean cmdStats(CommandSender s, String[] a) {
        OfflinePlayer t;
        if (a.length > 0) t = Bukkit.getOfflinePlayer(a[0]);
        else if (s instanceof Player p) t = p;
        else { plugin.msg(s, "&cSpecify a player."); return true; }
        if (!t.hasPlayedBefore() && !t.isOnline()) { plugin.msg(s, "&cPlayer not found."); return true; }
        int kills = t.getStatistic(Statistic.PLAYER_KILLS);
        int deaths = t.getStatistic(Statistic.DEATHS);
        String kdr = deaths == 0 ? String.valueOf(kills) : String.format(Locale.US, "%.2f", kills / (double) deaths);
        long hours = t.getStatistic(Statistic.PLAY_ONE_MINUTE) / 72000L;
        String team = plugin.teams() == null ? null : plugin.teams().teamName(t.getUniqueId());
        Double bounty = bounties.get(t.getUniqueId());
        plugin.msg(s, "&6&l" + t.getName() + "'s Stats"
                + "\n&7Kills: &f" + kills + " &8| &7Deaths: &f" + deaths + " &8| &7K/D: &f" + kdr
                + " &8| &7Best streak: &f" + plugin.streaks().best(t.getUniqueId())
                + "\n&7Playtime: &f" + hours + "h"
                + "\n&7Money: &a" + plugin.money(plugin.getBalance(t.getUniqueId())) + " &8| &7Shards: &d" + plugin.getShards(t.getUniqueId())
                + "\n&7Team: &f" + (team == null ? "none" : team)
                + (bounty != null ? "\n&cBounty: &a" + plugin.money(bounty) : ""));
        return true;
    }

    @SuppressWarnings("deprecation")
    private boolean cmdLeaderboard(CommandSender s, String[] a) {
        String type = a.length > 0 ? a[0].toLowerCase() : "";
        if (!(type.equals("money") || type.equals("shards") || type.equals("kills") || type.equals("playtime"))) {
            plugin.msg(s, "&cUsage: /leaderboard <money|shards|kills|playtime>");
            return true;
        }
        Map<UUID, Double> values = new HashMap<>();
        if (type.equals("money")) values.putAll(plugin.balancesView());
        else if (type.equals("shards")) {
            for (Map.Entry<UUID, Long> e : plugin.shardsView().entrySet()) values.put(e.getKey(), (double) e.getValue());
        } else {
            for (OfflinePlayer op : Bukkit.getOfflinePlayers()) {
                if (!op.hasPlayedBefore()) continue;
                double v = type.equals("kills") ? op.getStatistic(Statistic.PLAYER_KILLS) : op.getStatistic(Statistic.PLAY_ONE_MINUTE) / 72000.0;
                values.put(op.getUniqueId(), v);
            }
        }
        List<Map.Entry<UUID, Double>> list = new ArrayList<>(values.entrySet());
        list.sort((x, y) -> Double.compare(y.getValue(), x.getValue()));
        StringBuilder sb = new StringBuilder("&6&lTop " + type);
        int i = 0;
        for (Map.Entry<UUID, Double> e : list) {
            if (i++ >= 10) break;
            String v;
            if (type.equals("money")) v = plugin.money(e.getValue());
            else if (type.equals("playtime")) v = String.format(Locale.US, "%.1fh", e.getValue());
            else v = String.valueOf(e.getValue().longValue());
            sb.append("\n&e").append(i).append(". &f").append(nameOf(e.getKey())).append(" &7- &a").append(v);
        }
        plugin.msg(s, sb.toString());
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        List<String> out = new ArrayList<>();
        String n = cmd.getName().toLowerCase();
        String cur = a.length > 0 ? a[a.length - 1].toLowerCase() : "";
        if (n.equals("leaderboard") && a.length == 1) {
            for (String o : new String[]{"money", "shards", "kills", "playtime"}) if (o.startsWith(cur)) out.add(o);
        } else if (a.length == 1 && (n.equals("bounty") || n.equals("msg") || n.equals("ignore") || n.equals("stats"))) {
            if (n.equals("bounty") && "list".startsWith(cur)) out.add("list");
            for (Player p : Bukkit.getOnlinePlayers()) if (p.getName().toLowerCase().startsWith(cur)) out.add(p.getName());
        }
        return out;
    }
}
