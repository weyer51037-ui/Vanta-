package dev.vibe.economy;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Per-player transaction history (money and shards) with a menu. */
public final class History implements Listener, TabExecutor {

    private static final int MAX = 100;

    private static final class Entry {
        final long time; final boolean shards; final double amount; final String desc;
        Entry(long time, boolean shards, double amount, String desc) {
            this.time = time; this.shards = shards; this.amount = amount; this.desc = desc;
        }
    }

    private static final class Holder implements InventoryHolder {
        final int page; Inventory inv;
        Holder(int page) { this.page = page; }
        @Override public Inventory getInventory() { return inv; }
    }

    private final VibeEconomy plugin;
    private final File file;
    private final Map<UUID, LinkedList<Entry>> data = new HashMap<>();

    public History(VibeEconomy plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "history.yml");
        load();
    }

    private void load() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        for (String k : y.getKeys(false)) {
            try {
                UUID id = UUID.fromString(k);
                LinkedList<Entry> list = new LinkedList<>();
                for (String s : y.getStringList(k)) {
                    String[] p = s.split("\\|", 4);
                    if (p.length < 4) continue;
                    try {
                        list.addLast(new Entry(Long.parseLong(p[0]), p[1].equals("S"), Double.parseDouble(p[2]), p[3]));
                    } catch (NumberFormatException ignored) { }
                }
                data.put(id, list);
            } catch (IllegalArgumentException ignored) { }
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<UUID, LinkedList<Entry>> e : data.entrySet()) {
            List<String> out = new ArrayList<>();
            for (Entry en : e.getValue()) {
                out.add(en.time + "|" + (en.shards ? "S" : "M") + "|" + en.amount + "|" + en.desc);
            }
            y.set(e.getKey().toString(), out);
        }
        try { y.save(file); } catch (IOException ex) { plugin.getLogger().severe("history.yml: " + ex.getMessage()); }
    }

    public void record(UUID id, String desc, double amount, boolean shards) {
        LinkedList<Entry> l = data.computeIfAbsent(id, k -> new LinkedList<>());
        l.addFirst(new Entry(System.currentTimeMillis(), shards, amount, desc.replace('|', '/')));
        while (l.size() > MAX) l.removeLast();
    }

    // ---------------------------------------------------------------- menu

    public void open(Player p, int page) {
        List<Entry> all = data.getOrDefault(p.getUniqueId(), new LinkedList<>());
        int pages = Math.max(1, (int) Math.ceil(all.size() / 45.0));
        int pg = Math.max(0, Math.min(page, pages - 1));
        Holder h = new Holder(pg);
        Inventory inv = Bukkit.createInventory(h, 54, ItemSpec.c("&b&lTransactions &8(" + (pg + 1) + "/" + pages + ")"));
        h.inv = inv;

        int from = pg * 45;
        for (int i = 0; i < 45 && from + i < all.size(); i++) {
            Entry en = all.get(from + i);
            boolean gain = en.amount >= 0;
            Material m = en.shards ? Material.AMETHYST_SHARD : (gain ? Material.GOLD_INGOT : Material.REDSTONE);
            String amt = en.shards ? (long) Math.abs(en.amount) + " Vanta Shards" : plugin.money(Math.abs(en.amount));
            inv.setItem(i, Util.button(m, (gain ? "&a+ " : "&c- ") + amt, "&7" + en.desc, "&8" + Util.ago(System.currentTimeMillis() - en.time)));
        }
        if (all.isEmpty()) {
            inv.setItem(22, Util.button(Material.PAPER, "&7No transactions yet", "&8Sells, purchases, payments and rewards show up here."));
        }
        for (int i = 45; i < 54; i++) inv.setItem(i, Util.filler());
        Util.navButtons(inv);
        if (pg > 0) inv.setItem(45, Util.button(Material.ARROW, "&7Previous page"));
        if (pg < pages - 1) inv.setItem(53, Util.button(Material.ARROW, "&7Next page"));
        inv.setItem(49, Util.button(Material.GOLD_INGOT, "&eBalance: &a" + plugin.money(plugin.getBalance(p.getUniqueId())),
                "&5Vanta Shards: &d" + plugin.getShards(p.getUniqueId())));
        p.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != top) return;
        int slot = e.getRawSlot();
        if (slot == 52) return; // already here
        if (Util.navClick(plugin, p, slot)) return;
        if (slot == 45 && h.page > 0) open(p, h.page - 1);
        else if (slot == 53) open(p, h.page + 1);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (!(s instanceof Player p)) { plugin.msg(s, "&cPlayers only."); return true; }
        open(p, 0);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) { return new ArrayList<>(); }
}
