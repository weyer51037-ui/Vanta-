package dev.vibe.economy;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.EntityRemoveEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.inventory.InventoryPickupItemEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * The God Set: one unique armor set on the whole server. 2 billion per piece.
 * Protection X + every armor enchant, and +5 max health per piece (+10 hearts for the full set) while worn.
 * If a piece is lost to the void, destroyed, despawns, or wiped from its holder, it goes back on sale in /godset.
 */
@SuppressWarnings("deprecation")
public final class Godset implements Listener, TabExecutor {

    private enum Piece {
        HELMET(Material.NETHERITE_HELMET, EquipmentSlotGroup.HEAD, "God Helmet", 3,
                new String[]{"protection:10", "fire_protection:10", "blast_protection:10", "projectile_protection:10",
                        "unbreaking:10", "mending:1", "thorns:3", "respiration:3", "aqua_affinity:1"}),
        CHESTPLATE(Material.NETHERITE_CHESTPLATE, EquipmentSlotGroup.CHEST, "God Chestplate", 8,
                new String[]{"protection:10", "fire_protection:10", "blast_protection:10", "projectile_protection:10",
                        "unbreaking:10", "mending:1", "thorns:3"}),
        LEGGINGS(Material.NETHERITE_LEGGINGS, EquipmentSlotGroup.LEGS, "God Leggings", 6,
                new String[]{"protection:10", "fire_protection:10", "blast_protection:10", "projectile_protection:10",
                        "unbreaking:10", "mending:1", "thorns:3", "swift_sneaking:3"}),
        BOOTS(Material.NETHERITE_BOOTS, EquipmentSlotGroup.FEET, "God Boots", 3,
                new String[]{"protection:10", "fire_protection:10", "blast_protection:10", "projectile_protection:10",
                        "unbreaking:10", "mending:1", "thorns:3", "feather_falling:10", "depth_strider:3", "soul_speed:3"});

        final Material material; final EquipmentSlotGroup slot; final String display; final int armor; final String[] enchants;
        Piece(Material material, EquipmentSlotGroup slot, String display, int armor, String[] enchants) {
            this.material = material; this.slot = slot; this.display = display; this.armor = armor; this.enchants = enchants;
        }
    }

    private static final class State {
        String status = "STORE";        // STORE, HELD, DROPPED
        UUID holder; String holderName;
        UUID serial;
        UUID entity;
        Location droppedAt;
        long since;
        int missing;
    }

    private static final class Holder implements InventoryHolder {
        final Map<Integer, Piece> slots = new java.util.HashMap<>();
        Inventory inv;
        @Override public Inventory getInventory() { return inv; }
    }

    private final VibeEconomy plugin;
    private final File file;
    private final NamespacedKey tagPiece, tagSerial;
    private final Map<Piece, State> states = new EnumMap<>(Piece.class);

    public Godset(VibeEconomy plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "godset.yml");
        this.tagPiece = new NamespacedKey(plugin, "godset_piece");
        this.tagSerial = new NamespacedKey(plugin, "godset_serial");
        for (Piece p : Piece.values()) states.put(p, new State());
        load();
        Bukkit.getScheduler().runTaskTimer(plugin, this::scan, 400L, 400L);
    }

    // ---------------------------------------------------------------- storage

    private void load() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        for (Piece p : Piece.values()) {
            ConfigurationSection s = y.getConfigurationSection("pieces." + p.name());
            if (s == null) continue;
            State st = states.get(p);
            st.status = s.getString("status", "STORE");
            st.holderName = s.getString("holderName", null);
            st.since = s.getLong("since", 0);
            try { if (s.getString("holder") != null) st.holder = UUID.fromString(s.getString("holder")); } catch (IllegalArgumentException ignored) { }
            try { if (s.getString("serial") != null) st.serial = UUID.fromString(s.getString("serial")); } catch (IllegalArgumentException ignored) { }
            try { if (s.getString("entity") != null) st.entity = UUID.fromString(s.getString("entity")); } catch (IllegalArgumentException ignored) { }
            st.droppedAt = s.getLocation("location");
            if (st.serial == null) { st.status = "STORE"; }
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Piece p : Piece.values()) {
            State st = states.get(p);
            String k = "pieces." + p.name();
            y.set(k + ".status", st.status);
            if (st.holder != null) y.set(k + ".holder", st.holder.toString());
            if (st.holderName != null) y.set(k + ".holderName", st.holderName);
            if (st.serial != null) y.set(k + ".serial", st.serial.toString());
            if (st.entity != null) y.set(k + ".entity", st.entity.toString());
            if (st.droppedAt != null) y.set(k + ".location", st.droppedAt);
            y.set(k + ".since", st.since);
        }
        try { y.save(file); } catch (IOException e) { plugin.getLogger().severe("godset.yml: " + e.getMessage()); }
    }

    // ---------------------------------------------------------------- item helpers

    private ItemStack build(Piece pc, UUID serial) {
        ItemStack it = new ItemStack(pc.material);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(ItemSpec.c("&6&l" + pc.display));
        List<String> lore = new ArrayList<>();
        lore.add(ItemSpec.c("&7Only one set exists on the whole server."));
        lore.add(ItemSpec.c("&ePROTECTION X &7+ every armor enchant"));
        lore.add(ItemSpec.c("&c+5 max health &7(+10 hearts with the full set)"));
        lore.add(ItemSpec.c("&8Can't be stored. Lose it to the void and it"));
        lore.add(ItemSpec.c("&8returns to /godset for sale."));
        meta.setLore(lore);
        for (String e : pc.enchants) {
            String[] parts = e.split(":");
            Enchantment en = Registry.ENCHANTMENT.get(NamespacedKey.minecraft(parts[0]));
            if (en != null) meta.addEnchant(en, Integer.parseInt(parts[1]), true);
        }
        String n = pc.name().toLowerCase(Locale.ROOT);
        meta.addAttributeModifier(Attribute.MAX_HEALTH, new AttributeModifier(new NamespacedKey(plugin, "god_" + n + "_hp"), 5.0, AttributeModifier.Operation.ADD_NUMBER, pc.slot));
        meta.addAttributeModifier(Attribute.ARMOR, new AttributeModifier(new NamespacedKey(plugin, "god_" + n + "_armor"), pc.armor, AttributeModifier.Operation.ADD_NUMBER, pc.slot));
        meta.addAttributeModifier(Attribute.ARMOR_TOUGHNESS, new AttributeModifier(new NamespacedKey(plugin, "god_" + n + "_tough"), 3.0, AttributeModifier.Operation.ADD_NUMBER, pc.slot));
        meta.addAttributeModifier(Attribute.KNOCKBACK_RESISTANCE, new AttributeModifier(new NamespacedKey(plugin, "god_" + n + "_kb"), 0.1, AttributeModifier.Operation.ADD_NUMBER, pc.slot));
        meta.setUnbreakable(true);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
        meta.getPersistentDataContainer().set(tagPiece, PersistentDataType.STRING, pc.name());
        meta.getPersistentDataContainer().set(tagSerial, PersistentDataType.STRING, serial.toString());
        it.setItemMeta(meta);
        return it;
    }

    private Piece pieceOf(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        String v = it.getItemMeta().getPersistentDataContainer().get(tagPiece, PersistentDataType.STRING);
        if (v == null) return null;
        try { return Piece.valueOf(v); } catch (IllegalArgumentException e) { return null; }
    }

    private boolean isCurrent(ItemStack it) {
        Piece pc = pieceOf(it);
        if (pc == null) return false;
        String s = it.getItemMeta().getPersistentDataContainer().get(tagSerial, PersistentDataType.STRING);
        UUID serial = states.get(pc).serial;
        return serial != null && serial.toString().equals(s);
    }

    public boolean isGodItem(ItemStack it) { return pieceOf(it) != null; }

    // ---------------------------------------------------------------- state changes

    private void repost(Piece pc, String reason) {
        State s = states.get(pc);
        if (s.entity != null) {
            Entity ent = Bukkit.getEntity(s.entity);
            s.entity = null;
            if (ent != null) ent.remove();
        }
        s.status = "STORE";
        s.holder = null;
        s.serial = null;
        s.entity = null;
        s.droppedAt = null;
        s.missing = 0;
        save();
        Bukkit.broadcastMessage(ItemSpec.c("&6&l[GODSET] &fThe &6" + pc.display + " &f" + reason + " and is back for sale in &e/godset&f!"));
    }

    private void setHeld(Piece pc, Player p) {
        State s = states.get(pc);
        s.status = "HELD";
        s.holder = p.getUniqueId();
        s.holderName = p.getName();
        s.entity = null;
        s.droppedAt = null;
        s.missing = 0;
        save();
    }

    private void buy(Player p, Piece pc) {
        State s = states.get(pc);
        if (!"STORE".equals(s.status)) { plugin.msg(p, "&cThat piece isn't for sale right now."); return; }
        double price = plugin.getConfig().getDouble("godset.price", 2_000_000_000.0);
        if (!plugin.has(p.getUniqueId(), price)) { plugin.msg(p, "&cYou need " + plugin.money(price) + " to buy that."); return; }
        plugin.withdraw(p.getUniqueId(), price);
        plugin.record(p.getUniqueId(), "Bought " + pc.display, -price);
        s.serial = UUID.randomUUID();
        setHeld(pc, p);
        plugin.giveItem(p, build(pc, s.serial));
        Bukkit.broadcastMessage(ItemSpec.c("&6&l[GODSET] &e" + p.getName() + " &fbought the &6" + pc.display + "&f for &a"
                + plugin.money(price) + "&f! Kill them to take it. Check &e/godset&f."));
        open(p);
    }

    // ---------------------------------------------------------------- events

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        EntityDamageEvent last = p.getLastDamageCause();
        boolean voidDeath = last != null && last.getCause() == EntityDamageEvent.DamageCause.VOID;
        boolean always = plugin.getConfig().getBoolean("godset.repost-on-death", false);
        if (!voidDeath && !always) return;
        String why = voidDeath ? p.getName() + " fell into the void" : p.getName() + " died";
        for (Iterator<ItemStack> it = e.getDrops().iterator(); it.hasNext();) {
            ItemStack d = it.next();
            Piece pc = pieceOf(d);
            if (pc == null) continue;
            it.remove();
            if (isCurrent(d)) repost(pc, "was lost: " + why);
        }
        if (e.getKeepInventory()) {
            ItemStack[] c = p.getInventory().getContents();
            for (int i = 0; i < c.length; i++) {
                Piece pc = pieceOf(c[i]);
                if (pc == null) continue;
                boolean cur = isCurrent(c[i]);
                p.getInventory().setItem(i, null);
                if (cur) repost(pc, "was lost: " + why);
            }
        }
    }

    @EventHandler
    public void onSpawn(ItemSpawnEvent e) {
        Item item = e.getEntity();
        ItemStack st = item.getItemStack();
        Piece pc = pieceOf(st);
        if (pc == null) return;
        if (!isCurrent(st)) { e.setCancelled(true); return; }
        State s = states.get(pc);
        s.status = "DROPPED";
        s.entity = item.getUniqueId();
        s.droppedAt = item.getLocation();
        s.since = System.currentTimeMillis();
        s.missing = 0;
        item.setInvulnerable(true);
        save();
    }

    @EventHandler(ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent e) {
        ItemStack st = e.getItem().getItemStack();
        Piece pc = pieceOf(st);
        if (pc == null) return;
        if (!(e.getEntity() instanceof Player p)) { e.setCancelled(true); return; }
        if (!isCurrent(st)) { e.setCancelled(true); e.getItem().remove(); return; }
        setHeld(pc, p);
        Bukkit.broadcastMessage(ItemSpec.c("&6&l[GODSET] &e" + p.getName() + " &fpicked up the &6" + pc.display + "&f!"));
    }

    @EventHandler(ignoreCancelled = true)
    public void onHopperPickup(InventoryPickupItemEvent e) {
        if (pieceOf(e.getItem().getItemStack()) != null) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onMoveItem(InventoryMoveItemEvent e) {
        if (pieceOf(e.getItem()) != null) e.setCancelled(true);
    }

    @EventHandler
    public void onRemove(EntityRemoveEvent e) {
        if (!(e.getEntity() instanceof Item item)) return;
        Piece pc = pieceOf(item.getItemStack());
        if (pc == null) return;
        State s = states.get(pc);
        if (!"DROPPED".equals(s.status) || !item.getUniqueId().equals(s.entity)) return;
        EntityRemoveEvent.Cause c = e.getCause();
        if (c == EntityRemoveEvent.Cause.DESPAWN || c == EntityRemoveEvent.Cause.OUT_OF_WORLD
                || c == EntityRemoveEvent.Cause.DEATH || c == EntityRemoveEvent.Cause.EXPLODE) {
            s.entity = null;
            repost(pc, "was destroyed");
        }
    }

    // ---- stop players storing pieces anywhere except their own inventory

    private boolean isStorage(Inventory inv) {
        InventoryType t = inv.getType();
        return t != InventoryType.CRAFTING && t != InventoryType.PLAYER && t != InventoryType.WORKBENCH;
    }

    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        Inventory top = e.getView().getTopInventory();
        if (!isStorage(top)) return;
        ItemStack cursor = e.getCursor();
        ItemStack current = e.getCurrentItem();
        boolean inTop = e.getClickedInventory() == top;
        boolean bad = false;
        if (inTop && isGodItem(cursor)) bad = true;
        if (e.isShiftClick() && !inTop && isGodItem(current)) bad = true;
        if (e.getClick() == ClickType.NUMBER_KEY && inTop) {
            int hb = e.getHotbarButton();
            if (hb >= 0 && isGodItem(p.getInventory().getItem(hb))) bad = true;
        }
        if (e.getClick() == ClickType.SWAP_OFFHAND && inTop && isGodItem(p.getInventory().getItemInOffHand())) bad = true;
        if (current != null && current.getType().name().endsWith("BUNDLE") && isGodItem(cursor)) bad = true;
        if (bad) {
            e.setCancelled(true);
            plugin.msg(p, "&cThe God set can't be stored. Keep it on you.");
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrag(InventoryDragEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!isStorage(top) || !isGodItem(e.getOldCursor())) return;
        for (int raw : e.getRawSlots()) {
            if (raw < top.getSize()) { e.setCancelled(true); return; }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onFrame(PlayerInteractEntityEvent e) {
        if (e.getRightClicked() instanceof ItemFrame && isGodItem(e.getPlayer().getInventory().getItem(e.getHand()))) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onArmorStand(PlayerArmorStandManipulateEvent e) {
        if (isGodItem(e.getPlayerItem())) e.setCancelled(true);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Bukkit.getScheduler().runTaskLater(plugin, this::scan, 20L);
    }

    // ---------------------------------------------------------------- periodic scan

    private void scan() {
        Set<Piece> seen = EnumSet.noneOf(Piece.class);
        for (Player p : Bukkit.getOnlinePlayers()) {
            ItemStack[] c = p.getInventory().getContents();
            for (int i = 0; i < c.length; i++) {
                Piece pc = pieceOf(c[i]);
                if (pc == null) continue;
                if (!isCurrent(c[i])) {
                    p.getInventory().setItem(i, null);
                    plugin.msg(p, "&cAn outdated God set piece in your inventory vanished.");
                    continue;
                }
                seen.add(pc);
                State s = states.get(pc);
                if (!"HELD".equals(s.status) || !p.getUniqueId().equals(s.holder)) setHeld(pc, p);
                s.missing = 0;
            }
            Inventory top = p.getOpenInventory().getTopInventory();
            if (top.getType() == InventoryType.CRAFTING || top.getType() == InventoryType.WORKBENCH) {
                for (ItemStack t : top.getContents()) {
                    Piece pc = pieceOf(t);
                    if (pc != null && isCurrent(t)) seen.add(pc);
                }
            }
            ItemStack cur = p.getItemOnCursor();
            Piece cp = pieceOf(cur);
            if (cp != null && isCurrent(cur)) seen.add(cp);
        }
        long graceMs = plugin.getConfig().getLong("godset.dropped-grace-minutes", 10) * 60_000L;
        for (Piece pc : Piece.values()) {
            State s = states.get(pc);
            if ("HELD".equals(s.status) && s.holder != null && !seen.contains(pc)) {
                Player holder = Bukkit.getPlayer(s.holder);
                if (holder != null && holder.isOnline()) {
                    s.missing++;
                    if (s.missing >= 3) repost(pc, "vanished from " + s.holderName + " (wiped)");
                } else {
                    s.missing = 0;
                }
            } else if ("DROPPED".equals(s.status) && s.entity != null && Bukkit.getEntity(s.entity) == null
                    && System.currentTimeMillis() - s.since > graceMs) {
                s.entity = null;
                repost(pc, "was lost");
            }
        }
    }

    // ---------------------------------------------------------------- GUI + commands

    public void open(Player p) {
        Holder h = new Holder();
        Inventory inv = Bukkit.createInventory(h, 27, ItemSpec.c("&6&lGod Set"));
        h.inv = inv;
        for (int i = 0; i < 27; i++) inv.setItem(i, Util.filler());
        int[] slots = {10, 12, 14, 16};
        double price = plugin.getConfig().getDouble("godset.price", 2_000_000_000.0);
        Piece[] all = Piece.values();
        for (int i = 0; i < all.length; i++) {
            Piece pc = all[i];
            State s = states.get(pc);
            ItemStack icon = new ItemStack(pc.material);
            ItemMeta m = icon.getItemMeta();
            m.setDisplayName(ItemSpec.c("&6&l" + pc.display));
            List<String> lore = new ArrayList<>();
            lore.add(ItemSpec.c("&ePROTECTION X &7+ every armor enchant"));
            lore.add(ItemSpec.c("&c+5 max health &7while worn"));
            lore.add("");
            if ("STORE".equals(s.status)) {
                lore.add(ItemSpec.c("&aFor sale: &f" + plugin.money(price)));
                lore.add(ItemSpec.c("&eClick to buy"));
            } else if ("HELD".equals(s.status)) {
                lore.add(ItemSpec.c("&cOwned by: &f" + (s.holderName == null ? "Unknown" : s.holderName)));
                Player hp = s.holder == null ? null : Bukkit.getPlayer(s.holder);
                lore.add(ItemSpec.c(hp != null ? "&aOnline now" : "&7Offline"));
                double bounty = s.holder == null ? 0 : plugin.extras().bountyOf(s.holder);
                if (bounty > 0) lore.add(ItemSpec.c("&cBounty: &a" + plugin.money(bounty)));
                lore.add(ItemSpec.c("&7Kill them to take it."));
            } else {
                lore.add(ItemSpec.c("&eDropped on the ground!"));
                if (s.droppedAt != null && s.droppedAt.getWorld() != null) {
                    lore.add(ItemSpec.c("&7Near: &f" + s.droppedAt.getBlockX() + ", " + s.droppedAt.getBlockY() + ", "
                            + s.droppedAt.getBlockZ() + " &7(" + s.droppedAt.getWorld().getName() + ")"));
                }
                lore.add(ItemSpec.c("&7Last holder: &f" + (s.holderName == null ? "Unknown" : s.holderName)));
                lore.add(ItemSpec.c("&7It despawns in about 5 minutes."));
            }
            m.setLore(lore);
            m.setEnchantmentGlintOverride(true);
            m.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
            icon.setItemMeta(m);
            inv.setItem(slots[i], icon);
            h.slots.put(slots[i], pc);
        }
        inv.setItem(22, Util.button(Material.NETHER_STAR, "&6&lThe God Set",
                "&7Only ONE set exists on the server.", "&7Full set: &c+10 hearts &7and Protection X.",
                "&7If a piece is lost to the void, destroyed", "&7or wiped, it comes back here for sale.",
                "&7Price per piece: &a" + plugin.money(price)));
        p.openInventory(inv);
    }

    @EventHandler
    public void onGuiClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != top) return;
        Piece pc = h.slots.get(e.getRawSlot());
        if (pc != null) buy(p, pc);
    }

    @EventHandler
    public void onGuiDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    private List<Piece> parsePieces(String s) {
        List<Piece> out = new ArrayList<>();
        if (s.equalsIgnoreCase("all")) { for (Piece p : Piece.values()) out.add(p); return out; }
        try { out.add(Piece.valueOf(s.toUpperCase(Locale.ROOT))); } catch (IllegalArgumentException ignored) { }
        return out;
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (a.length >= 1 && (a[0].equalsIgnoreCase("reset") || a[0].equalsIgnoreCase("give"))) {
            if (!s.hasPermission("vibeeconomy.admin")) { plugin.msg(s, "&cNo permission."); return true; }
            if (a[0].equalsIgnoreCase("reset")) {
                List<Piece> list = a.length >= 2 ? parsePieces(a[1]) : new ArrayList<>();
                if (list.isEmpty()) { plugin.msg(s, "&cUsage: /godset reset <helmet|chestplate|leggings|boots|all>"); return true; }
                for (Piece pc : list) repost(pc, "was reset by an admin");
                return true;
            }
            if (a.length < 3) { plugin.msg(s, "&cUsage: /godset give <player> <piece|all>"); return true; }
            Player t = Bukkit.getPlayerExact(a[1]);
            List<Piece> list = parsePieces(a[2]);
            if (t == null || list.isEmpty()) { plugin.msg(s, "&cPlayer must be online and piece must be valid."); return true; }
            for (Piece pc : list) {
                State st = states.get(pc);
                if (st.entity != null) { Entity ent = Bukkit.getEntity(st.entity); st.entity = null; if (ent != null) ent.remove(); }
                st.serial = UUID.randomUUID();
                setHeld(pc, t);
                plugin.giveItem(t, build(pc, st.serial));
                Bukkit.broadcastMessage(ItemSpec.c("&6&l[GODSET] &e" + t.getName() + " &fnow holds the &6" + pc.display + "&f!"));
            }
            return true;
        }
        if (!(s instanceof Player p)) { plugin.msg(s, "&cPlayers only."); return true; }
        open(p);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (!s.hasPermission("vibeeconomy.admin")) return out;
        String cur = a.length > 0 ? a[a.length - 1].toLowerCase() : "";
        if (a.length == 1) {
            for (String o : new String[]{"reset", "give"}) if (o.startsWith(cur)) out.add(o);
        } else if ((a.length == 2 && a[0].equalsIgnoreCase("reset")) || (a.length == 3 && a[0].equalsIgnoreCase("give"))) {
            for (String o : new String[]{"helmet", "chestplate", "leggings", "boots", "all"}) if (o.startsWith(cur)) out.add(o);
        } else if (a.length == 2 && a[0].equalsIgnoreCase("give")) {
            for (Player p : Bukkit.getOnlinePlayers()) if (p.getName().toLowerCase().startsWith(cur)) out.add(p.getName());
        }
        return out;
    }
}
