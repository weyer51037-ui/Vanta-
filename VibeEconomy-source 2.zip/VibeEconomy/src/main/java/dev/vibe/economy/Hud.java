package dev.vibe.economy;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Statistic;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Sidebar scoreboard, tab list header/footer, and the money + role shown above every player's head. */
public final class Hud implements Listener {

    private static final int LINES = 11;

    private final VibeEconomy plugin;
    private final Map<UUID, Scoreboard> boards = new HashMap<>();
    private int taskId = -1;

    public Hud(VibeEconomy plugin) { this.plugin = plugin; }

    public void start() {
        if (!plugin.getConfig().getBoolean("hud.enabled", true)) return;
        long period = Math.max(5, plugin.getConfig().getLong("hud.update-ticks", 20));
        taskId = Bukkit.getScheduler().runTaskTimer(plugin, this::refreshAll, 20L, period).getTaskId();
        refreshAll();
    }

    public void stop() {
        if (taskId != -1) Bukkit.getScheduler().cancelTask(taskId);
        for (Player p : Bukkit.getOnlinePlayers()) p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
        boards.clear();
    }

    /** Flips the sidebar setting. Returns true if the HUD is now visible. */
    public boolean toggle(Player p) {
        boolean now = !plugin.settings().get(p.getUniqueId(), "hud");
        plugin.settings().set(p.getUniqueId(), "hud", now);
        update(p);
        return now;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Bukkit.getScheduler().runTaskLater(plugin, this::refreshAll, 5L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        boards.remove(e.getPlayer().getUniqueId());
    }

    public void refreshAll() {
        for (Player p : Bukkit.getOnlinePlayers()) update(p);
    }

    @SuppressWarnings("deprecation")
    public void update(Player p) {
        if (!p.isOnline()) return;
        Scoreboard sb = boards.get(p.getUniqueId());
        if (sb == null) {
            sb = Bukkit.getScoreboardManager().getNewScoreboard();
            String title = ItemSpec.c(plugin.getConfig().getString("hud.title", "&5&lVANTASMP"));
            Objective o = sb.registerNewObjective("vantahud", "dummy", title);
            o.setDisplaySlot(DisplaySlot.SIDEBAR);
            for (int i = 0; i < LINES; i++) {
                String entry = ChatColor.values()[i].toString();
                Team t = sb.registerNewTeam("line" + i);
                t.addEntry(entry);
                o.getScore(entry).setScore(LINES - i);
            }
            boards.put(p.getUniqueId(), sb);
        }
        p.setScoreboard(sb);

        Objective obj = sb.getObjective("vantahud");
        if (plugin.settings().get(p.getUniqueId(), "hud")) {
            if (obj != null) obj.setDisplaySlot(DisplaySlot.SIDEBAR);
            updateSidebar(p, sb);
        } else {
            sb.clearSlot(DisplaySlot.SIDEBAR);
        }
        updateTags(sb);

        p.setPlayerListHeaderFooter(
                ItemSpec.c(plugin.getConfig().getString("hud.tab-header", "&5&lVANTASMP")),
                ItemSpec.c(plugin.getConfig().getString("hud.tab-footer", "&7/shop &8| &7/shards &8| &7/sell all")));
    }

    private String teamName(Player t) {
        return "vt" + t.getUniqueId().toString().replace("-", "").substring(0, 14);
    }

    /** Puts "name | ROLE | $money" over everyone's head (as this viewer sees them). */
    private void updateTags(Scoreboard sb) {
        Set<String> expected = new HashSet<>();
        for (Player t : Bukkit.getOnlinePlayers()) {
            String tn = teamName(t);
            expected.add(tn);
            Team team = sb.getTeam(tn);
            if (!plugin.settings().get(t.getUniqueId(), "money-tag")) {
                if (team != null) team.unregister();
                continue;
            }
            if (team == null) {
                team = sb.registerNewTeam(tn);
                team.addEntry(t.getName());
            }
            String role = plugin.roles().display(t.getUniqueId());
            String suffix = " &8| " + (role != null ? role + " &8| " : "") + "&a" + Util.compact(plugin.getBalance(t.getUniqueId()));
            team.setSuffix(ItemSpec.c(suffix));
        }
        for (Team tm : new ArrayList<>(sb.getTeams())) {
            if (tm.getName().startsWith("vt") && !expected.contains(tm.getName())) tm.unregister();
        }
    }

    private void updateSidebar(Player p, Scoreboard sb) {
        UUID id = p.getUniqueId();
        int kills = p.getStatistic(Statistic.PLAYER_KILLS);
        int deaths = p.getStatistic(Statistic.DEATHS);
        String kdr = deaths == 0 ? String.valueOf(kills) : String.format("%.2f", kills / (double) deaths);
        String footer = plugin.getConfig().getString("hud.footer", "&5&lVantaSMP");
        String role = plugin.roles().display(id);

        String[] lines = new String[]{
                "&8&m                    ",
                "&dMoney: &f" + plugin.money(plugin.getBalance(id)).replace(".00", ""),
                "&dShards: &f" + plugin.getShards(id),
                "&dStreak: &f" + plugin.getStreak(id),
                "&dKills: &f" + kills + " &7| &dDeaths: &f" + deaths,
                "&dK/D: &f" + kdr,
                "&dRole: " + (role != null ? role : "&7none"),
                "&dOnline: &f" + Bukkit.getOnlinePlayers().size(),
                "&dPing: &f" + p.getPing() + "ms",
                "&8&m                    &r",
                footer
        };
        for (int i = 0; i < LINES; i++) {
            Team t = sb.getTeam("line" + i);
            if (t != null) t.setPrefix(ItemSpec.c(lines[i]));
        }
    }
}
