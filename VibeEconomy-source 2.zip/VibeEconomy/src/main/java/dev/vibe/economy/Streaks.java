package dev.vibe.economy;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;

/**
 * Killstreak extras: milestone rewards, server broadcasts, a growing automatic bounty on hot streaks,
 * a payout for ending someone's streak, and best-streak records (/streak).
 * The streak counter itself lives in VibeEconomy; it calls onKill() after a valid kill.
 */
@SuppressWarnings("deprecation")
public final class Streaks implements TabExecutor {

    private final VibeEconomy plugin;
    private final File file;
    private final Map<UUID, Integer> best = new HashMap<>();

    public Streaks(VibeEconomy plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "streaks.yml");
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        for (String k : y.getKeys(false)) {
            try { best.put(UUID.fromString(k), y.getInt(k)); } catch (IllegalArgumentException ignored) { }
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<UUID, Integer> e : best.entrySet()) y.set(e.getKey().toString(), e.getValue());
        try { y.save(file); } catch (IOException e) { plugin.getLogger().severe("streaks.yml: " + e.getMessage()); }
    }

    public int best(UUID id) { return best.getOrDefault(id, 0); }

    // ---------------------------------------------------------------- rewards

    /** milestone kills -> reward section. Falls back to built-in defaults if config has none. */
    private TreeMap<Integer, Map<String, Object>> milestones() {
        TreeMap<Integer, Map<String, Object>> out = new TreeMap<>();
        ConfigurationSection rs = plugin.getConfig().getConfigurationSection("killstreak.rewards");
        if (rs != null) {
            for (String k : rs.getKeys(false)) {
                ConfigurationSection s = rs.getConfigurationSection(k);
                if (s == null) continue;
                try { out.put(Integer.parseInt(k), s.getValues(false)); } catch (NumberFormatException ignored) { }
            }
        }
        if (out.isEmpty()) {
            out.put(3, Map.of("money", 2500));
            out.put(5, Map.of("money", 10000, "shards", 3));
            out.put(10, Map.of("money", 50000, "shards", 10, "key", "vanta"));
            out.put(15, Map.of("money", 100000, "shards", 20, "key", "void"));
            out.put(25, Map.of("money", 500000, "shards", 50, "key", "legend"));
        }
        return out;
    }

    private static double num(Object o) { return o instanceof Number n ? n.doubleValue() : 0; }

    /** Called by VibeEconomy after a valid PvP kill. streak = killer's new streak, victimStreak = streak just ended. */
    public void onKill(Player killer, Player victim, int streak, int victimStreak) {
        UUID k = killer.getUniqueId();
        if (streak > best.getOrDefault(k, 0)) { best.put(k, streak); save(); }

        // ended someone's streak
        if (victimStreak >= 3) {
            double bonus = victimStreak * plugin.getConfig().getDouble("killstreak.shutdown-money-per-streak", 1000);
            if (bonus > 0) {
                plugin.deposit(k, bonus);
                plugin.record(k, "Ended " + victim.getName() + "'s " + victimStreak + " streak", bonus);
            }
            Bukkit.broadcastMessage(ItemSpec.c("&c&l[STREAK] &e" + killer.getName() + " &fended &e" + victim.getName()
                    + "&f's &c" + victimStreak + " kill streak&f!" + (bonus > 0 ? " &a+" + plugin.money(bonus).replace(".00", "") : "")));
        }

        // milestone reward
        TreeMap<Integer, Map<String, Object>> ms = milestones();
        Map<String, Object> reward = ms.get(streak);
        boolean milestone = reward != null;
        int repeat = plugin.getConfig().getInt("killstreak.repeat-every", 5);
        if (reward == null && repeat > 0 && streak > ms.lastKey() && (streak - ms.lastKey()) % repeat == 0) {
            reward = ms.get(ms.lastKey());
            milestone = true;
        }
        if (reward != null) giveReward(killer, streak, reward);

        // automatic bounty that grows while the streak survives (server-funded)
        int bountyStart = plugin.getConfig().getInt("killstreak.bounty-start", 5);
        if (streak >= bountyStart && plugin.extras() != null) {
            double per = plugin.getConfig().getDouble("killstreak.bounty-per-kill", 5000);
            double max = plugin.getConfig().getDouble("killstreak.max-auto-bounty", 250000);
            double add = Math.min(per, max - plugin.extras().bountyOf(k));
            if (add > 0) plugin.extras().addServerBounty(k, add);
        }

        // announce
        int announceAt = plugin.getConfig().getInt("killstreak.broadcast-at", 5);
        if (streak >= announceAt && (milestone || streak % 5 == 0)) {
            double b = plugin.extras() == null ? 0 : plugin.extras().bountyOf(k);
            Bukkit.broadcastMessage(ItemSpec.c("&c&l[STREAK] &e" + killer.getName() + " &fis on a &c" + streak + " kill streak&f!"
                    + (b > 0 ? " &7Bounty: &a" + plugin.money(b).replace(".00", "") : "")));
        }
    }

    private void giveReward(Player p, int streak, Map<String, Object> r) {
        UUID id = p.getUniqueId();
        StringBuilder sb = new StringBuilder("&6&l[STREAK] &f" + streak + " kills! &7Reward:");
        double money = num(r.get("money"));
        long shards = (long) num(r.get("shards"));
        Object key = r.get("key");
        if (money > 0) {
            plugin.deposit(id, money);
            plugin.record(id, streak + " killstreak reward", money);
            sb.append(" &a").append(plugin.money(money).replace(".00", ""));
        }
        if (shards > 0) {
            plugin.addShards(id, shards);
            plugin.recordShards(id, streak + " killstreak reward", shards);
            sb.append(" &d").append(shards).append(" shards");
        }
        if (key instanceof String ks && plugin.crates() != null && plugin.crates().hasKeyType(ks)) {
            plugin.crates().giveKey(p, ks, 1);
            sb.append(" ").append(plugin.crates().keyName(ks.toLowerCase()));
        }
        plugin.msg(p, sb.toString());
    }

    // ---------------------------------------------------------------- /streak

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (a.length >= 1 && a[0].equalsIgnoreCase("top")) {
            List<Map.Entry<UUID, Integer>> all = new ArrayList<>(best.entrySet());
            all.sort((x, y) -> Integer.compare(y.getValue(), x.getValue()));
            if (all.isEmpty()) { plugin.msg(s, "&7No streaks recorded yet."); return true; }
            StringBuilder sb = new StringBuilder("&6&lBest killstreaks");
            int i = 0;
            for (Map.Entry<UUID, Integer> e : all) {
                if (i++ >= 10) break;
                String n = Bukkit.getOfflinePlayer(e.getKey()).getName();
                sb.append("\n&e").append(i).append(". &f").append(n == null ? "Unknown" : n).append(" &7- &c").append(e.getValue());
            }
            plugin.msg(s, sb.toString());
            return true;
        }
        OfflinePlayer t;
        if (a.length >= 1) t = Bukkit.getOfflinePlayer(a[0]);
        else if (s instanceof Player p) t = p;
        else { plugin.msg(s, "&cSpecify a player."); return true; }
        if (!t.hasPlayedBefore() && !t.isOnline()) { plugin.msg(s, "&cPlayer not found."); return true; }
        double bounty = plugin.extras() == null ? 0 : plugin.extras().bountyOf(t.getUniqueId());
        plugin.msg(s, "&6&l" + t.getName() + "'s streak\n&7Current: &c" + plugin.getStreak(t.getUniqueId())
                + " &8| &7Best: &c" + best(t.getUniqueId()) + (bounty > 0 ? "\n&7Bounty: &a" + plugin.money(bounty) : "")
                + "\n&8Rewards at: &7" + milestones().keySet());
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length != 1) return out;
        String cur = a[0].toLowerCase();
        if ("top".startsWith(cur)) out.add("top");
        for (Player p : Bukkit.getOnlinePlayers()) if (p.getName().toLowerCase().startsWith(cur)) out.add(p.getName());
        return out;
    }
}
