package dev.vibe.economy;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

/** PvP tuning, all optional in config.yml under "pvp". */
public final class Pvp implements Listener {

    private final VibeEconomy plugin;

    public Pvp(VibeEconomy plugin) {
        this.plugin = plugin;
        for (Player p : Bukkit.getOnlinePlayers()) apply(p);
    }

    private void apply(Player p) {
        AttributeInstance speed = p.getAttribute(Attribute.ATTACK_SPEED);
        if (speed != null) {
            if (plugin.getConfig().getBoolean("pvp.no-attack-cooldown", false)) {
                speed.setBaseValue(plugin.getConfig().getDouble("pvp.attack-speed", 16.0));   // 1.8-style: no swing cooldown
            } else if (speed.getBaseValue() > 4.0) {
                speed.setBaseValue(4.0);                                                       // vanilla default
            }
        }
        int ticks = plugin.getConfig().getInt("pvp.hit-delay-ticks", 20);
        p.setMaximumNoDamageTicks(Math.max(1, ticks));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> { if (p.isOnline()) apply(p); }, 5L);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> { if (p.isOnline()) apply(p); }, 5L);
    }

    /** Scale end crystal damage to players (1.0 = vanilla). */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onCrystalDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player)) return;
        double mult = plugin.getConfig().getDouble("pvp.crystal-damage-multiplier", 1.0);
        if (mult == 1.0) return;
        if (e instanceof EntityDamageByEntityEvent be && be.getDamager() instanceof EnderCrystal) {
            e.setDamage(e.getDamage() * Math.max(0, mult));
        }
    }

    /** No elytra escapes while in combat. */
    @EventHandler(ignoreCancelled = true)
    public void onGlide(EntityToggleGlideEvent e) {
        if (!(e.getEntity() instanceof Player p) || !e.isGliding()) return;
        if (!plugin.getConfig().getBoolean("pvp.block-elytra-in-combat", true)) return;
        if (plugin.travel() != null && plugin.travel().inCombat(p) && !p.hasPermission("vibeeconomy.admin")) {
            e.setCancelled(true);
            plugin.msg(p, "&cYou can't use an elytra while in combat.");
        }
    }

    /** Optional longer ender pearl cooldown. */
    @EventHandler(ignoreCancelled = true)
    public void onPearl(ProjectileLaunchEvent e) {
        if (!(e.getEntity() instanceof EnderPearl pearl) || !(pearl.getShooter() instanceof Player p)) return;
        int secs = plugin.getConfig().getInt("pvp.pearl-cooldown-seconds", 0);
        if (secs > 0) p.setCooldown(Material.ENDER_PEARL, secs * 20);
    }
}
