package dev.vibe.economy;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Player teams: invites, team chat, team home, friendly-fire protection. */
public final class Teams implements Listener, TabExecutor {

    private static final class Team {
        final String key; String name; UUID owner; Location home;
        final Set<UUID> members = new LinkedHashSet<>();
        Team(String key, String name, UUID owner) { this.key = key; this.name = name; this.owner = owner; members.add(owner); }
    }

    private static final class Invite {
        final String teamKey; final long expires;
        Invite(String teamKey, long expires) { this.teamKey = teamKey; this.expires = expires; }
    }

    private final VibeEconomy plugin;
    private final File file;
    private final Map<String, Team> teams = new HashMap<>();
    private final Map<UUID, String> memberOf = new ConcurrentHashMap<>();
    private final Map<UUID, Invite> invites = new HashMap<>();
    private final Set<UUID> chatToggle = ConcurrentHashMap.newKeySet();

    public Teams(VibeEconomy plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "teams.yml");
        load();
    }

    // ---------------------------------------------------------------- storage

    private void load() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection ts = y.getConfigurationSection("teams");
        if (ts == null) return;
        for (String key : ts.getKeys(false)) {
            ConfigurationSection s = ts.getConfigurationSection(key);
            if (s == null) continue;
            try {
                Team t = new Team(key, s.getString("name", key), UUID.fromString(s.getString("owner", "")));
                for (String m : s.getStringList("members")) {
                    try { t.members.add(UUID.fromString(m)); } catch (IllegalArgumentException ignored) { }
                }
                t.home = s.getLocation("home");
                teams.put(key, t);
                for (UUID m : t.members) memberOf.put(m, key);
            } catch (IllegalArgumentException ignored) { }
        }
    }

    private void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Team t : teams.values()) {
            String k = "teams." + t.key;
            y.set(k + ".name", t.name);
            y.set(k + ".owner", t.owner.toString());
            List<String> ms = new ArrayList<>();
            for (UUID m : t.members) ms.add(m.toString());
            y.set(k + ".members", ms);
            if (t.home != null) y.set(k + ".home", t.home);
        }
        try { y.save(file); } catch (IOException e) { plugin.getLogger().severe("teams.yml: " + e.getMessage()); }
    }

    // ---------------------------------------------------------------- helpers

    private Team teamOf(UUID id) {
        String k = memberOf.get(id);
        return k == null ? null : teams.get(k);
    }

    public String teamName(UUID id) {
        Team t = teamOf(id);
        return t == null ? null : t.name;
    }

    public boolean sameTeam(Player a, Player b) {
        String x = memberOf.get(a.getUniqueId());
        return x != null && x.equals(memberOf.get(b.getUniqueId()));
    }

    private String nameOf(UUID id) {
        String n = Bukkit.getOfflinePlayer(id).getName();
        return n == null ? "Unknown" : n;
    }

    private void tell(Team t, String text) {
        for (UUID m : t.members) {
            Player p = Bukkit.getPlayer(m);
            if (p != null) plugin.msg(p, text);
        }
    }

    // ---------------------------------------------------------------- commands

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (!(s instanceof Player p)) { plugin.msg(s, "&cPlayers only."); return true; }
        if (a.length == 0) {
            plugin.msg(p, "&6&lTeam commands\n&e/team create <name> &7- create a team\n&e/team invite <player> &7- invite (owner)\n"
                    + "&e/team accept &7- join an invite\n&e/team leave &7- leave\n&e/team kick <player> &7- remove (owner)\n"
                    + "&e/team disband &7- delete (owner)\n&e/team info [team] &7- details\n&e/team list &7- all teams\n"
                    + "&e/team chat &7- toggle team chat\n&e/team home &7| &e/team sethome");
            return true;
        }
        switch (a[0].toLowerCase()) {
            case "create":  create(p, a); break;
            case "invite":  invite(p, a); break;
            case "accept":  accept(p); break;
            case "leave":   leave(p); break;
            case "kick":    kick(p, a); break;
            case "disband": disband(p); break;
            case "info":    info(p, a); break;
            case "list":    list(p); break;
            case "chat":    chat(p); break;
            case "home":    home(p); break;
            case "sethome": setHome(p); break;
            default: plugin.msg(p, "&cUnknown subcommand. Type /team for help.");
        }
        return true;
    }

    private void create(Player p, String[] a) {
        if (teamOf(p.getUniqueId()) != null) { plugin.msg(p, "&cYou're already in a team."); return; }
        if (a.length < 2 || !a[1].matches("[A-Za-z0-9]{3,12}")) { plugin.msg(p, "&cTeam names are 3-12 letters or numbers."); return; }
        String key = a[1].toLowerCase();
        if (teams.containsKey(key)) { plugin.msg(p, "&cThat team name is taken."); return; }
        double cost = plugin.getConfig().getDouble("teams.create-cost", 5000);
        if (cost > 0 && !plugin.withdraw(p.getUniqueId(), cost)) { plugin.msg(p, "&cCreating a team costs " + plugin.money(cost) + "."); return; }
        if (cost > 0) plugin.record(p.getUniqueId(), "Created team " + a[1], -cost);
        Team t = new Team(key, a[1], p.getUniqueId());
        teams.put(key, t);
        memberOf.put(p.getUniqueId(), key);
        save();
        plugin.msg(p, "&aTeam &f" + t.name + "&a created! Invite players with &f/team invite <player>&a.");
    }

    private void invite(Player p, String[] a) {
        Team t = teamOf(p.getUniqueId());
        if (t == null || !t.owner.equals(p.getUniqueId())) { plugin.msg(p, "&cOnly a team owner can invite."); return; }
        if (a.length < 2) { plugin.msg(p, "&cUsage: /team invite <player>"); return; }
        Player target = Bukkit.getPlayerExact(a[1]);
        if (target == null) { plugin.msg(p, "&cThat player isn't online."); return; }
        if (teamOf(target.getUniqueId()) != null) { plugin.msg(p, "&cThat player is already in a team."); return; }
        int max = plugin.getConfig().getInt("teams.max-members", 5);
        if (t.members.size() >= max) { plugin.msg(p, "&cYour team is full (" + max + ")."); return; }
        invites.put(target.getUniqueId(), new Invite(t.key, System.currentTimeMillis() + 60_000L));
        plugin.msg(p, "&aInvited &f" + target.getName() + "&a.");
        plugin.msg(target, "&e" + p.getName() + " &finvited you to team &e" + t.name + "&f. Type &a/team accept &f(60s).");
    }

    private void accept(Player p) {
        Invite inv = invites.remove(p.getUniqueId());
        if (inv == null || inv.expires < System.currentTimeMillis()) { plugin.msg(p, "&cYou have no pending team invite."); return; }
        if (teamOf(p.getUniqueId()) != null) { plugin.msg(p, "&cYou're already in a team."); return; }
        Team t = teams.get(inv.teamKey);
        if (t == null) { plugin.msg(p, "&cThat team no longer exists."); return; }
        if (t.members.size() >= plugin.getConfig().getInt("teams.max-members", 5)) { plugin.msg(p, "&cThat team is full."); return; }
        t.members.add(p.getUniqueId());
        memberOf.put(p.getUniqueId(), t.key);
        save();
        tell(t, "&a" + p.getName() + " joined the team!");
    }

    private void leave(Player p) {
        Team t = teamOf(p.getUniqueId());
        if (t == null) { plugin.msg(p, "&cYou're not in a team."); return; }
        if (t.owner.equals(p.getUniqueId())) { plugin.msg(p, "&cYou own this team. Use &f/team disband&c."); return; }
        t.members.remove(p.getUniqueId());
        memberOf.remove(p.getUniqueId());
        chatToggle.remove(p.getUniqueId());
        save();
        plugin.msg(p, "&7You left &f" + t.name + "&7.");
        tell(t, "&c" + p.getName() + " left the team.");
    }

    private void kick(Player p, String[] a) {
        Team t = teamOf(p.getUniqueId());
        if (t == null || !t.owner.equals(p.getUniqueId())) { plugin.msg(p, "&cOnly a team owner can kick."); return; }
        if (a.length < 2) { plugin.msg(p, "&cUsage: /team kick <player>"); return; }
        UUID target = null;
        for (UUID m : t.members) if (nameOf(m).equalsIgnoreCase(a[1])) target = m;
        if (target == null) { plugin.msg(p, "&cThat player isn't in your team."); return; }
        if (target.equals(p.getUniqueId())) { plugin.msg(p, "&cYou can't kick yourself."); return; }
        t.members.remove(target);
        memberOf.remove(target);
        chatToggle.remove(target);
        save();
        tell(t, "&c" + nameOf(target) + " was removed from the team.");
        Player tp = Bukkit.getPlayer(target);
        if (tp != null) plugin.msg(tp, "&cYou were removed from team &f" + t.name + "&c.");
    }

    private void disband(Player p) {
        Team t = teamOf(p.getUniqueId());
        if (t == null || !t.owner.equals(p.getUniqueId())) { plugin.msg(p, "&cOnly a team owner can disband."); return; }
        tell(t, "&cTeam &f" + t.name + " &cwas disbanded.");
        for (UUID m : t.members) { memberOf.remove(m); chatToggle.remove(m); }
        teams.remove(t.key);
        save();
    }

    private void info(Player p, String[] a) {
        Team t = a.length >= 2 ? teams.get(a[1].toLowerCase()) : teamOf(p.getUniqueId());
        if (t == null) { plugin.msg(p, "&cTeam not found."); return; }
        List<String> names = new ArrayList<>();
        for (UUID m : t.members) {
            boolean on = Bukkit.getPlayer(m) != null;
            names.add((on ? "&a" : "&7") + nameOf(m) + (m.equals(t.owner) ? "&e*" : ""));
        }
        plugin.msg(p, "&6&lTeam " + t.name + " &7(" + t.members.size() + "/" + plugin.getConfig().getInt("teams.max-members", 5)
                + ")\n&7Members: " + String.join("&7, ", names) + "\n&7(&e*&7 = owner, &agreen&7 = online)");
    }

    private void list(Player p) {
        if (teams.isEmpty()) { plugin.msg(p, "&7No teams yet."); return; }
        List<Team> all = new ArrayList<>(teams.values());
        all.sort((x, y) -> Integer.compare(y.members.size(), x.members.size()));
        StringBuilder sb = new StringBuilder("&6&lTeams");
        int i = 0;
        for (Team t : all) {
            if (i++ >= 10) break;
            sb.append("\n&e").append(t.name).append(" &7- ").append(t.members.size()).append(" member(s)");
        }
        plugin.msg(p, sb.toString());
    }

    private void chat(Player p) {
        if (teamOf(p.getUniqueId()) == null) { plugin.msg(p, "&cYou're not in a team."); return; }
        if (chatToggle.remove(p.getUniqueId())) plugin.msg(p, "&7Team chat &coff&7. You're talking in public chat.");
        else { chatToggle.add(p.getUniqueId()); plugin.msg(p, "&7Team chat &aon&7. Only your team sees what you type."); }
    }

    private void home(Player p) {
        Team t = teamOf(p.getUniqueId());
        if (t == null) { plugin.msg(p, "&cYou're not in a team."); return; }
        if (t.home == null || t.home.getWorld() == null) { plugin.msg(p, "&cYour team has no home. The owner can use &f/team sethome&c."); return; }
        plugin.travel().teleport(p, t.home, "team home");
    }

    private void setHome(Player p) {
        Team t = teamOf(p.getUniqueId());
        if (t == null || !t.owner.equals(p.getUniqueId())) { plugin.msg(p, "&cOnly a team owner can set the team home."); return; }
        t.home = p.getLocation();
        save();
        plugin.msg(p, "&aTeam home set.");
    }

    // ---------------------------------------------------------------- events

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (plugin.getConfig().getBoolean("teams.friendly-fire", false)) return;
        if (!(e.getEntity() instanceof Player victim)) return;
        Player damager = null;
        if (e.getDamager() instanceof Player d1) damager = d1;
        else if (e.getDamager() instanceof Projectile pr && pr.getShooter() instanceof Player d2) damager = d2;
        if (damager == null || damager.getUniqueId().equals(victim.getUniqueId())) return;
        if (plugin.duels() != null && plugin.duels().inDuel(victim) && plugin.duels().inDuel(damager)) return;
        if (sameTeam(damager, victim)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent e) {
        Player p = e.getPlayer();
        if (!chatToggle.contains(p.getUniqueId())) return;
        Team t = teamOf(p.getUniqueId());
        if (t == null) { chatToggle.remove(p.getUniqueId()); return; }
        e.setCancelled(true);
        String line = ItemSpec.c("&8[&bTeam&8] &f" + p.getName() + "&7: &f") + e.getMessage();
        for (UUID m : t.members) {
            Player mp = Bukkit.getPlayer(m);
            if (mp != null) mp.sendMessage(line);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        invites.remove(e.getPlayer().getUniqueId());
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            for (String o : new String[]{"create", "invite", "accept", "leave", "kick", "disband", "info", "list", "chat", "home", "sethome"}) {
                if (o.startsWith(a[0].toLowerCase())) out.add(o);
            }
        } else if (a.length == 2 && (a[0].equalsIgnoreCase("invite") || a[0].equalsIgnoreCase("kick"))) {
            for (Player p : Bukkit.getOnlinePlayers()) if (p.getName().toLowerCase().startsWith(a[1].toLowerCase())) out.add(p.getName());
        } else if (a.length == 2 && a[0].equalsIgnoreCase("info")) {
            for (Team t : teams.values()) if (t.key.startsWith(a[1].toLowerCase())) out.add(t.name);
        }
        return out;
    }
}
