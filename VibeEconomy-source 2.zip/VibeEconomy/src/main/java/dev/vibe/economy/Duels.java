package dev.vibe.economy;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * 1v1 duels with optional money wagers. Accepting a duel sends both players to the same random
 * location (like an RTP), they fight, and everyone is returned afterwards. Players keep their items.
 */
@SuppressWarnings("deprecation")
public final class Duels implements Listener, TabExecutor {

    private static final class Request {
        final UUID from; final double wager; final long expires;
        Request(UUID from, double wager, long expires) { this.from = from; this.wager = wager; this.expires = expires; }
    }

    private static final class Duel {
        final UUID a, b; final double wager; final Location origA, origB;
        boolean active = false;
        BukkitTask countdown, timeout;
        Duel(UUID a, UUID b, double wager, Location origA, Location origB) {
            this.a = a; this.b = b; this.wager = wager; this.origA = origA; this.origB = origB;
        }
    }

    private static final int DIED = 0, FORFEIT = 1, QUIT = 2;

    private final VibeEconomy plugin;
    private final Map<UUID, Request> requests = new HashMap<>();
    private final Map<UUID, Duel> duels = new HashMap<>();
    private final Map<UUID, Location> returnOnRespawn = new HashMap<>();
    private final Map<UUID, Location> returnOnJoin = new HashMap<>();

    public Duels(VibeEconomy plugin) { this.plugin = plugin; }

    public boolean inDuel(Player p) { return duels.containsKey(p.getUniqueId()); }

    private String name(UUID id) {
        String n = Bukkit.getOfflinePlayer(id).getName();
        return n == null ? "Unknown" : n;
    }

    private void heal(Player p) {
        p.setHealth(p.getMaxHealth());
        p.setFoodLevel(20);
        p.setSaturation(20f);
        p.setFireTicks(0);
    }

    // ---------------------------------------------------------------- commands

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (!(s instanceof Player p)) { plugin.msg(s, "&cPlayers only."); return true; }
        if (a.length == 0) {
            plugin.msg(p, "&6/duel <player> [wager] &7- challenge someone. You both teleport to a random spot.\n&6/duel accept | deny | forfeit");
            return true;
        }
        switch (a[0].toLowerCase()) {
            case "accept":  accept(p); break;
            case "deny":    deny(p); break;
            case "forfeit": forfeit(p); break;
            default:        challenge(p, a);
        }
        return true;
    }

    private void challenge(Player p, String[] a) {
        Player t = Bukkit.getPlayerExact(a[0]);
        if (t == null) { plugin.msg(p, "&cThat player isn't online."); return; }
        if (t.getUniqueId().equals(p.getUniqueId())) { plugin.msg(p, "&cYou can't duel yourself."); return; }
        if (inDuel(p) || inDuel(t)) { plugin.msg(p, "&cOne of you is already in a duel."); return; }
        if (plugin.travel().inCombat(p) || plugin.travel().inCombat(t)) { plugin.msg(p, "&cYou can't duel while in combat."); return; }
        double wager = 0;
        if (a.length >= 2) {
            Double w = VibeEconomy.parseMoney(a[1]);
            if (w == null) { plugin.msg(p, "&cInvalid wager."); return; }
            wager = w;
        }
        double max = plugin.getConfig().getDouble("duel.max-wager", 1000000);
        if (wager > max) { plugin.msg(p, "&cMax wager is " + plugin.money(max) + "."); return; }
        if (!plugin.has(p.getUniqueId(), wager)) { plugin.msg(p, "&cYou can't afford that wager."); return; }
        requests.put(t.getUniqueId(), new Request(p.getUniqueId(), wager, System.currentTimeMillis() + 60_000L));
        String w = wager > 0 ? " for &a" + plugin.money(wager) : "";
        plugin.msg(p, "&aDuel request sent to &f" + t.getName() + "&a" + w + ".");
        plugin.msg(t, "&6&l[DUEL] &e" + p.getName() + " &fchallenged you to a duel" + w + "&f! Type &a/duel accept &f(60s).");
    }

    private void deny(Player p) {
        Request r = requests.remove(p.getUniqueId());
        if (r == null) { plugin.msg(p, "&cNo pending duel request."); return; }
        Player from = Bukkit.getPlayer(r.from);
        if (from != null) plugin.msg(from, "&c" + p.getName() + " declined your duel.");
        plugin.msg(p, "&7Duel declined.");
    }

    private void accept(Player p) {
        Request r = requests.remove(p.getUniqueId());
        if (r == null || r.expires < System.currentTimeMillis()) { plugin.msg(p, "&cNo pending duel request."); return; }
        Player from = Bukkit.getPlayer(r.from);
        if (from == null) { plugin.msg(p, "&cThat player went offline."); return; }
        if (inDuel(p) || inDuel(from)) { plugin.msg(p, "&cOne of you is already in a duel."); return; }
        if (plugin.travel().inCombat(p) || plugin.travel().inCombat(from)) { plugin.msg(p, "&cYou can't duel while in combat."); return; }
        if (!plugin.has(from.getUniqueId(), r.wager) || !plugin.has(p.getUniqueId(), r.wager)) {
            plugin.msg(p, "&cA player can't afford the wager.");
            plugin.msg(from, "&cA player can't afford the wager.");
            return;
        }
        start(from, p, r.wager);
    }

    private void forfeit(Player p) {
        Duel d = duels.get(p.getUniqueId());
        if (d == null) { plugin.msg(p, "&cYou're not in a duel."); return; }
        UUID winner = d.a.equals(p.getUniqueId()) ? d.b : d.a;
        finish(d, winner, p.getUniqueId(), FORFEIT);
    }

    // ---------------------------------------------------------------- duel lifecycle

    private void start(Player a, Player b, double wager) {
        Duel d = new Duel(a.getUniqueId(), b.getUniqueId(), wager, a.getLocation(), b.getLocation());
        duels.put(a.getUniqueId(), d);
        duels.put(b.getUniqueId(), d);
        plugin.msg(a, "&6&l[DUEL] &7Finding a random spot for the fight...");
        plugin.msg(b, "&6&l[DUEL] &7Finding a random spot for the fight...");

        plugin.travel().randomSpot(base -> {
            if (duels.get(d.a) != d) return;           // duel already ended (someone left)
            Player pa = Bukkit.getPlayer(d.a), pb = Bukkit.getPlayer(d.b);
            if (base == null || pa == null || pb == null) {
                duels.remove(d.a);
                duels.remove(d.b);
                if (pa != null) plugin.msg(pa, "&cCouldn't find a spot. Duel cancelled.");
                if (pb != null) plugin.msg(pb, "&cCouldn't find a spot. Duel cancelled.");
                return;
            }
            pa.teleportAsync(plugin.travel().safeOffset(base, -5, 0));
            pb.teleportAsync(plugin.travel().safeOffset(base, 5, 0));
            heal(pa);
            heal(pb);
            String w = wager > 0 ? " &7(wager &a" + plugin.money(wager) + "&7)" : "";
            plugin.msg(pa, "&6&l[DUEL] &fDuel vs &e" + pb.getName() + w);
            plugin.msg(pb, "&6&l[DUEL] &fDuel vs &e" + pa.getName() + w);
            beginCountdown(d);
        });
    }

    private void beginCountdown(Duel d) {
        final int secs = Math.max(1, plugin.getConfig().getInt("duel.countdown-seconds", 5));
        d.countdown = new BukkitRunnable() {
            int left = secs;
            @Override public void run() {
                Player pa = Bukkit.getPlayer(d.a), pb = Bukkit.getPlayer(d.b);
                if (pa == null || pb == null) { cancel(); return; }
                if (left > 0) {
                    pa.sendTitle(ItemSpec.c("&e" + left), "", 0, 20, 0);
                    pb.sendTitle(ItemSpec.c("&e" + left), "", 0, 20, 0);
                    left--;
                    return;
                }
                d.active = true;
                pa.sendTitle(ItemSpec.c("&c&lFIGHT!"), "", 0, 30, 10);
                pb.sendTitle(ItemSpec.c("&c&lFIGHT!"), "", 0, 30, 10);
                cancel();
                long maxMin = Math.max(1, plugin.getConfig().getLong("duel.max-minutes", 5));
                d.timeout = Bukkit.getScheduler().runTaskLater(plugin, () -> draw(d, false), maxMin * 60L * 20L);
            }
        }.runTaskTimer(plugin, 20L, 20L);
    }

    private void endTasks(Duel d) {
        if (d.countdown != null) d.countdown.cancel();
        if (d.timeout != null) d.timeout.cancel();
    }

    private void finish(Duel d, UUID winner, UUID loser, int mode) {
        if (duels.get(d.a) != d) return;
        duels.remove(d.a);
        duels.remove(d.b);
        endTasks(d);

        Player w = Bukkit.getPlayer(winner);
        Player l = Bukkit.getPlayer(loser);
        double pot = 0;
        if (d.wager > 0) {
            double take = Math.min(d.wager, plugin.getBalance(loser));
            double tax = take * plugin.getConfig().getDouble("duel.wager-tax-percent", 5) / 100.0;
            plugin.setBalance(loser, plugin.getBalance(loser) - take);
            pot = Util.round2(take - tax);
            plugin.deposit(winner, pot);
            plugin.record(loser, "Duel lost vs " + name(winner), -take);
            plugin.record(winner, "Duel won vs " + name(loser), pot);
        }
        Bukkit.broadcastMessage(ItemSpec.c("&6&l[DUEL] &e" + name(winner) + " &fdefeated &e" + name(loser)
                + (pot > 0 ? " &7and won &a" + plugin.money(pot) : "") + "&f!"));

        Location wOrig = winner.equals(d.a) ? d.origA : d.origB;
        Location lOrig = loser.equals(d.a) ? d.origA : d.origB;

        if (w != null && w.isOnline()) {
            heal(w);
            Bukkit.getScheduler().runTaskLater(plugin, () -> { if (w.isOnline()) w.teleportAsync(wOrig); }, 60L);
        }
        if (mode == QUIT || l == null || !l.isOnline()) returnOnJoin.put(loser, lOrig);
        else if (mode == DIED) returnOnRespawn.put(loser, lOrig);
        else {
            heal(l);
            Bukkit.getScheduler().runTaskLater(plugin, () -> { if (l.isOnline()) l.teleportAsync(lOrig); }, 20L);
        }
    }

    private void draw(Duel d, boolean sync) {
        if (duels.get(d.a) != d) return;
        duels.remove(d.a);
        duels.remove(d.b);
        endTasks(d);
        UUID[] ids = {d.a, d.b};
        Location[] origs = {d.origA, d.origB};
        for (int i = 0; i < 2; i++) {
            Player pl = Bukkit.getPlayer(ids[i]);
            if (pl != null && pl.isOnline()) {
                plugin.msg(pl, "&6&l[DUEL] &eThe duel ended in a draw.");
                heal(pl);
                if (sync) pl.teleport(origs[i]); else pl.teleportAsync(origs[i]);
            } else {
                returnOnJoin.put(ids[i], origs[i]);
            }
        }
    }

    /** Called when the plugin disables. */
    public void shutdown() {
        Set<Duel> all = new HashSet<>(duels.values());
        for (Duel d : all) draw(d, true);
    }

    // ---------------------------------------------------------------- events

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent e) {
        Player dead = e.getEntity();
        Duel d = duels.get(dead.getUniqueId());
        if (d == null) return;
        e.setKeepInventory(true);
        e.setKeepLevel(true);
        e.getDrops().clear();
        e.setDroppedExp(0);
        e.setDeathMessage(null);
        UUID winner = d.a.equals(dead.getUniqueId()) ? d.b : d.a;
        finish(d, winner, dead.getUniqueId(), DIED);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        requests.remove(id);
        Duel d = duels.get(id);
        if (d == null) return;
        UUID winner = d.a.equals(id) ? d.b : d.a;
        finish(d, winner, id, QUIT);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onRespawn(PlayerRespawnEvent e) {
        Location r = returnOnRespawn.remove(e.getPlayer().getUniqueId());
        if (r != null && r.getWorld() != null) e.setRespawnLocation(r);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Location r = returnOnJoin.remove(p.getUniqueId());
        if (r != null && r.getWorld() != null) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> { if (p.isOnline()) p.teleportAsync(r); }, 5L);
        }
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        if (!e.hasChangedBlock()) return;
        Duel d = duels.get(e.getPlayer().getUniqueId());
        if (d != null && !d.active) e.setCancelled(true);
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length != 1) return out;
        String cur = a[0].toLowerCase();
        for (String o : new String[]{"accept", "deny", "forfeit"}) if (o.startsWith(cur)) out.add(o);
        for (Player p : Bukkit.getOnlinePlayers()) if (p.getName().toLowerCase().startsWith(cur)) out.add(p.getName());
        return out;
    }
}
