package dev.vibe.economy;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.RayTraceResult;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/** A pickaxe that mines a 3x3 area and stops working after a set time. Can be sold in /ah. */
public final class Drills implements Listener {

    private final VibeEconomy plugin;
    private final NamespacedKey tag;
    private final Set<UUID> busy = new HashSet<>();

    public Drills(VibeEconomy plugin) {
        this.plugin = plugin;
        this.tag = new NamespacedKey(plugin, "drill_expires");
    }

    public ItemStack create(int hours) {
        long expires = System.currentTimeMillis() + hours * 3_600_000L;
        ItemStack it = new ItemStack(Material.NETHERITE_PICKAXE);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(ItemSpec.c("&5&lVanta Drill"));
        String when = ZonedDateTime.now().plusHours(hours).format(DateTimeFormatter.ofPattern("MMM d, HH:mm z", Locale.US));
        meta.setLore(List.of(
                ItemSpec.c("&7Mines a &f3x3 &7area."),
                ItemSpec.c("&cExpires: &f" + when),
                ItemSpec.c("&8Can be sold in /ah. The timer keeps running.")));
        meta.addEnchant(Enchantment.EFFICIENCY, 5, true);
        meta.addEnchant(Enchantment.FORTUNE, 3, true);
        meta.setUnbreakable(true);
        meta.getPersistentDataContainer().set(tag, PersistentDataType.LONG, expires);
        it.setItemMeta(meta);
        return it;
    }

    private Long expiry(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(tag, PersistentDataType.LONG);
    }

    private BlockFace face(Player p, Block center) {
        RayTraceResult r = p.rayTraceBlocks(6.0);
        if (r != null && r.getHitBlock() != null && r.getHitBlock().equals(center) && r.getHitBlockFace() != null) {
            return r.getHitBlockFace();
        }
        float pitch = p.getLocation().getPitch();
        if (pitch > 60) return BlockFace.UP;
        if (pitch < -60) return BlockFace.DOWN;
        return p.getFacing().getOppositeFace();
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (busy.contains(p.getUniqueId())) return;
        ItemStack tool = p.getInventory().getItemInMainHand();
        Long exp = expiry(tool);
        if (exp == null) return;
        if (exp < System.currentTimeMillis()) {
            plugin.msg(p, "&cYour Vanta Drill has expired. It only mines one block now.");
            return;
        }
        Block center = e.getBlock();
        BlockFace face = face(p, center);
        int ax = Math.abs(face.getModX());
        int ay = Math.abs(face.getModY());

        for (int a = -1; a <= 1; a++) {
            for (int b = -1; b <= 1; b++) {
                if (a == 0 && b == 0) continue;
                int dx, dy, dz;
                if (ay == 1) { dx = a; dy = 0; dz = b; }
                else if (ax == 1) { dx = 0; dy = a; dz = b; }
                else { dx = a; dy = b; dz = 0; }
                Block t = center.getRelative(dx, dy, dz);
                Material m = t.getType();
                if (m.isAir() || !m.isBlock() || t.isLiquid() || m.getHardness() < 0) continue;
                BlockBreakEvent ev = new BlockBreakEvent(t, p);
                busy.add(p.getUniqueId());
                try { Bukkit.getPluginManager().callEvent(ev); }
                finally { busy.remove(p.getUniqueId()); }
                if (ev.isCancelled()) continue;
                if (ev.isDropItems()) t.breakNaturally(tool);
                else t.setType(Material.AIR);
            }
        }
    }
}
