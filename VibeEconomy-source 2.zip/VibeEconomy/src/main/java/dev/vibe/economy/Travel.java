package dev.vibe.economy;

import org.bukkit.Bukkit;
import org.bukkit.HeightMap;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.function.Consumer;

/** Homes, TPA, spawn, RTP, RTP queue, teleport warmups and combat tagging. */
public final class Travel implements Listener, TabExecutor {

    public static final String[] COMMANDS = {"sethome", "home", "delhome", "homes", "tpa", "tpahere",
            "tpaccept", "tpdeny", "spawn", "rtp", "rtpqueue"};

    private static final class Tpa {
        final UUID from; final boolean here; final long expires;
        Tpa(UUID from, boolean here, long expires) { this.from = from; this.here = here; this.expires = expires; }
    }

    private final VibeEconomy plugin;
    private final File homesFile, locFile;
    private final YamlConfiguration homes, locs;
    private final Map<UUID, BukkitTask> warmups = new HashMap<>();
    private final Map<UUID, Long> combat = new HashMap<>();
    private final Map<UUID, Tpa> requests = new HashMap<>();   // key = player who received the request
    private final Map<UUID, Long> rtpCooldown = new HashMap<>();
    private final List<UUID> queue = new ArrayList<>();
    private BukkitTask queueTask;
    private final Random rnd = new Random();

    public Travel(VibeEconomy plugin) {
        this.plugin = plugin;
        homesFile = new File(plugin.getDataFolder(), "homes.yml");
        locFile = new File(plugin.getDataFolder(), "locations.yml");
        homes = YamlConfiguration.loadConfiguration(homesFile);
        locs = YamlConfiguration.loadConfiguration(locFile);
    }

    private void saveHomes() {
        try { homes.save(homesFile); } catch (IOException e) { plugin.getLogger().severe("homes.yml: " + e.getMessage()); }
    }

    private void saveLocs() {
        try { locs.save(locFile); } catch (IOException e) { plugin.getLogger().severe("locations.yml: " + e.getMessage()); }
    }

    // ---------------------------------------------------------------- spawn

    public Location getSpawn() {
        return Bukkit.getWorlds().get(0).getSpawnLocation();
    }

    // ---------------------------------------------------------------- combat tag

    public boolean inCombat(Player p) {
        Long t = combat.get(p.getUniqueId());
        return t != null && t > System.currentTimeMillis();
    }

    private long combatLeft(Player p) {
        Long t = combat.get(p.getUniqueId());
        return t == null ? 0 : Math.max(0, (t - System.currentTimeMillis() + 999) / 1000);
    }

    private void tag(Player p) {
        long secs = plugin.getConfig().getLong("combat.tag-seconds", 15);
        combat.put(p.getUniqueId(), System.currentTimeMillis() + secs * 1000L);
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPvp(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;
        Player damager = null;
        if (e.getDamager() instanceof Player d1) damager = d1;
        else if (e.getDamager() instanceof Projectile pr && pr.getShooter() instanceof Player d2) damager = d2;
        if (damager == null || damager.getUniqueId().equals(victim.getUniqueId())) return;
        if (plugin.duels() != null && plugin.duels().inDuel(victim)) return;
        tag(victim);
        tag(damager);
    }

    @EventHandler(ignoreCancelled = true)
    public void onAnyDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p && warmups.containsKey(p.getUniqueId())) {
            cancelWarmup(p, "&cTeleport cancelled: you took damage.");
        }
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        if (!e.hasChangedBlock()) return;
        Player p = e.getPlayer();
        if (warmups.containsKey(p.getUniqueId())) cancelWarmup(p, "&cTeleport cancelled because you moved.");
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        combat.remove(e.getEntity().getUniqueId());
        cancelWarmup(e.getEntity(), null);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        cancelWarmup(p, null);
        queue.remove(id);
        requests.remove(id);
        boolean dueling = plugin.duels() != null && plugin.duels().inDuel(p);
        if (inCombat(p) && !dueling && plugin.getConfig().getBoolean("combat.kill-on-logout", false)) {
            p.setHealth(0);
        }
        combat.remove(id);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (!p.hasPlayedBefore() && plugin.getConfig().getBoolean("spawn.teleport-new-players", true)) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> { if (p.isOnline()) p.teleportAsync(getSpawn()); }, 3L);
        }
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        if (!plugin.getConfig().getBoolean("spawn.respawn-at-spawn", true)) return;
        if (e.isBedSpawn() || e.isAnchorSpawn()) return;
        e.setRespawnLocation(getSpawn());
    }

    // ---------------------------------------------------------------- teleport core

    private void cancelWarmup(Player p, String message) {
        BukkitTask t = warmups.remove(p.getUniqueId());
        if (t != null) {
            t.cancel();
            if (message != null) plugin.msg(p, message);
        }
    }

    public void teleport(Player p, Location dest, String what) {
        if (plugin.duels() != null && plugin.duels().inDuel(p)) {
            plugin.msg(p, "&cYou can't teleport during a duel.");
            return;
        }
        boolean admin = p.hasPermission("vibeeconomy.admin");
        if (inCombat(p) && !admin) {
            plugin.msg(p, "&cYou can't teleport while in combat (&f" + combatLeft(p) + "s&c left).");
            return;
        }
        int delay = plugin.getConfig().getInt("teleport.warmup-seconds", 3);
        if (delay <= 0 || admin) { go(p, dest); return; }
        cancelWarmup(p, null);
        plugin.msg(p, "&eTeleporting to &f" + what + "&e in &f" + delay + "s&e. Don't move!");
        BukkitTask t = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            warmups.remove(p.getUniqueId());
            if (!p.isOnline()) return;
            if (inCombat(p)) { plugin.msg(p, "&cTeleport cancelled: you are in combat."); return; }
            go(p, dest);
        }, delay * 20L);
        warmups.put(p.getUniqueId(), t);
    }

    private void go(Player p, Location dest) {
        p.teleportAsync(dest);
        plugin.msg(p, "&aTeleported!");
    }

    // ---------------------------------------------------------------- homes

    private ConfigurationSection homeSection(UUID id) { return homes.getConfigurationSection("homes." + id); }

    public int extraHomes(UUID id) { return homes.getInt("extra." + id, 0); }

    public boolean canBuyHomeSlot(UUID id) {
        return extraHomes(id) < plugin.getConfig().getInt("homes.max-extra-slots", 5);
    }

    public void addExtraHome(UUID id) {
        homes.set("extra." + id, extraHomes(id) + 1);
        saveHomes();
    }

    private int homeLimit(Player p) {
        if (p.hasPermission("vibeeconomy.homes.unlimited")) return 999;
        int limit = plugin.getConfig().getInt("homes.default-limit", 1);
        for (int i = 50; i > limit; i--) {
            if (p.hasPermission("vibeeconomy.homes." + i)) { limit = i; break; }
        }
        return limit + extraHomes(p.getUniqueId());
    }

    private boolean cmdSetHome(Player p, String[] a) {
        String name = a.length > 0 ? a[0].toLowerCase() : "home";
        if (!name.matches("[a-z0-9_-]{1,16}")) {
            plugin.msg(p, "&cHome names: 1-16 letters, numbers, - or _.");
            return true;
        }
        UUID id = p.getUniqueId();
        ConfigurationSection sec = homeSection(id);
        boolean exists = sec != null && sec.contains(name);
        int count = sec == null ? 0 : sec.getKeys(false).size();
        int limit = homeLimit(p);
        if (!exists && count >= limit) {
            plugin.msg(p, "&cYou've used all &f" + limit + " &chome slot(s). Buy more in &f/shop qol&c.");
            return true;
        }
        homes.set("homes." + id + "." + name, p.getLocation());
        saveHomes();
        plugin.msg(p, "&aHome &f" + name + "&a set. (" + (exists ? count : count + 1) + "/" + limit + ")");
        return true;
    }

    private boolean cmdHome(Player p, String[] a) {
        UUID id = p.getUniqueId();
        ConfigurationSection sec = homeSection(id);
        if (sec == null || sec.getKeys(false).isEmpty()) {
            plugin.msg(p, "&cYou have no homes. Use &f/sethome&c.");
            return true;
        }
        String name;
        if (a.length > 0) name = a[0].toLowerCase();
        else if (sec.contains("home")) name = "home";
        else if (sec.getKeys(false).size() == 1) name = sec.getKeys(false).iterator().next();
        else name = null;
        if (name == null || !sec.contains(name)) {
            plugin.msg(p, "&eYour homes: &f" + String.join(", ", sec.getKeys(false)));
            return true;
        }
        Location l = homes.getLocation("homes." + id + "." + name);
        if (l == null || l.getWorld() == null) { plugin.msg(p, "&cThat home's world no longer exists."); return true; }
        teleport(p, l, "home " + name);
        return true;
    }

    private boolean cmdDelHome(Player p, String[] a) {
        if (a.length == 0) { plugin.msg(p, "&cUsage: /delhome <name>"); return true; }
        String name = a[0].toLowerCase();
        ConfigurationSection sec = homeSection(p.getUniqueId());
        if (sec == null || !sec.contains(name)) { plugin.msg(p, "&cNo home called " + name + "."); return true; }
        homes.set("homes." + p.getUniqueId() + "." + name, null);
        saveHomes();
        plugin.msg(p, "&aHome &f" + name + "&a deleted.");
        return true;
    }

    private boolean cmdHomes(Player p) {
        ConfigurationSection sec = homeSection(p.getUniqueId());
        int count = sec == null ? 0 : sec.getKeys(false).size();
        plugin.msg(p, "&eHomes (&f" + count + "/" + homeLimit(p) + "&e): &f"
                + (count == 0 ? "none" : String.join(", ", sec.getKeys(false))));
        return true;
    }

    // ---------------------------------------------------------------- TPA

    private boolean cmdTpa(Player p, String[] a, boolean here) {
        if (a.length == 0) { plugin.msg(p, "&cUsage: /" + (here ? "tpahere" : "tpa") + " <player>"); return true; }
        Player t = Bukkit.getPlayerExact(a[0]);
        if (t == null) { plugin.msg(p, "&cThat player isn't online."); return true; }
        if (t.getUniqueId().equals(p.getUniqueId())) { plugin.msg(p, "&cYou can't teleport to yourself."); return true; }
        if (!plugin.settings().get(t.getUniqueId(), "tpa")) { plugin.msg(p, "&cThat player has teleport requests turned off."); return true; }
        long expire = plugin.getConfig().getLong("tpa.expire-seconds", 60);
        requests.put(t.getUniqueId(), new Tpa(p.getUniqueId(), here, System.currentTimeMillis() + expire * 1000L));
        plugin.msg(p, "&aTeleport request sent to &f" + t.getName() + "&a. It expires in " + expire + "s.");
        plugin.msg(t, "&e" + p.getName() + " &fwants " + (here ? "you to teleport to them" : "to teleport to you")
                + ". Type &a/tpaccept &for &c/tpdeny&f.");
        return true;
    }

    private boolean cmdTpAccept(Player p) {
        Tpa r = requests.remove(p.getUniqueId());
        if (r == null || r.expires < System.currentTimeMillis()) { plugin.msg(p, "&cYou have no pending teleport request."); return true; }
        Player from = Bukkit.getPlayer(r.from);
        if (from == null) { plugin.msg(p, "&cThat player is no longer online."); return true; }
        plugin.msg(from, "&a" + p.getName() + " accepted your request.");
        if (!r.here) teleport(from, p.getLocation(), p.getName());
        else teleport(p, from.getLocation(), from.getName());
        return true;
    }

    private boolean cmdTpDeny(Player p) {
        Tpa r = requests.remove(p.getUniqueId());
        if (r == null) { plugin.msg(p, "&cYou have no pending teleport request."); return true; }
        Player from = Bukkit.getPlayer(r.from);
        if (from != null) plugin.msg(from, "&c" + p.getName() + " denied your request.");
        plugin.msg(p, "&7Request denied.");
        return true;
    }

    // ---------------------------------------------------------------- RTP

    private World rtpWorld() {
        World w = Bukkit.getWorld(plugin.getConfig().getString("rtp.world", "world"));
        return w != null ? w : Bukkit.getWorlds().get(0);
    }

    private boolean unsafe(Material m) {
        return m == Material.WATER || m == Material.LAVA || m == Material.FIRE || m == Material.SOUL_FIRE
                || m == Material.MAGMA_BLOCK || m == Material.CACTUS || m == Material.POWDER_SNOW
                || m == Material.CAMPFIRE || m == Material.SOUL_CAMPFIRE || m == Material.SWEET_BERRY_BUSH
                || m == Material.BEDROCK || m == Material.BUBBLE_COLUMN || m == Material.AIR;
    }

    private void findLocation(World w, int attempts, Consumer<Location> done) {
        if (attempts <= 0) { done.accept(null); return; }
        int min = plugin.getConfig().getInt("rtp.min-radius", 500);
        int max = Math.max(min + 1, plugin.getConfig().getInt("rtp.max-radius", 5000));
        double ang = rnd.nextDouble() * Math.PI * 2;
        double dist = min + rnd.nextDouble() * (max - min);
        final int x = (int) (Math.cos(ang) * dist);
        final int z = (int) (Math.sin(ang) * dist);
        if (!w.getWorldBorder().isInside(new Location(w, x, 64, z))) { findLocation(w, attempts - 1, done); return; }
        w.getChunkAtAsync(x >> 4, z >> 4).thenAccept(chunk -> Bukkit.getScheduler().runTask(plugin, () -> {
            int y = w.getHighestBlockYAt(x, z, HeightMap.MOTION_BLOCKING_NO_LEAVES);
            Material ground = w.getBlockAt(x, y, z).getType();
            if (unsafe(ground) || y <= w.getMinHeight()) findLocation(w, attempts - 1, done);
            else done.accept(new Location(w, x + 0.5, y + 1, z + 0.5));
        }));
    }

    private boolean cmdRtp(Player p) {
        UUID id = p.getUniqueId();
        boolean admin = p.hasPermission("vibeeconomy.admin");
        if (!admin) {
            Long until = rtpCooldown.get(id);
            if (until != null && until > System.currentTimeMillis()) {
                plugin.msg(p, "&cRTP cooldown: &f" + ((until - System.currentTimeMillis() + 999) / 1000) + "s&c left.");
                return true;
            }
        }
        if (inCombat(p) && !admin) { plugin.msg(p, "&cYou can't RTP while in combat."); return true; }
        long cd = plugin.getConfig().getLong("rtp.cooldown-seconds", 30);
        rtpCooldown.put(id, System.currentTimeMillis() + cd * 1000L);
        plugin.msg(p, "&7Finding a safe location...");
        findLocation(rtpWorld(), 12, loc -> {
            if (!p.isOnline()) return;
            if (loc == null) {
                plugin.msg(p, "&cCouldn't find a safe spot. Try again.");
                rtpCooldown.remove(id);
                return;
            }
            teleport(p, loc, "a random location");
        });
        return true;
    }

    // ---------------------------------------------------------------- RTP queue

    private void tellQueue(String text) {
        for (UUID id : queue) {
            Player q = Bukkit.getPlayer(id);
            if (q != null) plugin.msg(q, text);
        }
    }

    private boolean cmdRtpQueue(Player p) {
        UUID id = p.getUniqueId();
        if (queue.remove(id)) { plugin.msg(p, "&7You left the RTP queue."); return true; }
        if (inCombat(p)) { plugin.msg(p, "&cYou can't join the queue while in combat."); return true; }
        if (plugin.duels() != null && plugin.duels().inDuel(p)) { plugin.msg(p, "&cYou can't join during a duel."); return true; }
        queue.add(id);
        int min = plugin.getConfig().getInt("rtp.queue-min-players", 2);
        plugin.msg(p, "&aJoined the RTP queue (&f" + queue.size() + "&a/&f" + min + "&a needed). Run &f/rtpqueue &aagain to leave.");
        if (queue.size() >= min && queueTask == null) {
            int secs = plugin.getConfig().getInt("rtp.queue-countdown-seconds", 10);
            tellQueue("&6RTP queue match found! Teleporting in &f" + secs + "s&6. Everyone goes to the same area.");
            queueTask = Bukkit.getScheduler().runTaskLater(plugin, this::runQueue, secs * 20L);
        } else if (queue.size() < min) {
            tellQueue("&7" + p.getName() + " joined the queue (" + queue.size() + "/" + min + ").");
        }
        return true;
    }

    private Location spread(Location base) {
        World w = base.getWorld();
        for (int i = 0; i < 8; i++) {
            int x = base.getBlockX() + rnd.nextInt(13) - 6;
            int z = base.getBlockZ() + rnd.nextInt(13) - 6;
            int y = w.getHighestBlockYAt(x, z, HeightMap.MOTION_BLOCKING_NO_LEAVES);
            if (!unsafe(w.getBlockAt(x, y, z).getType())) return new Location(w, x + 0.5, y + 1, z + 0.5);
        }
        return base;
    }

    private void runQueue() {
        queueTask = null;
        List<Player> group = new ArrayList<>();
        for (UUID id : new ArrayList<>(queue)) {
            Player q = Bukkit.getPlayer(id);
            if (q == null || !q.isOnline() || inCombat(q)) continue;
            if (plugin.duels() != null && plugin.duels().inDuel(q)) continue;
            group.add(q);
        }
        queue.clear();
        int min = plugin.getConfig().getInt("rtp.queue-min-players", 2);
        if (group.size() < min) {
            for (Player q : group) plugin.msg(q, "&cNot enough players. The RTP queue was cancelled.");
            return;
        }
        findLocation(rtpWorld(), 15, base -> {
            if (base == null) {
                for (Player q : group) plugin.msg(q, "&cCouldn't find a safe spot. Try /rtpqueue again.");
                return;
            }
            for (Player q : group) {
                if (!q.isOnline()) continue;
                q.teleportAsync(spread(base));
                plugin.msg(q, "&aTeleported with &f" + (group.size() - 1) + " &aother player(s). Good luck!");
            }
        });
    }

    /** Finds a random safe location (used by duels). Calls back on the main thread; null if none found. */
    void randomSpot(Consumer<Location> done) { findLocation(rtpWorld(), 15, done); }

    /** A safe spot near base shifted by dx/dz, or base itself if that spot isn't safe. */
    Location safeOffset(Location base, int dx, int dz) {
        World w = base.getWorld();
        int x = base.getBlockX() + dx;
        int z = base.getBlockZ() + dz;
        int y = w.getHighestBlockYAt(x, z, HeightMap.MOTION_BLOCKING_NO_LEAVES);
        if (unsafe(w.getBlockAt(x, y, z).getType())) return base;
        return new Location(w, x + 0.5, y + 1, z + 0.5);
    }

    // ---------------------------------------------------------------- commands

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (!(s instanceof Player p)) { plugin.msg(s, "&cPlayers only."); return true; }
        switch (cmd.getName().toLowerCase()) {
            case "sethome":  return cmdSetHome(p, a);
            case "home":     return cmdHome(p, a);
            case "delhome":  return cmdDelHome(p, a);
            case "homes":    return cmdHomes(p);
            case "tpa":      return cmdTpa(p, a, false);
            case "tpahere":  return cmdTpa(p, a, true);
            case "tpaccept": return cmdTpAccept(p);
            case "tpdeny":   return cmdTpDeny(p);
            case "spawn":    teleport(p, getSpawn(), "spawn"); return true;
            case "rtp":      return cmdRtp(p);
            case "rtpqueue": return cmdRtpQueue(p);
        }
        return false;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (!(s instanceof Player)) return out;
        if (a.length != 1) return out;
        Player p = (Player) s;
        String cur = a[0].toLowerCase();
        String n = cmd.getName().toLowerCase();
        if (n.equals("tpa") || n.equals("tpahere")) {
            for (Player o : Bukkit.getOnlinePlayers()) if (o.getName().toLowerCase().startsWith(cur)) out.add(o.getName());
        } else if (n.equals("home") || n.equals("delhome")) {
            ConfigurationSection sec = homeSection(p.getUniqueId());
            if (sec != null) for (String k : sec.getKeys(false)) if (k.startsWith(cur)) out.add(k);
        }
        return out;
    }
}
