package dev.vibe.economy;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Player-to-player auction house with a GUI. */
public final class AuctionHouse implements Listener, TabExecutor {

    private static final String[] SORTS = {"Newest", "Price: Low to High", "Price: High to Low"};

    private static final class Listing {
        final String id; final UUID seller; final String sellerName; final double price; final ItemStack item; final long time;
        Listing(String id, UUID seller, String sellerName, double price, ItemStack item, long time) {
            this.id = id; this.seller = seller; this.sellerName = sellerName; this.price = price; this.item = item; this.time = time;
        }
    }

    private static final class Holder implements InventoryHolder {
        final boolean mine; final int page; final int sort;
        final Map<Integer, String> slots = new HashMap<>();
        Inventory inv;
        Holder(boolean mine, int page, int sort) { this.mine = mine; this.page = page; this.sort = sort; }
        @Override public Inventory getInventory() { return inv; }
    }

    private final VibeEconomy plugin;
    private final File file;
    private final List<Listing> listings = new ArrayList<>();
    private final Map<UUID, List<ItemStack>> claims = new HashMap<>();

    public AuctionHouse(VibeEconomy plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "auctions.yml");
        load();
        Bukkit.getScheduler().runTaskTimer(plugin, this::expire, 1200L, 1200L);
    }

    // ---------------------------------------------------------------- storage

    private void load() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection ls = y.getConfigurationSection("listings");
        if (ls != null) {
            for (String id : ls.getKeys(false)) {
                ConfigurationSection s = ls.getConfigurationSection(id);
                if (s == null) continue;
                ItemStack item = s.getItemStack("item");
                if (item == null) continue;
                try {
                    listings.add(new Listing(id, UUID.fromString(s.getString("seller", "")), s.getString("name", "?"),
                            s.getDouble("price"), item, s.getLong("time")));
                } catch (IllegalArgumentException ignored) { }
            }
        }
        ConfigurationSection cs = y.getConfigurationSection("claims");
        if (cs != null) {
            for (String u : cs.getKeys(false)) {
                List<ItemStack> items = new ArrayList<>();
                for (Object o : cs.getList(u, new ArrayList<>())) if (o instanceof ItemStack it) items.add(it);
                try { claims.put(UUID.fromString(u), items); } catch (IllegalArgumentException ignored) { }
            }
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Listing l : listings) {
            String k = "listings." + l.id;
            y.set(k + ".seller", l.seller.toString());
            y.set(k + ".name", l.sellerName);
            y.set(k + ".price", l.price);
            y.set(k + ".time", l.time);
            y.set(k + ".item", l.item);
        }
        for (Map.Entry<UUID, List<ItemStack>> e : claims.entrySet()) {
            if (!e.getValue().isEmpty()) y.set("claims." + e.getKey(), e.getValue());
        }
        try { y.save(file); } catch (IOException e) { plugin.getLogger().severe("auctions.yml: " + e.getMessage()); }
    }

    private void expire() {
        long dur = plugin.getConfig().getLong("auction.duration-hours", 48) * 3_600_000L;
        long now = System.currentTimeMillis();
        boolean changed = false;
        Iterator<Listing> it = listings.iterator();
        while (it.hasNext()) {
            Listing l = it.next();
            if (now - l.time >= dur) {
                it.remove();
                claims.computeIfAbsent(l.seller, k -> new ArrayList<>()).add(l.item);
                changed = true;
                Player sp = Bukkit.getPlayer(l.seller);
                if (sp != null) plugin.msg(sp, "&eA listing of yours expired. Use &f/ah claim &eto get the item back.");
            }
        }
        if (changed) save();
    }

    private Listing find(String id) {
        for (Listing l : listings) if (l.id.equals(id)) return l;
        return null;
    }

    // ---------------------------------------------------------------- commands

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (!(s instanceof Player p)) { plugin.msg(s, "&cPlayers only."); return true; }
        if (a.length == 0) { open(p, false, 0, 0); return true; }
        switch (a[0].toLowerCase()) {
            case "sell": sell(p, a); break;
            case "mine": open(p, true, 0, 0); break;
            case "claim": claim(p); break;
            default: plugin.msg(p, "&cUsage: /ah, /ah sell <price>, /ah mine, /ah claim");
        }
        return true;
    }

    private void sell(Player p, String[] a) {
        if (a.length < 2) { plugin.msg(p, "&cUsage: /ah sell <price>  (sells the stack in your hand)"); return; }
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (hand.getType() == Material.AIR) { plugin.msg(p, "&cHold the item you want to sell."); return; }
        Double price = VibeEconomy.parseMoney(a[1]);
        double max = plugin.getConfig().getDouble("auction.max-price", 1_000_000_000);
        if (price == null || price < 1 || price > max) {
            plugin.msg(p, "&cPrice must be between $1 and " + plugin.money(max) + ". You can use k, m, b (e.g. 2.5k).");
            return;
        }
        int mine = 0;
        for (Listing l : listings) if (l.seller.equals(p.getUniqueId())) mine++;
        int limit = plugin.getConfig().getInt("auction.max-listings", 10);
        if (mine >= limit) { plugin.msg(p, "&cYou can only have " + limit + " listings at once."); return; }
        if (plugin.godset().isGodItem(hand)) { plugin.msg(p, "&cThe God set can't be sold."); return; }
        ItemStack copy = hand.clone();
        p.getInventory().setItemInMainHand(null);
        listings.add(new Listing(UUID.randomUUID().toString(), p.getUniqueId(), p.getName(), price, copy, System.currentTimeMillis()));
        save();
        double tax = plugin.getConfig().getDouble("auction.tax-percent", 5);
        plugin.msg(p, "&aListed &f" + Util.itemName(copy) + "&a for &f" + plugin.money(price) + "&a. A " + tax + "% tax is taken when it sells.");
    }

    private void claim(Player p) {
        List<ItemStack> items = claims.remove(p.getUniqueId());
        if (items == null || items.isEmpty()) { plugin.msg(p, "&cYou have nothing to claim."); return; }
        for (ItemStack it : items) plugin.giveItem(p, it);
        save();
        plugin.msg(p, "&aClaimed &f" + items.size() + " &aitem stack(s).");
    }

    // ---------------------------------------------------------------- GUI

    public void open(Player p, boolean mine, int page, int sort) {
        List<Listing> view = new ArrayList<>();
        for (Listing l : listings) if (!mine || l.seller.equals(p.getUniqueId())) view.add(l);
        if (sort == 1) view.sort(Comparator.comparingDouble(l -> l.price));
        else if (sort == 2) view.sort((x, y) -> Double.compare(y.price, x.price));
        else view.sort((x, y) -> Long.compare(y.time, x.time));

        int pages = Math.max(1, (int) Math.ceil(view.size() / 45.0));
        int pg = Math.max(0, Math.min(page, pages - 1));

        Holder h = new Holder(mine, pg, sort);
        String title = (mine ? "&6&lMy Listings" : "&6&lAuction House") + " &8(" + (pg + 1) + "/" + pages + ")";
        Inventory inv = Bukkit.createInventory(h, 54, ItemSpec.c(title));
        h.inv = inv;

        long dur = plugin.getConfig().getLong("auction.duration-hours", 48) * 3_600_000L;
        int from = pg * 45;
        for (int i = 0; i < 45 && from + i < view.size(); i++) {
            Listing l = view.get(from + i);
            ItemStack icon = l.item.clone();
            ItemMeta m = icon.getItemMeta();
            List<String> lore = m.hasLore() ? new ArrayList<>(m.getLore()) : new ArrayList<>();
            lore.add("");
            lore.add(ItemSpec.c("&7Seller: &f" + l.sellerName));
            lore.add(ItemSpec.c("&aPrice: &f" + plugin.money(l.price)));
            lore.add(ItemSpec.c("&7Expires in: &f" + Util.timeLeft(l.time + dur - System.currentTimeMillis())));
            boolean own = l.seller.equals(p.getUniqueId());
            lore.add(ItemSpec.c(mine ? "&eClick to cancel this listing" : (own ? "&7This is your listing" : "&eClick to buy")));
            m.setLore(lore);
            icon.setItemMeta(m);
            inv.setItem(i, icon);
            h.slots.put(i, l.id);
        }
        for (int i = 45; i < 54; i++) inv.setItem(i, Util.filler());
        Util.navButtons(inv);
        if (pg > 0) inv.setItem(45, Util.button(Material.ARROW, "&7Previous page"));
        if (pg < pages - 1) inv.setItem(53, Util.button(Material.ARROW, "&7Next page"));
        if (!mine) inv.setItem(47, Util.button(Material.HOPPER, "&eSort: &f" + SORTS[sort], "&7Click to change."));
        inv.setItem(48, mine ? Util.button(Material.CHEST, "&eBack to Auction House")
                : Util.button(Material.BOOK, "&eMy Listings", "&7View or cancel your listings."));
        inv.setItem(49, Util.button(Material.GOLD_INGOT, "&eBalance: &a" + plugin.money(plugin.getBalance(p.getUniqueId()))));
        List<ItemStack> cl = claims.get(p.getUniqueId());
        int cn = cl == null ? 0 : cl.size();
        inv.setItem(50, Util.button(Material.ENDER_CHEST, "&dClaim items", "&7Expired listings waiting: &f" + cn));
        p.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != top) return;
        int slot = e.getRawSlot();
        if (Util.navClick(plugin, p, slot)) return;

        if (slot == 45 && h.page > 0) { open(p, h.mine, h.page - 1, h.sort); return; }
        if (slot == 53) { open(p, h.mine, h.page + 1, h.sort); return; }
        if (slot == 47 && !h.mine) { open(p, false, 0, (h.sort + 1) % SORTS.length); return; }
        if (slot == 48) { open(p, !h.mine, 0, 0); return; }
        if (slot == 50) { claim(p); open(p, h.mine, h.page, h.sort); return; }

        String id = h.slots.get(slot);
        if (id == null) return;
        Listing l = find(id);
        if (l == null) { plugin.msg(p, "&cThat listing is gone."); open(p, h.mine, h.page, h.sort); return; }

        if (h.mine) {
            listings.remove(l);
            save();
            plugin.giveItem(p, l.item.clone());
            plugin.msg(p, "&aListing cancelled. The item was returned to you.");
            open(p, true, h.page, h.sort);
            return;
        }
        if (l.seller.equals(p.getUniqueId())) { plugin.msg(p, "&cThat's your listing. Use My Listings to cancel it."); return; }
        if (!plugin.withdraw(p.getUniqueId(), l.price)) {
            plugin.msg(p, "&cYou need " + plugin.money(l.price) + " to buy that.");
            return;
        }
        double tax = l.price * plugin.getConfig().getDouble("auction.tax-percent", 5) / 100.0;
        double payout = Util.round2(l.price - tax);
        plugin.deposit(l.seller, payout);
        plugin.record(p.getUniqueId(), "Auction: bought " + Util.itemName(l.item), -l.price);
        plugin.record(l.seller, "Auction: sold " + Util.itemName(l.item) + " to " + p.getName(), payout);
        listings.remove(l);
        save();
        plugin.giveItem(p, l.item.clone());
        plugin.msg(p, "&aBought &f" + Util.itemName(l.item) + "&a for &f" + plugin.money(l.price) + "&a.");
        Player sp = Bukkit.getPlayer(l.seller);
        if (sp != null) plugin.msg(sp, "&a" + p.getName() + " bought your &f" + Util.itemName(l.item) + "&a. You received &f"
                + plugin.money(payout) + "&a after tax.");
        open(p, false, h.page, h.sort);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length != 1) return out;
        for (String o : new String[]{"sell", "mine", "claim"}) if (o.startsWith(a[0].toLowerCase())) out.add(o);
        return out;
    }
}
