package dev.vibe.economy;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

final class Util {
    private Util() { }

    static double round2(double v) { return Math.round(v * 100.0) / 100.0; }

    static String pretty(Material m) {
        String[] words = m.name().toLowerCase(Locale.ROOT).split("_");
        StringBuilder sb = new StringBuilder();
        for (String w : words) {
            if (w.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        return sb.toString();
    }

    static String itemName(ItemStack it) {
        ItemMeta m = it.getItemMeta();
        String n = (m != null && m.hasDisplayName()) ? ChatColor.stripColor(m.getDisplayName()) : pretty(it.getType());
        return it.getAmount() + "x " + n;
    }

    static ItemStack button(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(ItemSpec.c(name));
        List<String> l = new ArrayList<>();
        for (String s : lore) l.add(ItemSpec.c(s));
        meta.setLore(l);
        it.setItemMeta(meta);
        return it;
    }

    static ItemStack filler() { return button(Material.GRAY_STAINED_GLASS_PANE, " "); }

    static String timeLeft(long ms) {
        if (ms < 0) ms = 0;
        long mins = ms / 60000;
        long h = mins / 60;
        return h + "h " + (mins % 60) + "m";
    }

    static String ago(long ms) {
        if (ms < 0) ms = 0;
        long m = ms / 60000;
        if (m < 1) return "just now";
        if (m < 60) return m + "m ago";
        long h = m / 60;
        if (h < 48) return h + "h ago";
        return (h / 24) + "d ago";
    }

    /** Shop / Sell / Transactions shortcut buttons shared by every money menu (bottom row slots 46, 51, 52). */
    static void navButtons(org.bukkit.inventory.Inventory inv) {
        inv.setItem(46, button(Material.CHEST, "&e&lShop", "&7Open the main menu and shop."));
        inv.setItem(51, button(Material.HOPPER, "&a&lSell", "&7Open the sell menu."));
        inv.setItem(52, button(Material.BOOK, "&b&lTransactions", "&7See your money history."));
    }

    static boolean navClick(VibeEconomy plugin, org.bukkit.entity.Player p, int slot) {
        if (slot == 46) { plugin.shopGui().openMain(p); return true; }
        if (slot == 51) { plugin.sellGui().open(p); return true; }
        if (slot == 52) { plugin.history().open(p, 0); return true; }
        return false;
    }

    /** $1.2K, $3.4M, $2B style money for nametags. */
    static String compact(double v) {
        if (v >= 1e9) return "$" + trim(v / 1e9) + "B";
        if (v >= 1e6) return "$" + trim(v / 1e6) + "M";
        if (v >= 1e3) return "$" + trim(v / 1e3) + "K";
        return "$" + (long) v;
    }

    private static String trim(double d) {
        String s = String.format(Locale.US, "%.1f", d);
        return s.endsWith(".0") ? s.substring(0, s.length() - 2) : s;
    }
}
